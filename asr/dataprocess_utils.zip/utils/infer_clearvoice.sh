#!/usr/bin/env bash

set -e
# set -u
set -o pipefail

stage=1
stop_stage=2

# 环境
source /mnt/lustre/wangweifei/repository/miniconda3/etc/profile.d/conda.sh
conda activate AudioPipeline
export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/miniconda3/envs/AudioPipeline/lib/python3.9/site-packages/nvidia/cudnn/lib:$LD_LIBRARY_PATH

# gpu3上额外加上
# export PATH=/usr/local/cuda-11.8/bin:$PATH
# export LD_LIBRARY_PATH=/usr/local/cuda-11.8/lib64:$LD_LIBRARY_PATH

# H800加上
# export PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/bin:$PATH
# export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/lib64:$LD_LIBRARY_PATH
# export PYTHONIOENCODING=utf-8


# 参数设置 采样率48k


wav_scp=$1    #"wav.scp"
wav_dir=$(dirname "$wav_scp")

# 先删除split和log以及wav.scp.new
rm -rf $wav_dir/split
# 创建
mkdir -p $wav_dir/split

wav_scp_new="${wav_dir}/split/wav.scp.new"
output_dir=$2
gpuid_list=$3
gpu_inference=true
njob=1    # the number of jobs for CPU decoding, if gpu_inference=false, use CPU decoding, please set njob


# 跳过已经处理的wav_id,生成新的wav.scp.new
declare -A processed_map
# processed_files=($(ls ${output_dir}/MossFormer2_SE_48K/* 2>/dev/null || true))  -name "*.mp3" -size +20c
processed_files=($(find "${output_dir}/MossFormer2_SE_48K" -type f 2>/dev/null))
for processed_file in "${processed_files[@]}"; do
    processed_id=$(basename "$processed_file" | cut -d. -f1)
    processed_map["$processed_id"]=1
done

# Process wav.scp and create new wav.scp.new
while IFS=$'\t ' read -r wav_id wav_path; do
    # Check if current wav_id is already processed
    if [ -z "${processed_map[$wav_id]}" ]; then
        echo -e "${wav_id}\t${wav_path}" >> "$wav_scp_new"
    fi
done < "$wav_scp"




. ./parse_options.sh || exit 1;

if ${gpu_inference} == "true"; then
    nj=$(echo $gpuid_list | awk -F "," '{print NF}')
else
    nj=$njob
    batch_size=1
    gpuid_list=""
    for JOB in $(seq ${nj}); do
        gpuid_list=$gpuid_list"-1,"
    done
fi

split_scps=""
for JOB in $(seq ${nj}); do
    split_scps="$split_scps $wav_dir/split/wav.$JOB.scp"
done
perl ./split_scp.pl ${wav_scp_new} ${split_scps}


if [ $stage -le 1 ] && [ $stop_stage -ge 1 ];then
    echo "Decoding ..."
    gpuid_list_array=(${gpuid_list//,/ })
    for JOB in $(seq ${nj}); do
        {
        id=$((JOB-1))
        gpuid=${gpuid_list_array[$id]}

        cd /mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/
        export CUDA_VISIBLE_DEVICES=$gpuid
        # 采样率48k
        python infer_clearvoice.py \
            -i ${wav_dir}/split/wav.$JOB.scp \
            -o ${output_dir} > ${wav_dir}/split/job_${JOB}.log  2>&1
        }&
       
    done
    wait
fi


