# from pyannote.audio import Pipeline
# pipeline = Pipeline.from_pretrained("/home/wangweifei/repository/pyannote/speaker-diarization/config.yaml")

# # send pipeline to GPU (when available)
# import torch
# pipeline.to(torch.device("cuda"))

# # apply pretrained pipeline
# diarization = pipeline("/mnt/lustre/wangweifei/podcast_seg/part00/5/09a9c7c6-8e0e-4701-9600-852237b38931/09a9c7c6-8e0e-4701-9600-852237b38931_181.wav")

# # print the result
# for turn, _, speaker in diarization.itertracks(yield_label=True):
#     print(f"start={turn.start:.1f}s stop={turn.end:.1f}s speaker_{speaker}")
# # start=0.2s stop=1.5s speaker_0
# # start=1.8s stop=3.9s speaker_1
# # start=4.2s stop=5.7s speaker_0
# # ...
import argparse
import json
import os
import torch
from pyannote.audio import Pipeline
import time

def load_pipeline(device):
    # Load the pre-trained speaker diarization model
    pipeline = Pipeline.from_pretrained("/home/wangweifei/repository/pyannote/speaker-diarization/config.yaml")
    pipeline.to(device)
    return pipeline

def count_speakers_in_file(audio_file, pipeline):
    # Perform speaker diarization
    diarization = pipeline(audio_file)

    # Get all speaker identifiers and their time segments
    speakers = set()
    speaker_segments = []
    for turn, _, speaker in diarization.itertracks(yield_label=True):
        speakers.add(speaker)
        speaker_segments.append({
            "speaker": speaker,
            "start": f"{turn.start:.2f}",
            "end": f"{turn.end:.2f}"
        })

    # Return the number of speakers and time segment information
    return len(speakers), list(speakers), speaker_segments

def process_wav_scp(input_file, output_dir, device):
    # Load the pipeline once
    pipeline = load_pipeline(device)

    # Read already processed wav_ids if output file exists
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, "speaker.jsonl")

    processed_wav_ids = set()
    if os.path.exists(output_file):
        with open(output_file, 'r') as out_f:
            for line in out_f:
                result = json.loads(line.strip())
                processed_wav_ids.add(result['wav_id'])

    with open(input_file, 'r') as f:
        lines = f.readlines()

    with open(output_file, 'a') as out_f:
        for line in lines:
            key, audio_file = line.strip().split()
            if key in processed_wav_ids:
                continue
            try:
                num_speakers, speakers, speaker_segments = count_speakers_in_file(audio_file, pipeline)
                result = {
                    "wav_id": key,
                    "speaker_num": num_speakers,
                    "speakers": speaker_segments
                }
                out_f.write(json.dumps(result) + "\n")
                out_f.flush()
            except Exception as e:
                print(f"Error processing {key}: {e}")

def main(args):
    # 记录开始时间
    start_time = time.time()
    gpuid = int(args.gpuid)
    device = torch.device(f"cuda:{gpuid}" if torch.cuda.is_available() else "cpu")
    process_wav_scp(args.input, args.output_dir, device)
    # 记录结束时间
    end_time = time.time()
    
    # 计算总耗时（按小时显示）
    elapsed_time = end_time - start_time
    elapsed_hours = elapsed_time / 3600
    print(f"Processing {args.input} completed in {elapsed_hours:.2f} hours.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=str, default="./data/test/wav.scp")
    parser.add_argument('--output_dir', type=str, default="./results")
    parser.add_argument('--gpuid', type=str, default="0")
    args = parser.parse_args()

    main(args)
