import os
import numpy as np
from subprocess import CalledProcessError, run
from tqdm import tqdm
from modelscope.pipelines import pipeline
from modelscope.utils.constant import Tasks

import argparse

# 全局变量
SAMPLE_RATE = 16000

# 初始化Voice Activity Detection模型
inference_pipeline = pipeline(
    task=Tasks.voice_activity_detection,
    model='damo/speech_fsmn_vad_zh-cn-16k-common-pytorch',
    ngpu = 0
)

# 加载音频文件
def load_audio(file: str, sr: int = SAMPLE_RATE):
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        # raise RuntimeError(f"Failed to load audio: {e.stderr.decode()}") from e
        print(f"Failed to load audio: {e.stderr.decode()}")
        return None  # 返回 None 表示加载音频失败
    return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0

# 处理VAD
def process_vad(args,output_dir):
    try: 
        audio_line = args
        audio_id = audio_line[0]
        audio_path = audio_line[1]

        # 加载音频
        waveform = load_audio(audio_path)
        if waveform is None:
            print(f"{waveform}为空")
        else:
        
            # VAD 分段
            segments_result = inference_pipeline(input=waveform)
            
            # 输出目录
            file_path = os.path.join(output_dir, f"{audio_id}.segments")

            # 写入分段结果到文件
            with open(file_path, "w") as f1:
                for i, segment in enumerate(segments_result[0]["value"]):
                    start = segment[0] / 1000
                    end = segment[1] / 1000
                    f1.write(f"{audio_id}_{i} {audio_id} {start} {end}\n")
    except Exception as e :
        print(f"Exception occurred while processing audio file {audio_id}: {e}")

# 从wav.scp文件中获取数据
def get_data(wav_scp_path, output_dir):
    audio_lines = []
    with open(wav_scp_path, 'r') as f:
        for line in f:
            audio_line = line.strip().split("\t")
            audio_id = audio_line[0]
            wav_path = audio_line[1]
            file_path = os.path.join(output_dir, f"{audio_id}.segments")

            # 检查输出文件是否存在并且不为空
            if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
                continue  # 跳过已处理的文件
            else:
                audio_lines.append(audio_line)

    return audio_lines

def main():
    parser = argparse.ArgumentParser(description="Voice Activity Detection")
    parser.add_argument("--wav_scp", '-w',type=str, help="Path to the wav.scp file")
    parser.add_argument("--output_dir", '-o',type=str, default=None, help="Output directory for segments files")
    args = parser.parse_args()

    wav_scp_path = args.wav_scp
    output_dir = args.output_dir
    os.makedirs(output_dir,exist_ok=True)

    audio_lines = get_data(wav_scp_path, output_dir)
    for audio_line in tqdm(audio_lines):
        process_vad(audio_line,output_dir)

if __name__ == "__main__":
    main()
