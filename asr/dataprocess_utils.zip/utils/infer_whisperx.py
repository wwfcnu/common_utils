import codecs
import sys
import os
from tqdm import tqdm
import concurrent.futures
import os
import shutil
import argparse
import whisperx

# 写一个whisper的pipeline类，batch_size在whisper里面就是线程数

class whisper_infer_pipeline:
    def __init__(self,whisper_model_path,gpuid) -> None:
        self.gpuid = gpuid
        self.device = "cuda"
        # self.model = WhisperModel(whisper_model_path, device=self.device, device_index=[int(gpuid)])
        self.model = whisperx.load_model(whisper_model_path, device=self.device, compute_type="float16",language="zh", device_index=[int(gpuid)]) #处理gigaspeech将语言改成英文
        #self.model_a, self.metadata = whisperx.load_align_model(language_code="zh", device=self.device)
    def __call__(self, clip):

        wav_id = clip[0]
        wav_path = clip[1]
        audio = whisperx.load_audio(wav_path)
        result = self.model.transcribe(wav_path,batch_size=32,chunk_size=1) # vad的chunk_size默认是30s chunk_size=20,tv改成10s
        #result = whisperx.align(result["segments"], self.model_a, self.metadata, audio, device=self.device, return_char_alignments=False)
        hypothesis = []
        segments = []
        for i, segment in enumerate(result["segments"]):
            text = segment["text"]
            start = segment["start"]
            end = segment["end"]
            key = f"{wav_id}_{i}"
            
            hypothesis.append(f"{key}\t{text}")
            segments.append(f"{key} {wav_id} {start} {end}")
        # hypothesis = "".join(seg["text"] for seg in result["segments"])
        #return '{0}'.format(wav_id + '\t' + hypothesis + '\n')
        
        return '\n'.join(hypothesis),"\n".join(segments)

def whisper_infer(args):
    model_path = args.model
    gpuid = args.gpuid

    # 加载模型
    infer_pipeline = whisper_infer_pipeline(model_path,gpuid)

    wav_scp_file = args.input
    output_dir = args.output_dir
    max_workers = args.batch_size

    clips = []
    with open(wav_scp_file)as f:
        for line in f:
            audio_clip = line.strip().split("\t")
            clips.append(audio_clip)

    os.makedirs(os.path.join(output_dir,"1best_recog"), exist_ok=True)
    result_file_path = codecs.open(f"{output_dir}/1best_recog/text", 'w+', 'utf8')
    segments_file_path = codecs.open(f"{output_dir}/1best_recog/segments", 'w+', 'utf8')
    #with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {executor.submit(infer_pipeline, clip): clip for clip in clips}
        for future in tqdm(concurrent.futures.as_completed(future_to_url),total=len(future_to_url),colour="blue"):
            clip = future_to_url[future]
            try:
                hypothesis,segments = future.result()
            except Exception as exc:
                print('%r generated an exception: %s' % (clip, exc))
            else:
                result_file_path.write(hypothesis + "\n")
                result_file_path.flush()
                segments_file_path.write(segments + "\n")
                segments_file_path.flush()
    result_file_path.close()
    segments_file_path.close()
    # 循环处理
    # for clip in tqdm(clips, total=len(clips), colour="blue"):
    #     try:
    #         hypothesis, segments = infer_pipeline(clip)
    #     except Exception as exc:
    #         print('%r generated an exception: %s' % (clip, exc))
    #     else:
    #         result_file_path.write(hypothesis + "\n")
    #         result_file_path.flush()
    #         segments_file_path.write(segments + "\n")
    #         segments_file_path.flush()

    # result_file_path.close()
    # segments_file_path.close()



if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default="large-v2")
    parser.add_argument('--input', type=str, default="./data/test/wav.scp")
    parser.add_argument('--output_dir', type=str, default="./results/")
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--gpuid', type=str, default="0")
    args = parser.parse_args()
    whisper_infer(args)