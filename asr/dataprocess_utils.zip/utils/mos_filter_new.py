import argparse
import pandas as pd
import json
def main(args):
    # Reading command-line arguments
    mos_text_file = args.mos_text_file
    wav_scp_file = args.wav_scp_file
    mos_wav_scp_file = args.mos_wav_scp_file

    mos_score = args.mos_score


    # 读取文件并替换单引号为双引号
    with open(mos_text_file, 'r') as file:
        fixed_lines = [line.replace("'", '"') for line in file.readlines()]
    # 处理每一行数据

    wav_id_mos = set()
    count_all = 0
    count_mos = 0
    duration_all = 0
    duration_mos = 0
    for line in fixed_lines:    

        json_data = json.loads(line)
        filename = json_data["filename"]
        P808_MOS = json_data["P808_MOS"]
        len_in_sec = json_data["len_in_sec"]
        wav_id = filename.split("/")[-1].replace(".wav","")
        if float(P808_MOS) >= mos_score:
            wav_id_mos.add(wav_id)
            count_mos += 1
            duration_mos += float(len_in_sec)
        
        count_all += 1
        duration_all += float(len_in_sec)



    # Filtering wav.scp file based on the selected wav IDs
    with open(wav_scp_file) as f, open(mos_wav_scp_file, "w") as w:
        for line in f:
            line = line.strip()
            wav_id, wav_path = line.split()
            if wav_id in wav_id_mos:
                w.write(f"{line}\n")

    # Statistics

    mos_percentage = (count_mos / count_all) * 100
    mos_duration_percentage = (duration_mos / duration_all) * 100

    print(f"mos >= {mos_score} 的音频个数：", count_mos)
    print(f"mos >= {mos_score} 的音频个数占总条数的百分比：", mos_percentage)
    print(f"mos >= {mos_score} 的音频时长：", duration_mos, "秒")
    print(f"mos >= {mos_score} 的音频时长占总时长的比例：", mos_duration_percentage)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process MOS files and WAV files.')
    parser.add_argument('--mos_text_file', '-mos', type=str, help='Path to the MOS CSV file')
    parser.add_argument('--wav_scp_file', '-w', type=str, help='Path to the WAV SCP file')
    parser.add_argument('--mos_wav_scp_file', '-wmos', type=str, help='Path to save filtered WAV SCP file')
    parser.add_argument('--mos_score', '-ms', help='mos-score', default=3.4, type=float)

    args = parser.parse_args()
    main(args)


    # python .py -mos dnsmos.txt -w seg_wav.scp -wmos mos_seg_wav.scp
    # 基于得到的mos文件，给定mos阈值，生成筛选后的mos_wav_scp