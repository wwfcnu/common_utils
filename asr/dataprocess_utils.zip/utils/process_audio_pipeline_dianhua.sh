#!/usr/bin/env bash

set -e
# set -u
set -o pipefail

stage=1
stop_stage=2

# 环境
source /mnt/lustre/wangweifei/repository/miniconda3/etc/profile.d/conda.sh
conda activate AudioPipeline
export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/miniconda3/envs/AudioPipeline/lib/python3.9/site-packages/nvidia/cudnn/lib:$LD_LIBRARY_PATH

# gpu3上额外加上
# export PATH=/usr/local/cuda-11.8/bin:$PATH
# export LD_LIBRARY_PATH=/usr/local/cuda-11.8/lib64:$LD_LIBRARY_PATH

# H800加上
# export PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/bin:$PATH
# export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/lib64:$LD_LIBRARY_PATH
# export PYTHONIOENCODING=utf-8



# 参数设置 注意采样率的选择，是用A800_main.py还是A800_main_sr.py
wav_dir=$1
wav_scp=$2
output_dir=$3
gpu_inference=true    # whether to perform gpu decoding
# gpuid_list="0,0,1,1"    # set gpus, e.g., gpuid_list="0,1"
gpuid_list=$4
njob=1    # the number of jobs for CPU decoding, if gpu_inference=false, use CPU decoding, please set njob


# 先删除split和log
rm -rf $wav_dir/split

. ./parse_options.sh || exit 1;

if ${gpu_inference} == "true"; then
    nj=$(echo $gpuid_list | awk -F "," '{print NF}')
else
    nj=$njob
    batch_size=1
    gpuid_list=""
    for JOB in $(seq ${nj}); do
        gpuid_list=$gpuid_list"-1,"
    done
fi

mkdir -p $wav_dir/split
split_scps=""
for JOB in $(seq ${nj}); do
    split_scps="$split_scps $wav_dir/split/wav.$JOB.scp"
done
perl ./split_scp.pl ${wav_scp} ${split_scps}


if [ $stage -le 1 ] && [ $stop_stage -ge 1 ];then
    echo "Decoding ..."
    gpuid_list_array=(${gpuid_list//,/ })
    for JOB in $(seq ${nj}); do
        {
        id=$((JOB-1))
        gpuid=${gpuid_list_array[$id]}

        cd /mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/


        export CUDA_VISIBLE_DEVICES=$gpuid
        # 采样率的选择
        python A800_main_sr.py \
            --config_path /mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/config_16k.json \
            --input_folder_path ${wav_dir}/split/wav.$JOB.scp \
            --output_dir ${output_dir} > ${wav_dir}/split/job_${JOB}.log  2>&1
        }&
    done
    wait
fi


