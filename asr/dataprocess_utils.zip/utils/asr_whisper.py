from faster_whisper import WhisperModel
import codecs
import sys
import os
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

model = WhisperModel("/home/wangweifei/repository/wair/asr_project/models/faster-whisper-large-v3", device="cuda", device_index=[0])

def whisper_process(file):
    try:
        segs, info = model.transcribe(file)  # ,initial_prompt="中文简体"
        segs = list(segs)
        hypothesis = "".join(seg.text for seg in segs)    
    except Exception as e:
        print(e)
        hypothesis = ""
    return hypothesis


def tt(temp):
    temp = temp.strip()
    if len(temp.split()) == 2:  # source_info_list format: "key\taudio"
        key, audio = temp.split(maxsplit=1)
      
        text = whisper_process(audio)   

        return '{0}'.format(key + '\t' + text + '\n')
    else:
        return '{0}'.format("Invalid line: " + temp + "\n")

def main():

    source_info_list = codecs.open(sys.argv[1], 'r', 'utf8')
    result_file_path = codecs.open(sys.argv[2], 'w+', 'utf8')

    MAX_WORKER = int(sys.argv[3])
    
    executor = ThreadPoolExecutor(max_workers=MAX_WORKER)
    all_task = [executor.submit(tt,temp) for temp in source_info_list]

    with tqdm(total=len(all_task)) as pbar:
        for future in as_completed(all_task):
            data = future.result()
            result_file_path.write(data)
            result_file_path.flush()
            pbar.update(1)

    source_info_list.close()
    result_file_path.close()

if __name__ == '__main__':
    main()
