import argparse
import concurrent.futures
import os
import multiprocessing
from modelscope.pipelines import pipeline
from modelscope.utils.constant import Tasks
from tqdm import tqdm
import numpy as np
from subprocess import CalledProcessError, run
import glob
import sys

# os.environ['CUDA_VISIBLE_DEVICES'] = "0"
SAMPLE_RATE = 16000


def load_audio(file: str, sr: int = SAMPLE_RATE):
    """
    Open an audio file and read as mono waveform, resampling as necessary

    Parameters
    ----------
    file: str
        The audio file to open

    sr: int
        The sample rate to resample the audio if necessary

    Returns
    -------
    A NumPy array containing the audio waveform, in float32 dtype.
    """

    # This launches a subprocess to decode audio while down-mixing
    # and resampling as necessary.  Requires the ffmpeg CLI in PATH.
    # fmt: off
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    # fmt: on
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        raise RuntimeError(f"Failed to load audio: {e.stderr.decode()}") from e

    return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0


def get_inference_pipeline(gpu_id):

    # paraformer
    os.environ['CUDA_VISIBLE_DEVICES'] = str(gpu_id)
    return pipeline(
        task=Tasks.auto_speech_recognition,
        model='iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-pytorch',
    )



def get_data(wav_scp_file, segments_file, output_dir):
    wav_scp_path = {}
    with open(wav_scp_file) as f1:
        for line in f1:
            wav_id, wav_path = line.strip().split("\t", 1)
            file_path = os.path.join(output_dir, f"{wav_id}.txt")
            if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
                continue
            else:
                wav_scp_path[wav_id] = wav_path

    data = {}
    with open(segments_file, 'r') as f:
        for line in f:
            line = line.strip().split()
            if line[1] in wav_scp_path:
                data.setdefault(line[1], []).append((line[0], line[2], line[3]))

    audio_lines = {}
    for audio_id, segments in data.items():
        audio_path = wav_scp_path.get(audio_id)
        audio_lines[audio_id] = (segments, audio_path)

    return audio_lines


def process_segment(audio_id, audio_lines, output_dir, inference_pipeline):
    segments, audio_path = audio_lines[audio_id]
    file_path = os.path.join(output_dir, f"{audio_id}.txt")
    waveform = load_audio(audio_path)

    with open(file_path, "w") as w:
        for segment in tqdm(segments, total=len(segments), desc=f"processing file {audio_id}"):
            try:
                sample_rate = 16000
                beg_idx = float(segment[1]) * sample_rate
                end_idx = float(segment[2]) * sample_rate
                wav_segment_id = segment[0]
                waveform_slice = waveform[int(beg_idx):int(end_idx)]
                result_segments = inference_pipeline(input=waveform_slice)
                hypothesis = result_segments[0]["text"]
                w.write(f"{wav_segment_id}\t{hypothesis}\n")
            except Exception as e:
                print(f"------------------Error Occurred-----------------{e}")
                continue


def main():
    parser = argparse.ArgumentParser(description='ASR Pipeline')
    parser.add_argument('--wav_scp', '-w', type=str, help='Path to the wav.scp file')
    parser.add_argument('--segment_merge_path', '-s', type=str, help='Path to the segment merge directory')
    parser.add_argument('--output_dir', '-o', type=str, help='Path to the output directory')
    parser.add_argument('--gpu_id', '-g', type=str, help='GPU ID')




    args = parser.parse_args()

    wav_scp_file = args.wav_scp
    segment_merge_path = args.segment_merge_path
    output_dir = args.output_dir
    gpu_id = args.gpu_id


    os.makedirs(output_dir, exist_ok=True)

    inference_pipeline = get_inference_pipeline(gpu_id)
    #segments_files = [file for file in glob.glob(f"{segment_merge_dir}/*.segments") if os.path.getsize(file) > 0]
    segments_files = []
    with open(segment_merge_path)as f:
        for line in f:
            segments_file = line.strip()
            segments_files.append(segments_file)

    for segments_file in tqdm(segments_files, total=len(segments_files)):
        audio_lines = get_data(wav_scp_file, segments_file, output_dir)
        for audio_id in audio_lines.keys():
            process_segment(audio_id, audio_lines, output_dir, inference_pipeline)


if __name__ == "__main__":
    main()
