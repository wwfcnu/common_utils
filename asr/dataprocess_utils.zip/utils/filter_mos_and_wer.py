import json
import argparse

def read_mos_file(mos_text_file):

    clip_dict = {}
    # 读取文件并替换单引号为双引号
    with open(mos_text_file, 'r') as file:
        fixed_lines = [line.replace("'", '"') for line in file.readlines()]
    # 处理每一行数据

    for line in fixed_lines:    

        json_data = json.loads(line)
        filename = json_data["filename"]
        P808_MOS = json_data["P808_MOS"]
        len_in_sec = json_data["len_in_sec"]
        wav_id = filename.split("/")[-1].split(".")[0]
        clip_dict[wav_id] = (len_in_sec,P808_MOS)

    return clip_dict

def main():
    parser = argparse.ArgumentParser(description="Process files.")
    parser.add_argument("-m", "--mos-text", dest="mos_text_file", help="Path to MOS text file")
    parser.add_argument("-w", "--mos-wav-scp", dest="mos_wav_scp_file", help="Path to MOS WAV SCP file")
    parser.add_argument("-f", "--filter-wer", dest="filter_wer_file", help="Path to filter WER file")
    parser.add_argument("-o", "--filter-mos-wer", dest="filter_mos_wer_file", help="Path to filtered MOS WER file")
    args = parser.parse_args()

    mos_text_file = args.mos_text_file
    mos_wav_scp_file = args.mos_wav_scp_file
    filter_wer_file = args.filter_wer_file
    filter_mos_wer_file = args.filter_mos_wer_file
    
    # 读取mos_text_file
    clip_dict = read_mos_file(mos_text_file)

    # 读取mos筛选后的wav.scp
    mos_uttid = set()
    with open(mos_wav_scp_file)as f:
        for line in f:
            uttid,wav_path = line.strip().split()
            mos_uttid.add(uttid)

  
    # 再mos筛选的基础上，进一步挑选filter_wer中的uttid
    filter_mos_wer_duration = 0
    with open(filter_wer_file)as f,open(filter_mos_wer_file,"w")as w:
        
        for line in f:
            wer_uttid = line.strip()
            if wer_uttid in mos_uttid:
                w.write(wer_uttid + "\n")
                duration = clip_dict[wer_uttid][0]
                filter_mos_wer_duration += duration
    
    print(f"经过p808_mos计算和wer筛选后的时长：{filter_mos_wer_duration}s .")




if __name__ == "__main__":
    main()