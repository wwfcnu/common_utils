import argparse

def main(text_file, wav_scp_file, remain_wav_scp_file):
    processed_wav = set()
    
    # 读取文本文件并获取处理过的音频ID
    with open(text_file) as f:
        for line in f:
            line = line.strip().split(maxsplit=1)
            # if len(line)== 2:
            wav_id = line[0]
            processed_wav.add(wav_id)
    
    # 打开原始音频列表文件和输出文件，将未处理的音频写入输出文件
    with open(wav_scp_file) as f, open(remain_wav_scp_file, "w") as w:
        for line in f:
            line = line.strip()
            wav_id,wav_path = line.split(maxsplit=1)
            if wav_id not in processed_wav:
                w.write(f"{line}\n")


if __name__ == "__main__":
    # 创建命令行参数解析器
    parser = argparse.ArgumentParser(description="Process text, wav_scp_file, and remain_wav_scp_file.")
    
    # 添加命令行参数，使用简写
    parser.add_argument("-t", "--text", dest="text_file", type=str, help="Path to the text file.")
    parser.add_argument("-w", "--wav", dest="wav_scp_file", type=str, help="Path to the original wav.scp file.")
    parser.add_argument("-r", "--remain", dest="remain_wav_scp_file", type=str, help="Path to the output remain_wav.scp file.")
    
    # 解析命令行参数
    args = parser.parse_args()
    
    # 调用 main 函数处理数据
    main(args.text_file, args.wav_scp_file, args.remain_wav_scp_file)


