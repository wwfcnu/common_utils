#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys

def load_duration_file(duration_file):
    """加载 duration 文件，返回 {uttid: duration_in_seconds} 的字典"""
    duration_dict = {}
    with open(duration_file, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) != 2:
                continue
            uttid, dur_str = parts
            try:
                duration = float(dur_str)
                duration_dict[uttid] = duration
            except ValueError:
                print(f"Warning: Invalid duration for {uttid}: {dur_str}", file=sys.stderr)
                continue
    return duration_dict

def load_uttid_file(uttid_file):
    """加载 utterance ID 文件，返回列表"""
    with open(uttid_file, 'r', encoding='utf-8') as f:
        uttids = [line.strip() for line in f if line.strip()]
    return uttids

def select_utts_by_duration(uttids, duration_dict, target_duration_sec):
    """从 uttids 中按顺序选择，直到总时长 >= target_duration_sec"""
    selected_utts = []
    total_duration = 0.0

    for uttid in uttids:
        if uttid not in duration_dict:
            print(f"Warning: {uttid} not found in duration file, skipping.", file=sys.stderr)
            continue

        dur = duration_dict[uttid]
        selected_utts.append(uttid)
        total_duration += dur

        if total_duration >= target_duration_sec:
            break

    return selected_utts, total_duration

def main():
    if len(sys.argv) != 4:
        print("Usage: python select_1w_hours.py <uttid_file> <duration_file> <output_file>", file=sys.stderr)
        sys.exit(1)

    uttid_file = sys.argv[1]
    duration_file = sys.argv[2]
    output_file = sys.argv[3]

    TARGET_HOURS = 10000
    TARGET_SECONDS = TARGET_HOURS * 3600  # 10,000 hours in seconds

    print(f"Loading utterance IDs from {uttid_file}...")
    uttids = load_uttid_file(uttid_file)

    print(f"Loading durations from {duration_file}...")
    duration_dict = load_duration_file(duration_file)

    print("Selecting utterances to reach target duration...")
    selected_utts, total_duration = select_utts_by_duration(uttids, duration_dict, TARGET_SECONDS)

    hours_achieved = total_duration / 3600.0
    print(f"Selected {len(selected_utts)} utterances, total duration: {hours_achieved:.2f} hours")

    # 写入选中的 uttid 到输出文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for uttid in selected_utts:
            f.write(uttid + '\n')

    print(f"Selected utterance IDs written to {output_file}")

if __name__ == '__main__':
    main()