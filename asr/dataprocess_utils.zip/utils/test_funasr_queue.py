from pydub import AudioSegment
import numpy as np
from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess
import os
import argparse
from collections import defaultdict
import threading
from queue import Queue

def load_wav_scp(wav_scp_path):
    """
    加载 wav.scp 文件
    返回: {wav_id: wav_path} 的字典
    """
    wav_dict = {}
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split('\t')
                if len(parts) >= 2:
                    wav_id = parts[0]
                    wav_path = parts[1]
                    wav_dict[wav_id] = wav_path
    return wav_dict

def load_segments(segments_path):
    """
    加载 segments 文件并按 wav_id 分组
    返回: {wav_id: [(uttid, start, end), ...]} 的字典
    """
    segments_by_wav = defaultdict(list)
    with open(segments_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split()
                if len(parts) >= 4:
                    uttid = parts[0]
                    wav_id = parts[1]
                    start = float(parts[2])
                    end = float(parts[3])
                    segments_by_wav[wav_id].append((uttid, start, end))
    return dict(segments_by_wav)

def process_wav_segments(wav_path, segments_list, target_sr=16000):
    """
    处理单个音频文件的多个段落
    返回: (audio_arrays, uttids)
    """
    try:
        # 加载音频文件
        audio = AudioSegment.from_file(wav_path)
        audio = audio.set_channels(1)  # 转为单通道
        audio = audio.set_frame_rate(target_sr)  # 设置采样率
        
        audio_arrays = []
        uttids = []
        
        # 处理所有段落
        for uttid, start, end in segments_list:
            start_ms = int(start * 1000)
            end_ms = int(end * 1000)
            
            # 切片音频段
            segment = audio[start_ms:end_ms]
            
            # 转换为 numpy 数组
            audio_array = np.array(segment.get_array_of_samples(), dtype=np.float32)
            
            # 归一化到 [-1, 1] 范围
            audio_array = audio_array / 32768.0  # 16位音频的最大值
            
            audio_arrays.append(audio_array)
            uttids.append(uttid)
        
        return audio_arrays, uttids
        
    except Exception as e:
        print(f"Error processing audio file '{wav_path}': {e}")
        return [], []

def audio_loader_thread(wav_dict, segments_by_wav, audio_queue, max_queue_size=2):
    """
    音频预加载线程函数
    将加载好的音频数据放入队列
    """
    for wav_id in segments_by_wav.keys():
        if wav_id not in wav_dict:
            print(f"Warning: wav_id '{wav_id}' not found in wav.scp")
            continue
            
        wav_path = wav_dict[wav_id]
        if not os.path.exists(wav_path):
            print(f"Warning: audio file '{wav_path}' not found")
            continue
        
        segments_list = segments_by_wav[wav_id]
        
        print(f"[Loader] Loading wav_id: {wav_id} ({len(segments_list)} segments)")
        
        # 处理音频文件
        audio_arrays, uttids = process_wav_segments(wav_path, segments_list)
        
        if not audio_arrays:
            print(f"[Loader] No valid segments for wav_id: {wav_id}")
            continue
        
        # 放入队列（如果队列满了会自动阻塞等待）
        audio_queue.put({
            'wav_id': wav_id,
            'wav_path': wav_path,
            'audio_arrays': audio_arrays,
            'uttids': uttids,
            'segment_count': len(segments_list)
        })
        
        print(f"[Loader] Queued wav_id: {wav_id} (queue size: {audio_queue.qsize()})")
    
    # 发送结束信号
    audio_queue.put(None)
    print("[Loader] Loading thread completed")

def run_asr_batch(wav_scp_path, segments_path, output_text_path, 
                  model_name="iic/SenseVoiceSmall", device="cuda:0", 
                  batch_size=16, language="auto", preload_queue_size=2):
    """
    批量语音识别主函数 - 带音频预加载优化
    
    Args:
        preload_queue_size: 预加载队列大小，建议设置为1-3
    """
    # 加载配置文件
    print("Loading wav.scp and segments...")
    wav_dict = load_wav_scp(wav_scp_path)
    segments_by_wav = load_segments(segments_path)
    
    print(f"Loaded {len(wav_dict)} wav files")
    print(f"Found segments for {len(segments_by_wav)} wav_ids")
    
    # 初始化模型
    print("Loading ASR model...")
    model = AutoModel(
        model=model_name,
        device=device,
    )
    
    # 创建音频队列
    audio_queue = Queue(maxsize=preload_queue_size)
    
    # 启动音频加载线程
    print(f"\nStarting audio loader thread (queue size: {preload_queue_size})...")
    loader = threading.Thread(
        target=audio_loader_thread,
        args=(wav_dict, segments_by_wav, audio_queue, preload_queue_size),
        daemon=True
    )
    loader.start()
    
    # 打开输出文件
    with open(output_text_path, 'a', encoding='utf-8') as output_file:
        
        processed_count = 0
        
        # 主循环：从队列中获取预加载的音频数据
        while True:
            # 从队列获取数据（如果队列空会阻塞等待）
            print(f"\n[Main] Waiting for next audio from queue...")
            audio_data = audio_queue.get()
            
            # 检查是否结束
            if audio_data is None:
                print("[Main] Received end signal")
                break
            
            wav_id = audio_data['wav_id']
            wav_path = audio_data['wav_path']
            audio_arrays = audio_data['audio_arrays']
            uttids = audio_data['uttids']
            segment_count = audio_data['segment_count']
            
            print(f"[Main] Processing wav_id: {wav_id} ({segment_count} segments)")
            print(f"[Main] Audio file: {wav_path}")
            print(f"[Main] Generated {len(audio_arrays)} audio segments")
            
            # 对当前 wav_id 的所有段落进行批量推理
            print(f"[Main] Running ASR inference for wav_id: {wav_id}...")
            try:
                res = model.generate(
                    audio_arrays,
                    language=language,
                    cache={},
                    use_itn=True,
                    batch_size=batch_size,
                )
                
                # 写入结果
                for i, result in enumerate(res):
                    if i < len(uttids):
                        uttid = uttids[i]
                        text = result.get('text', '')
                        output_file.write(f"{uttid}\t{text}\n")
                
                output_file.flush()
                processed_count += 1
                print(f"[Main] Completed wav_id: {wav_id} ({len(res)} utterances) - Total processed: {processed_count}")
                
            except Exception as e:
                print(f"[Main] Error during ASR inference for wav_id {wav_id}: {e}")
                continue
    
    # 等待加载线程结束
    loader.join()
    
    print(f"\n{'='*60}")
    print(f"ASR batch processing completed!")
    print(f"Total processed: {processed_count} wav files")
    print(f"Results written to: {output_text_path}")
    print(f"{'='*60}")

def main():
    parser = argparse.ArgumentParser(description='Batch ASR with preloading optimization')
    parser.add_argument('--wav-scp', required=True, help='Path to wav.scp file')
    parser.add_argument('--segments', required=True, help='Path to segments file')
    parser.add_argument('--output-text', required=True, help='Path to output text file')
    parser.add_argument('--model', default='iic/SenseVoiceSmall', help='ASR model name')
    parser.add_argument('--device', default='cuda:0', help='Device to use')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size for ASR inference')
    parser.add_argument('--language', default='auto', help='Language code')
    parser.add_argument('--preload-queue-size', type=int, default=2, 
                        help='Number of audio files to preload (1-3 recommended)')
    
    args = parser.parse_args()
    
    run_asr_batch(
        wav_scp_path=args.wav_scp,
        segments_path=args.segments,
        output_text_path=args.output_text,
        model_name=args.model,
        device=args.device,
        batch_size=args.batch_size,
        language=args.language,
        preload_queue_size=args.preload_queue_size
    )

if __name__ == "__main__":
    main()
    
    # 命令行用法示例:
    # python script.py --wav-scp wav.scp --segments segments --output-text sensevoice.txt --preload-queue-size 2