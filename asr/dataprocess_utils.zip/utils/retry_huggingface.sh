#!/bin/bash

# 定义命令
COMMAND="huggingface-cli download --repo-type dataset --resume-download --token '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' qyang1021/AIR-Bench-Dataset --local-dir /mnt/lustre/wangweifei/asr_datasets/AIR-Bench-Dataset"

# 无限重试直到命令成功
while true; do
    echo "开始下载..."
    $COMMAND
    
    # 检查命令的退出状态
    if [ $? -eq 0 ]; then
        echo "下载成功！"
        break
    else
        echo "下载失败，重新尝试..."
        sleep 2  # 等待5秒后再重试，可以根据需要调整时间
    fi
done


# python /home/share/models/hg_down_V2.py -t datasets -id  qyang1021/AIR-Bench-Dataset -redown 1