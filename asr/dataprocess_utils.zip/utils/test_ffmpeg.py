from subprocess import run, CalledProcessError
import numpy as np


def load_audio(file: str, sr: int = 16000):
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        print(f"Failed to load audio: {e.stderr.decode()}")
        return None  # 返回 None 表示加载音频失败
    return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0

def process_audio_files(files):
    for file in files:
        print(f"process {file}")
        audio_data = load_audio(file)
        if audio_data is None:
            print(f"{audio_data}为空")
            continue  # 跳过处理失败的音频
        # 在这里进行对音频数据的处理
        # 例如，保存到新文件中或者进行其他分析


file = ["/lustre/wangweifei/podcast/f5eae39e-7567-4244-a95b-aa28f6bc8c6a.m4a","/lustre/wangweifei/podcast/ecb0bde9-dbf6-4ddd-9b83-9a6ed0a1bbd5.mp3"]
process_audio_files(file)