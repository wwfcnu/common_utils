#!/bin/bash

# whisper重新启动
# part00
# for i in {1..4};do
#     cat /mnt/lustre/wangweifei/data/part00/whisper/result/output.$i/1best_recog/text >> /mnt/lustre/wangweifei/data/part00/whisper_20240327_text
# done

# # part01

# for i in {1..10};do
#     cat /mnt/lustre/wangweifei/data/part01/whisper/result/output.$i/1best_recog/text >> /mnt/lustre/wangweifei/data/part01/whisper_20240327_text
# done


# # part02

# for i in {1..3};do
#     cat /mnt/lustre/wangweifei/data/part02/whisper/result/output.$i/1best_recog/text >> /mnt/lustre/wangweifei/data/part02/whisper_20240327_text
# done


# 生成新的wav.scp
# datasets="part00 part01 part02"
# for dataset in $datasets;do
#     echo "process $dataset"
#     python retry_wav_scp.py -t /mnt/lustre/wangweifei/data/$dataset/whisper_20240327_text -w /mnt/lustre/wangweifei/data/$dataset/check_audio_clip_wav.scp -r /mnt/lustre/wangweifei/data/$dataset/20240327_whisper_remain_wav.scp
# done


# datasets="part00 part01 part02"
# for dataset in $datasets;do
#     echo "删除 $dataset whisper result"
#     rm -rf /mnt/lustre/wangweifei/data/$dataset/whisper
# done


# paraformer重新启动

# cat /mnt/lustre/wangweifei/data/part00/paraformer/result/output.1/1best_recog/text >> /mnt/lustre/wangweifei/data/part00/paraformer_20240328_text
# cat /mnt/lustre/wangweifei/data/part04/paraformer/result/output.1/1best_recog/text >> /mnt/lustre/wangweifei/data/part04/paraformer_20240328_text

# python retry_wav_scp.py -t /mnt/lustre/wangweifei/data/part00/paraformer_20240328_text -w /mnt/lustre/wangweifei/data/part00/check_audio_clip_wav.scp -r /mnt/lustre/wangweifei/data/part00/20240328_paraformer_remain_wav.scp
# python retry_wav_scp.py -t /mnt/lustre/wangweifei/data/part04/paraformer_20240328_text -w /mnt/lustre/wangweifei/data/part04/check_audio_clip_wav.scp -r /mnt/lustre/wangweifei/data/part04/20240328_paraformer_remain_wav.scp

# rm -rf /mnt/lustre/wangweifei/data/part00/paraformer/result
# rm -rf /mnt/lustre/wangweifei/data/part04/paraformer/result

set -e


# whisper输出路径
utils_dir="/home/wangweifei/repository/wair/asr_project/utils"
output_dir=$1      #/mnt/lustre/wangweifei/data/part00/
remain_wav_scp_file=$2


stage=1 
stop_stage=1
if [ $stage -le 1 ] && [ $stop_stage -ge 1 ];then
    # 合并output.1，output.2，....等等目录下的text
    cat $output_dir/whisper/result/output.*/1best_recog/text >>$output_dir/whisper_temp_text
    cat $output_dir/whisper_temp_text >>$output_dir/whisper_processed_text

    python $utils_dir/retry_wav_scp.py -t $output_dir/whisper_processed_text -w $output_dir/check_audio_clip_wav.scp -r $remain_wav_scp_file


    # rm -rf $output_dir/whisper_temp_text
    # rm -rf $output_dir/whisper
    
fi

#bash retry_asr.sh /mnt/lustre/wangweifei/data/part01 /mnt/lustre/wangweifei/data/part01/remain_whisper_wav.scp
# part00 459454
