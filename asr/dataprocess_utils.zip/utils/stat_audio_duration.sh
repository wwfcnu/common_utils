#!/bin/bash

# ===========================================
# 脚本：递归统计目录下所有 .mp3 和 .m4a 文件的总时长
# 依赖：ffprobe (来自 ffmpeg)
# 作者：AI助手（改进版，修复已知问题）
# ===========================================

# 移除 -e，避免非关键命令的非零状态导致脚本提前退出
set -uo pipefail  # 严格模式（不使用 -e）

TARGET_DIR="${1:-.}"  # 默认当前目录

if [[ ! -d "$TARGET_DIR" ]]; then
    echo "❌ 错误：目录 '$TARGET_DIR' 不存在或不是目录" >&2
    exit 1
fi

if ! command -v ffprobe >/dev/null 2>&1; then
    echo "❌ 错误：未找到 'ffprobe'，请先安装 ffmpeg" >&2
    exit 1
fi

echo "🔍 正在查找 '$TARGET_DIR' 下所有 .mp3 和 .m4a 文件..."
echo

# 用 while+数组代替 mapfile，兼容旧 bash
all_files=()
while IFS= read -r -d '' f; do
    all_files+=("$f")
done < <(find "$TARGET_DIR" -type f \( -iname "*.mp3" -o -iname "*.m4a" \) -print0)

total_found=${#all_files[@]}
if (( total_found == 0 )); then
    echo "⚠️  没有找到任何 .mp3 或 .m4a 文件"
    exit 0
fi

echo "📂 找到 $total_found 个文件，开始统计时长..."
echo

total_seconds=0
file_count=0
error_count=0
processed_count=0

# 简单进度条绘制函数
draw_progress() {
    local current="$1"
    local total="$2"
    local width=40
    local percent=$(( current * 100 / total ))
    local filled=$(( percent * width / 100 ))

    # 构造进度条字符串
    local bar
    local pad
    bar=$(printf '%*s' "$filled" '' | tr ' ' '#')
    pad=$(printf '%*s' $(( width - filled )) '')

    printf "\r🔄 进度: [%s%s] %3d%% (%d/%d)" "$bar" "$pad" "$percent" "$current" "$total"
}

for audio_file in "${all_files[@]}"; do
    [[ -f "$audio_file" ]] || continue

    duration=$(ffprobe -v quiet -show_entries format=duration \
              -of default=noprint_wrappers=1:nokey=1 "$audio_file" 2>/dev/null) || true

    # 改进的数字验证正则表达式，支持 0.123 这样的格式
    if [[ -n "$duration" && "$duration" =~ ^[0-9]*\.?[0-9]+([eE][+-]?[0-9]+)?$ ]]; then
        # 使用 awk 进行浮点数加法，并检查计算是否成功
        new_total=$(awk -v a="$total_seconds" -v b="$duration" 'BEGIN {print a+b}' 2>/dev/null) || {
            echo "⚠️  计算错误，跳过: $audio_file" >&2
            ((error_count++))
            continue
        }
        
        total_seconds="$new_total"
        ((file_count++))
        # 单文件详细输出已注释，避免刷屏
    else
        echo "⚠️  跳过（无法读取时长或格式错误）: $(basename "$audio_file")" >&2
        ((error_count++))
    fi

    ((processed_count++))
    draw_progress "$processed_count" "$total_found"
done

echo  # 进度条换行

# 改进的时间格式化函数，减少精度丢失
format_time() {
    local total_sec="$1"
    # 使用 awk 进行更精确的计算
    awk -v t="$total_sec" '
    BEGIN {
        T = int(t + 0.5)  # 四舍五入到最近的整数
        H = int(T / 3600)
        M = int((T % 3600) / 60)
        S = T % 60
        printf "%02d:%02d:%02d", H, M, S
    }'
}

echo
echo "📊 统计完成！"
echo "📁 目录: $TARGET_DIR"
echo "🎵 成功处理: $file_count 个文件"
echo "⚠️  处理失败: $error_count 个文件"
echo "📝 文件总数: $total_found"
echo "⏱️  总时长（秒）: $(printf "%.2f" "$total_seconds")"
echo "🕒 总时长（时:分:秒）: $(format_time "$total_seconds")"

# 如有错误，告警但仍返回 0，避免中断后续流程
if (( error_count > 0 )); then
    echo
    echo "⚠️  注意：有 $error_count 个文件处理失败，但已完成统计并正常返回"
fi

exit 0