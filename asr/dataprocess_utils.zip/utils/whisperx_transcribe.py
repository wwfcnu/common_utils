import json
import whisperx
import gc
from tqdm import tqdm
def process_audio(audio_file, model, model_a, metadata, diarization_config, device="cuda", batch_size=1):
    # Load audio

    audio = whisperx.load_audio(audio_file)
    
    # Transcribe audio
    result = model.transcribe(audio, batch_size=batch_size)
    
    # Align whisper output
    result = whisperx.align(result["segments"], model_a, metadata, audio, device, return_char_alignments=False)

    # Perform speaker diarization
    diarize_model = whisperx.DiarizationPipeline(diarization_config, device=device)
    diarize_segments = diarize_model(audio)
    result = whisperx.assign_word_speakers(diarize_segments, result)
    
    return result

def load_audio_files_from_wav_scp(wav_scp_path):
    audio_files = []
    with open(wav_scp_path, "r") as file:
        for line in file:
            parts = line.strip().split()
            if len(parts) == 2:
                utterance_id, audio_file = parts
                audio_files.append((utterance_id, audio_file))
    return audio_files

# Load models once and reuse
device = "cuda"
model_path = "/mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/models/whisperx_model/faster-whisper-large-v3"

diarization_config = "/mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/models/pyannote/speaker-diarization-3.1/config.yaml"

model = whisperx.load_model(model_path, device, compute_type="float16", asr_options={
            "initial_prompt": "生于忧患,死于安乐。岂不快哉?当然,嗯,呃,就,这样,那个,哪个,啊,呀,哎呀,哎哟,唉哇,啧,唷,哟,噫!微斯人,吾谁与归?"
        })# asr_options
model_a, metadata = whisperx.load_align_model(language_code="zh", device=device)  

# Load audio files from wav.scp
wav_scp_path = "/mnt/lustre/wangweifei/asr_datasets/donghugaoxin/wav.scp"
audio_files = load_audio_files_from_wav_scp(wav_scp_path)

# List to store all results
all_results = []

# Process each audio file
for utterance_id, audio_file in tqdm(audio_files):
    result = process_audio(
        audio_file=audio_file,
        model=model,
        model_a=model_a,
        metadata=metadata,
        diarization_config=diarization_config
    )
    # Add the utterance_id to the result for identification
    result["utterance_id"] = utterance_id
    all_results.append(result)

# Write all results to a single JSON file
output_file = "all_results.json"
with open(output_file, "w") as f:
    json.dump(all_results, f, indent=4, ensure_ascii=False)

print(f"All results have been written to {output_file}.")
