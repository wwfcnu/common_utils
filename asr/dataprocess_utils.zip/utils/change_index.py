import sys
with open(sys.argv[1],"r") as f:
    lines = f.readlines()

modified_lines = []
count_dict = {}
with open(sys.argv[2],"w") as f:
    for line in lines:
        fields = line.split()
        speaker = fields[1]
    
        if speaker in count_dict:
            count_dict[speaker] += 1
        else:
            count_dict[speaker] = 1

        modified_line = f"{fields[1]}_{count_dict[speaker]} {fields[1]} {fields[2]} {fields[3]}\n"
        f.write(modified_line)


