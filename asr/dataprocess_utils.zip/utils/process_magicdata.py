#!/usr/bin/env python3
"""
Script to parse UTTRANSINFO.txt and generate wav.scp and text files.
wav.scp format: {UTTRANS_ID.replace(".wav","")} {base_dir}/WAV/{SPEAKER_ID}/{UTTRANS_ID}
text format: {UTTRANS_ID.replace(".wav","")} {transcription}
"""

import os
import argparse

def parse_uttransinfo(uttransinfo_path, base_dir):
    """
    Parse UTTRANSINFO.txt and generate wav.scp and text files
    
    Args:
        uttransinfo_path: Path to UTTRANSINFO.txt file
        base_dir: Base directory for WAV files
    """
    wav_scp_lines = []
    text_lines = []
    
    # Skip header line
    header_skipped = False
    
    with open(uttransinfo_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
                
            # Skip the header line
            if not header_skipped:
                header_skipped = True
                continue
                
            parts = line.split('\t')
            if len(parts) < 4:
                parts = line.split()  # Try space-separated if tab-separated fails
                
            if len(parts) >= 4:
                channel, uttrans_id, speaker_id, prompt = parts[0], parts[1], parts[2], parts[3]
                
                # Get transcription (last part)
                transcription = parts[-1] if len(parts) > 4 else ""
                
                # Generate wav.scp line
                uttrans_id_no_ext = uttrans_id.replace(".wav", "")
                wav_path = f"{base_dir}/WAV/{speaker_id}/{uttrans_id}"
                wav_scp_line = f"{uttrans_id_no_ext}\t{wav_path}"
                wav_scp_lines.append(wav_scp_line)
                
                # Generate text line
                text_line = f"{uttrans_id_no_ext}\t{transcription}"
                text_lines.append(text_line)
    
    return wav_scp_lines, text_lines

def write_output_files(wav_scp_lines, text_lines, output_dir):
    """
    Write wav.scp and text files
    
    Args:
        wav_scp_lines: List of lines for wav.scp
        text_lines: List of lines for text
        output_dir: Directory to write output files
    """
    os.makedirs(output_dir, exist_ok=True)
    
    with open(os.path.join(output_dir, 'wav.scp'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(wav_scp_lines)+"\n")
    
    with open(os.path.join(output_dir, 'text'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(text_lines)+"\n")

def main():
    parser = argparse.ArgumentParser(description='Parse UTTRANSINFO.txt and generate wav.scp and text files')
    parser.add_argument('--uttransinfo', type=str, required=True, help='Path to UTTRANSINFO.txt file')
    parser.add_argument('--base_dir', type=str, required=True, help='Base directory for WAV files')
    parser.add_argument('--output_dir', type=str, default='.', help='Directory to write output files')
    
    args = parser.parse_args()
    
    wav_scp_lines, text_lines = parse_uttransinfo(args.uttransinfo, args.base_dir)
    write_output_files(wav_scp_lines, text_lines, args.output_dir)
    
    print(f"Generated wav.scp and text files in {args.output_dir}")

if __name__ == "__main__":
    main()

    # python script.py --uttransinfo /mnt/lustre/wangweifei/asr_datasets/baseline_test_datasets/magicdata_dialect/cantonese/UTTRANSINFO.txt --base_dir /mnt/lustre/wangweifei/asr_datasets/baseline_test_datasets/magicdata_dialect/cantonese --output_dir /output/directory