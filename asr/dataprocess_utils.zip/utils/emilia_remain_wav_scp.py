# 跳过已经处理的目录，生成wav.scp

import os
import sys
import re 


# def processed_item(target_directory):

#     # 获取所有子目录的名称
#     subdirectories = [name for name in os.listdir(target_directory) 
#                   if os.path.isdir(os.path.join(target_directory, name))]
#     return subdirectories
def processed_item(target_directory):
    subdirectories = []
    
    for name in os.listdir(target_directory):
        subdirectory_path = os.path.join(target_directory, name)
        
        if os.path.isdir(subdirectory_path):
            # 检查子目录中是否有大小大于 0 的 .json 文件
            json_files = [f for f in os.listdir(subdirectory_path) 
                          if f.endswith('.json') and os.path.getsize(os.path.join(subdirectory_path, f)) > 20]
            
            if json_files:  # 如果存在大小大于 0 的 .json 文件
                subdirectories.append(name)
    
    return subdirectories
def generate_wav_scp(subdirectories,directory):
    wav_scp_content = ""
    for root, dirs, files in os.walk(directory):
        for file in files:
            #if file.endswith(".m4a") or file.endswith(".mp3") or file.endswith(".wav") or file.endswith(".flac") or file.endswith(".aac"):        #这个需要修改
            if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac")):
                wav_path = os.path.join(root, file)
                if os.path.getsize(wav_path) > 0:  # 检查文件大小是否大于 0
                    utt_id = os.path.splitext(file)[0]
                    if utt_id not in subdirectories:
                        wav_scp_content += f"{utt_id}\t{wav_path}\n"

    return wav_scp_content

def save_wav_scp(wav_scp_content, output_file):
    with open(output_file, "w") as file:
        file.write(wav_scp_content)

def main():
        # 设置包含 WAV 文件的目录
    target_directory = sys.argv[1]  #"/mnt/lustre/wangweifei/asr_datasets/network_datasets/youtube/leaderboard/deyunshexiangsheng_processed"
   
    # 生成 WAV.scp 内容
    subdirectories = processed_item(target_directory)
    #print(subdirectories)

    directory =  sys.argv[2]  #/mnt/lustre/wangweifei/asr_datasets/network_datasets/youtube/leaderboard/deyunshexiangsheng
    wav_scp_content = generate_wav_scp(subdirectories,directory)
    # 设置输出文件路径
    output_file = sys.argv[3]   #"wav.scp"

    # 将 WAV.scp 内容保存到文件
    save_wav_scp(wav_scp_content, output_file)

    print(f"{output_file} 文件已生成。")

if __name__ == "__main__":
    main()

# python emilia_remain_wav_scp.py data_processed data wav.scp