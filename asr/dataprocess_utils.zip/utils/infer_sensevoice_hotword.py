from pathlib import Path
import sys
import os
from typing import Dict, List, Tuple

# Import SenseVoice model
from modelscope import snapshot_download

# Change to your local model directory if already downloaded
# model_dir = snapshot_download('dengcunqin/SenseVoiceSmall_hotword')
model_dir = "/home/wangweifei/.cache/modelscope/hub/dengcunqin/SenseVoiceSmall_hotword"
sys.path.append(model_dir)

from sensevoice_bin_hot import SenseVoiceSmall
from funasr_onnx.utils.postprocess_utils import rich_transcription_postprocess

def read_wavscp(wavscp_path: str) -> Dict[str, str]:
    """Read wav.scp file and return a dictionary of {wav_id: wav_path}"""
    wav_dict = {}
    with open(wavscp_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(maxsplit=1)
            if len(parts) != 2:
                print(f"Warning: Invalid line in wav.scp: {line}", file=sys.stderr)
                continue
            wav_id, wav_path = parts
            wav_dict[wav_id] = wav_path
    return wav_dict

def process_batch(wav_files: List[str], wav_ids: List[str], model, 
                  hotwords_str: str = '', hotwords_score: float = 1.0) -> List[Tuple[str, str]]:
    """Process a batch of wav files and return (wav_id, text) pairs"""
    results = model(wav_files, hotwords_str=hotwords_str, hotwords_score=hotwords_score)
    processed_results = [rich_transcription_postprocess(res) for res in results]
    return list(zip(wav_ids, processed_results))

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Process wav.scp file with SenseVoice ASR')
    parser.add_argument('--wavscp_path','-w', help='Path to wav.scp file')
    parser.add_argument('--output', '-o', help='Output file path (default: stdout)')
    parser.add_argument('--batch_size', '-b', type=int, default=10, help='Batch size for processing')
    parser.add_argument('--hotwords', type=str, default='', help='Hotwords separated by |')
    parser.add_argument('--hotwords_score', type=float, default=1.0, help='Hotwords score')
    args = parser.parse_args()

    # Load model
    print(f"Loading SenseVoice model from {model_dir}...", file=sys.stderr)
    model = SenseVoiceSmall(model_dir, batch_size=args.batch_size, quantize=False)
    
    # Read wav.scp
    wav_dict = read_wavscp(args.wavscp_path)
    print(f"Loaded {len(wav_dict)} utterances from {args.wavscp_path}", file=sys.stderr)
    
    # Prepare output
    outfile = open(args.output, 'w', encoding='utf-8') if args.output else sys.stdout
    
    # Process in batches
    wav_ids = list(wav_dict.keys())
    wav_paths = list(wav_dict.values())
    
    for i in range(0, len(wav_ids), args.batch_size):
        batch_ids = wav_ids[i:i+args.batch_size]
        batch_paths = wav_paths[i:i+args.batch_size]
        
        print(f"Processing batch {i//args.batch_size + 1}/{(len(wav_ids) + args.batch_size - 1)//args.batch_size}...", 
              file=sys.stderr)
        
        results = process_batch(batch_paths, batch_ids, model, 
                               hotwords_str=args.hotwords, 
                               hotwords_score=args.hotwords_score)
        
        # Write results to output
        for wav_id, text in results:
            outfile.write(f"{wav_id}\t{text}\n")
        
        # Flush to ensure partial results are written
        outfile.flush()
    
    if args.output:
        outfile.close()
    print("Done!", file=sys.stderr)

if __name__ == "__main__":
    main()