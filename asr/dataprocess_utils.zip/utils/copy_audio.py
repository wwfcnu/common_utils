import os
import shutil
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm


def copy_one(uttid, uttid_to_wav, src_prefix, dst_prefix):
    """复制单个文件，返回结果 (uttid, success, msg)"""
    if uttid not in uttid_to_wav:
        return uttid, False, f"not found in wav.scp"

    src_path = uttid_to_wav[uttid]

    # 检查路径是否以 src_prefix 开头
    if not src_path.startswith(src_prefix):
        return uttid, False, f"src path {src_path} does not start with {src_prefix}"

    # 替换前缀，得到目标路径
    rel_path = src_path[len(src_prefix):]  # 去掉前缀，保留相对路径
    dst_path = os.path.join(dst_prefix, rel_path)

    # 创建目标目录
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)

    # 检查源文件是否存在
    if not os.path.exists(src_path):
        return uttid, False, f"source file {src_path} does not exist"

    # 复制文件（保留元数据）
    shutil.copy2(src_path, dst_path)
    return uttid, True, f"Copied: {src_path} -> {dst_path}"


def main():
    parser = argparse.ArgumentParser(description="批量复制音频文件并保持目录结构")
    parser.add_argument("--wav-scp", required=True, help="wav.scp 文件路径")
    parser.add_argument("--select", required=True, help="select_xxx.txt 文件路径")
    parser.add_argument("--src-prefix", required=True, help="原始音频根目录前缀")
    parser.add_argument("--dst-prefix", required=True, help="目标根目录前缀")
    parser.add_argument("--num-workers", type=int, default=8, help="并发线程数")
    args = parser.parse_args()

    # 读取 select.txt
    with open(args.select, 'r', encoding='utf-8') as f:
        selected_uttids = set(line.strip() for line in f if line.strip())

    # 读取 wav.scp
    uttid_to_wav = {}
    with open(args.wav_scp, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split(maxsplit=1)
            if len(parts) < 2:
                continue
            uttid, wav_path = parts
            uttid_to_wav[uttid] = wav_path

    copied_count = 0
    not_found_count = 0

    # 多线程执行复制任务 + 进度条
    with ThreadPoolExecutor(max_workers=args.num_workers) as executor:
        futures = {
            executor.submit(copy_one, uttid, uttid_to_wav, args.src_prefix, args.dst_prefix): uttid
            for uttid in selected_uttids
        }

        with tqdm(total=len(futures), desc="Copying files", unit="file") as pbar:
            for future in as_completed(futures):
                uttid = futures[future]
                try:
                    uttid, success, msg = future.result()
                    if success:
                        copied_count += 1
                        # 可以去掉详细日志，只保留错误
                        # print(f"✅ {msg}")
                    else:
                        not_found_count += 1
                        print(f"⚠️  {uttid} skipped: {msg}")
                except Exception as e:
                    not_found_count += 1
                    print(f"❌ Error processing {uttid}: {e}")
                finally:
                    pbar.update(1)

    print(f"\n📋 Summary:")
    print(f"   ✅ Successfully copied: {copied_count}")
    print(f"   ⚠️  Skipped (not found / invalid): {not_found_count}")
    print(f"   📁 Target root: {args.dst_prefix}")


if __name__ == "__main__":
    main()
