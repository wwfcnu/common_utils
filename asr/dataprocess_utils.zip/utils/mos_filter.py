import argparse
import pandas as pd

def main(args):
    # Reading command-line arguments
    mos_csv_file = args.mos_csv_file
    mos_greater_csv_file = args.mos_greater_csv_file
    wav_scp_file = args.wav_scp_file
    mos_wav_scp_file = args.mos_wav_scp_file

    mos_score = 3.4
    
    # Reading CSV file
    df = pd.read_csv(mos_csv_file)

    # Filtering rows where mos >= mos_score
    mos_df = df[df['P808_MOS'] >= float(mos_score)]

    # Saving filtered rows to a new CSV file
    mos_df.to_csv(mos_greater_csv_file, index=False)

    # Extracting wav IDs where mos >= mos_score
    wav_id_mos = [file.split("/")[-1].split(".")[0] for file in mos_df["filename"].tolist()]

    # Filtering wav.scp file based on the selected wav IDs
    with open(wav_scp_file) as f, open(mos_wav_scp_file, "w") as w:
        for line in f:
            line = line.strip()
            wav_id, wav_path = line.split()
            if wav_id in wav_id_mos:
                w.write(f"{line}\n")

    # Statistics
    mos_count = mos_df.shape[0]
    mos_percentage = (mos_count / df.shape[0]) * 100
    mos_duration = mos_df['len_in_sec'].sum()
    total_duration = df['len_in_sec'].sum()
    mos_duration_percentage = (mos_duration / total_duration) * 100

    print(f"mos >= {mos_score} 的音频个数：", mos_count)
    print(f"mos >= {mos_score} 的音频个数占总条数的百分比：", mos_percentage)
    print(f"mos >= {mos_score} 的音频时长：", mos_duration, "秒")
    print(f"mos >= {mos_score} 的音频时长占总时长的比例：", mos_duration_percentage)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process MOS files and WAV files.')
    parser.add_argument('--mos_csv_file', '-mos', type=str, help='Path to the MOS CSV file')
    parser.add_argument('--mos_greater_csv_file', '-fmos', type=str, help='Path to save filtered MOS CSV file')
    parser.add_argument('--wav_scp_file', '-w', type=str, help='Path to the WAV SCP file')
    parser.add_argument('--mos_wav_scp_file', '-wmos', type=str, help='Path to save filtered WAV SCP file')

    args = parser.parse_args()
    main(args)