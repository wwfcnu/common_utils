#!/usr/bin/env python3
import os
import random

def split_data(wav_scp_path, text_path, output_dir, dev_size=1500, seed=42):
    """
    将数据集分为训练集和开发集
    
    参数:
    wav_scp_path: wav.scp文件路径，格式为 {wav_id} {wav_path}
    text_path: text文件路径，格式为 {wav_id} {text}
    output_dir: 输出目录
    dev_size: 开发集大小，默认为1500
    seed: 随机种子，默认为42
    """
    # 设置随机种子以确保结果可复现
    random.seed(seed)
    
    # 创建输出目录结构
    os.makedirs(output_dir, exist_ok=True)
    train_dir = os.path.join(output_dir, "train")
    dev_dir = os.path.join(output_dir, "dev")
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(dev_dir, exist_ok=True)
    
    # 读取wav.scp文件
    wav_ids = []
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split(maxsplit=1)
            if len(parts) == 2:
                wav_id = parts[0]
                wav_ids.append(wav_id)
    
    # 随机选择dev_size个wav_id作为开发集
    total_samples = len(wav_ids)
    if dev_size >= total_samples:
        raise ValueError(f"开发集大小({dev_size})大于或等于总样本数({total_samples})")
    
    dev_ids = set(random.sample(wav_ids, dev_size))
    train_ids = set(wav_ids) - dev_ids
    
    print(f"总样本数: {total_samples}")
    print(f"训练集大小: {len(train_ids)}")
    print(f"开发集大小: {len(dev_ids)}")
    
    # 根据划分结果创建train和dev的wav.scp和text文件
    subset_dirs = {"train": train_dir, "dev": dev_dir}
    subset_ids = {"train": train_ids, "dev": dev_ids}
    
    for subset, ids in subset_ids.items():
        subset_dir = subset_dirs[subset]
        
        # 创建wav.scp文件
        with open(os.path.join(subset_dir, "wav.scp"), 'w', encoding='utf-8') as out_wav:
            with open(wav_scp_path, 'r', encoding='utf-8') as in_wav:
                for line in in_wav:
                    parts = line.strip().split(maxsplit=1)
                    if len(parts) == 2 and parts[0] in ids:
                        out_wav.write(line)
        
        # 创建text文件
        with open(os.path.join(subset_dir, "text"), 'w', encoding='utf-8') as out_text:
            with open(text_path, 'r', encoding='utf-8') as in_text:
                for line in in_text:
                    parts = line.strip().split(maxsplit=1)
                    if len(parts) == 2 and parts[0] in ids:
                        out_text.write(line)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="将数据集分为训练集和开发集")
    parser.add_argument("--wav-scp", required=True, help="wav.scp文件路径")
    parser.add_argument("--text", required=True, help="text文件路径")
    parser.add_argument("--output-dir", required=True, help="输出目录")
    parser.add_argument("--dev-size", type=int, default=1500, help="开发集大小，默认为1500")
    parser.add_argument("--seed", type=int, default=42, help="随机种子，默认为42")
    
    args = parser.parse_args()
    
    split_data(args.wav_scp, args.text, args.output_dir, args.dev_size, args.seed)