#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MP3到WAV转换脚本
使用pydub将mp3文件转换为16kHz采样率的单声道wav文件
"""

import os
import sys
import argparse
from pathlib import Path
from pydub import AudioSegment
from multiprocessing import Pool, cpu_count
from functools import partial
import time


def convert_single_file(args_tuple):
    """
    转换单个文件的包装函数，用于多进程处理
    
    Args:
        args_tuple: (wav_id, wav_path, output_dir, keep_structure)
    
    Returns:
        tuple: (wav_id, success, error_msg)
    """
    wav_id, wav_path, output_dir, keep_structure = args_tuple
    
    try:
        # 检查输入文件是否存在
        if not os.path.exists(wav_path):
            return (wav_id, False, f"输入文件不存在: {wav_path}")
        
        # 检查是否为mp3文件
        if not wav_path.lower().endswith('.mp3'):
            return (wav_id, False, f"跳过非mp3文件: {wav_path}")
        
        # 确定输出路径
        if keep_structure:
            # 保持目录结构
            rel_path = os.path.relpath(wav_path)
            output_path = Path(output_dir) / os.path.dirname(rel_path) / f"{wav_id}.wav"
        else:
            # 所有文件输出到同一目录
            output_path = Path(output_dir) / f"{wav_id}.wav"
        
        # 转换文件
        success = convert_mp3_to_wav(wav_path, str(output_path))
        
        if success:
            return (wav_id, True, None)
        else:
            return (wav_id, False, "转换失败")
            
    except Exception as e:
        return (wav_id, False, f"处理异常: {str(e)}")


def convert_mp3_to_wav(input_path, output_path):
    """
    将mp3文件转换为16kHz单声道wav文件
    
    Args:
        input_path (str): 输入mp3文件路径
        output_path (str): 输出wav文件路径
    
    Returns:
        bool: 转换是否成功
    """
    try:
        # 加载mp3文件
        audio = AudioSegment.from_mp3(input_path)
        
        # 转换为单声道
        audio = audio.set_channels(1)
        
        # 设置采样率为16kHz
        audio = audio.set_frame_rate(16000)
        
        # 确保输出目录存在
        output_dir = os.path.dirname(output_path)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        # 导出为wav格式
        audio.export(output_path, format="wav")
        
        return True
        
    except Exception as e:
        return False


def parse_wav_scp(scp_file):
    """
    解析wav.scp文件
    
    Args:
        scp_file (str): scp文件路径
    
    Returns:
        dict: {wav_id: wav_path} 的字典
    """
    wav_dict = {}
    
    try:
        with open(scp_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # 分割wav_id和wav_path
                parts = line.split(None, 1)  # 只分割一次，防止路径中有空格
                if len(parts) != 2:
                    print(f"警告: 第{line_num}行格式不正确: {line}")
                    continue
                
                wav_id, wav_path = parts
                wav_dict[wav_id] = wav_path
                
    except FileNotFoundError:
        print(f"错误: 找不到文件 {scp_file}")
        sys.exit(1)
    except Exception as e:
        print(f"错误: 读取文件 {scp_file} 时出错: {str(e)}")
        sys.exit(1)
    
    return wav_dict


def main():
    parser = argparse.ArgumentParser(
        description="将mp3文件批量转换为16kHz单声道wav文件",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
    使用示例:
    python convert_mp3_to_wav.py wav.scp /path/to/output/dir
    python convert_mp3_to_wav.py --scp-file data/wav.scp --output-dir ./wav_output --jobs 8
        """
    )
    
    parser.add_argument('scp_file', help='输入的wav.scp文件路径')
    parser.add_argument('output_dir', help='输出目录路径')
    parser.add_argument('--keep-structure', action='store_true', 
                       help='保持原有的目录结构（默认所有文件输出到同一目录）')
    parser.add_argument('--jobs', '-j', type=int, default=4,
                       help=f'并行进程数（默认: {cpu_count()}）')
    
    args = parser.parse_args()
    
    # 检查输入文件
    if not os.path.exists(args.scp_file):
        print(f"错误: 输入文件不存在: {args.scp_file}")
        sys.exit(1)
    
    # 创建输出目录
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 解析scp文件
    print(f"正在解析文件: {args.scp_file}")
    wav_dict = parse_wav_scp(args.scp_file)
    
    if not wav_dict:
        print("错误: 没有找到有效的音频文件记录")
        sys.exit(1)
    
    print(f"找到 {len(wav_dict)} 个音频文件")
    print(f"使用 {args.jobs} 个进程进行转换...")
    
    # 准备任务参数
    tasks = []
    for wav_id, wav_path in wav_dict.items():
        tasks.append((wav_id, wav_path, str(output_dir), args.keep_structure))
    
    # 开始多进程转换
    start_time = time.time()
    
    # 转换统计
    success_count = 0
    fail_count = 0
    
    with Pool(processes=args.jobs) as pool:
        results = pool.map(convert_single_file, tasks)
    
    # 处理结果
    for wav_id, success, error_msg in results:
        if success:
            print(f"✓ 转换成功: {wav_id}")
            success_count += 1
        else:
            print(f"✗ 转换失败: {wav_id} - {error_msg}")
            fail_count += 1
    
    # 计算耗时
    elapsed_time = time.time() - start_time
    
    # 输出统计结果
    print(f"\n转换完成:")
    print(f"  成功: {success_count} 个文件")
    print(f"  失败: {fail_count} 个文件")
    print(f"  总耗时: {elapsed_time:.2f} 秒")
    print(f"  平均速度: {len(wav_dict)/elapsed_time:.2f} 文件/秒")
    print(f"  输出目录: {output_dir.absolute()}")
    
    if fail_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
    #python convert_mp3_to_wav.py wav.scp /path/to/output/dir --jobs 8


