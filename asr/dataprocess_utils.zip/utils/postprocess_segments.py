# 对segments进行平滑处理，注意相邻的segment区间不能间隔太大，太大取中间点就会出问题。

def smooth_segments(input_file, output_file):
    # 读取输入文件
    with open(input_file, 'r', encoding='utf-8') as f:
        input_lines = f.readlines()
    
    # 按wav_id分组存储segments
    wav_segments = {}
    for line in input_lines:
        uutid, wav_id, start, end = line.strip().split()
        if wav_id not in wav_segments:
            wav_segments[wav_id] = []
        wav_segments[wav_id].append({
            'uutid': uutid,
            'wav_id': wav_id,
            'start': float(start),
            'end': float(end)
        })
    
    # 对每个wav_id的segments进行平滑处理
    smoothed_lines = []
    for wav_id, segments in wav_segments.items():
        # 按start时间排序
        segments.sort(key=lambda x: x['start'])
        
        # 处理每个wav_id内的相邻segments
        for i in range(len(segments) - 1):
            current_seg = segments[i]
            next_seg = segments[i + 1]
            
            # 计算中间点
            mid_point = (current_seg['end'] + next_seg['start']) / 2
            
            # 更新当前segment的end和下一个segment的start
            current_seg['end'] = mid_point
            next_seg['start'] = mid_point
        
        # 将处理后的segments添加到结果中
        for seg in segments:
            smoothed_lines.append(f"{seg['uutid']} {seg['wav_id']} {seg['start']:.2f} {seg['end']:.2f}")
    
    # 写入输出文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for line in smoothed_lines:
            f.write(line + '\n')

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python script.py input_segments output_segments")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    smooth_segments(input_file, output_file)