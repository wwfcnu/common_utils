#!/usr/bin/env bash

set -e
# set -u
set -o pipefail

stage=1
stop_stage=2

# 环境
source /mnt/lustre/wangweifei/repository/miniconda3/etc/profile.d/conda.sh
conda activate AudioPipeline
export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/miniconda3/envs/AudioPipeline/lib/python3.9/site-packages/nvidia/cudnn/lib:$LD_LIBRARY_PATH

# gpu3上额外加上
# export PATH=/usr/local/cuda-11.8/bin:$PATH
# export LD_LIBRARY_PATH=/usr/local/cuda-11.8/lib64:$LD_LIBRARY_PATH

# H800加上
# export PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/bin:$PATH
# export LD_LIBRARY_PATH=/mnt/lustre/wangweifei/repository/cuda-11.4/lib64:$LD_LIBRARY_PATH
# export PYTHONIOENCODING=utf-8



# 参数设置 注意采样率的选择，是用A800_main.py还是A800_main_sr.py
wav_scp=$1    #"wav.scp"
wav_dir=$(dirname "$wav_scp")

# 先删除split和log以及wav.scp.new
rm -rf $wav_dir/split
# 创建
mkdir -p $wav_dir/split

wav_scp_new="${wav_dir}/split/wav.scp.new"
output_dir=$2
# config_path=$3  #config_44.1k.json
gpuid_list=$3
gpu_inference=true
njob=1    # the number of jobs for CPU decoding, if gpu_inference=false, use CPU decoding, please set njob


# 跳过已经处理的wav_id,生成新的wav.scp.new

declare -A processed_map
# 首先计算总目录数
total_dirs=$(find "${output_dir}" -mindepth 1 -maxdepth 1 -type d | wc -l)
echo "Total directories: $total_dirs"
current=0

# 遍历子目录
for subdir in "${output_dir}"/*; do
    if [[ -d "$subdir" ]]; then
        # 更新进度
        current=$((current + 1))
        percentage=$((current * 100 / total_dirs))
        printf "\rProgress: [%-50s] %d%%" $(printf "#%.0s" $(seq 1 $((percentage / 2)))) $percentage

        # 获取子目录名
        sub_dirname=$(basename "$subdir")
        
        # JSON 文件路径
        json_file="${subdir}/${sub_dirname}.json"
        
        # 检查文件是否存在并且大小大于 20 字节
        if [[ -f "$json_file" && $(stat -c%s "$json_file") -gt 20 ]]; then
            # 记录处理状态
            processed_map["$sub_dirname"]=1
            # echo "Processed: $json_file (ID: $sub_dirname)"  # 打印处理日志
        else
            echo "Skipped: $json_file (Not found or too small)"
        fi
    fi
done


# Process wav.scp and create new wav.scp.new
while IFS=$'\t ' read -r wav_id wav_path; do
    # Check if current wav_id is already processed
    if [ -z "${processed_map[$wav_id]}" ]; then
        echo -e "${wav_id}\t${wav_path}" >> "$wav_scp_new"
    fi
done < "$wav_scp"

. ./parse_options.sh || exit 1;

if ${gpu_inference} == "true"; then
    nj=$(echo $gpuid_list | awk -F "," '{print NF}')
else
    nj=$njob
    batch_size=1
    gpuid_list=""
    for JOB in $(seq ${nj}); do
        gpuid_list=$gpuid_list"-1,"
    done
fi

mkdir -p $wav_dir/split
split_scps=""
for JOB in $(seq ${nj}); do
    split_scps="$split_scps $wav_dir/split/wav.$JOB.scp"
done
perl ./split_scp.pl ${wav_scp_new} ${split_scps}


if [ $stage -le 1 ] && [ $stop_stage -ge 1 ];then
    echo "Decoding ..."
    gpuid_list_array=(${gpuid_list//,/ })
    for JOB in $(seq ${nj}); do
        {
        id=$((JOB-1))
        gpuid=${gpuid_list_array[$id]}

        cd /mnt/lustre/wangweifei/repository/Amphion/preprocessors/Emilia/


        export CUDA_VISIBLE_DEVICES=$gpuid
        # 采样率的选择
        python A800_main_sr.py \
            --input_folder_path ${wav_dir}/split/wav.$JOB.scp \
            --output_dir ${output_dir} > ${wav_dir}/split/job_${JOB}.log  2>&1
        }&
    done
    wait
fi
