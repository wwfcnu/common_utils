import argparse
import glob
import os
def main(old_wav_scp_file, new_wav_scp_file, wav_dir):

    processed_wav = set()
    with open(old_wav_scp_file) as f:
        for line in f:
            wav_id, wav_path = line.strip().split()
            processed_wav.add(wav_id)

    file_list = glob.glob(wav_dir + "/*.wav")

    # Check if directory for new_wav_scp_file exists, if not, create it
    new_wav_dir = os.path.dirname(new_wav_scp_file)
    os.makedirs(new_wav_dir, exist_ok=True)

    with open(new_wav_scp_file, 'w') as w:
        for file in file_list:
            wav_id = file.split("/")[-1].split(".")[0]
            if wav_id not in processed_wav:
                w.write(f"{wav_id}\t{file}\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process WAV files.")
    parser.add_argument("-o", "--old", required=True, help="Path to the old WAV SCP file")
    parser.add_argument("-n", "--new", required=True, help="Path to the new WAV SCP file")
    parser.add_argument("-d", "--dir", default="/mnt/lustre/chentingwei/tv_drama_sep", help="Directory containing WAV files")
    args = parser.parse_args()

    main(args.old, args.new, args.dir)
