import os
import glob
import concurrent.futures
from tqdm import tqdm
import subprocess
def extract_audio(video_path,output_file):
    try:
        #command = ["ffmpeg", "-i", video_path, output_file]
        command = ["ffmpeg", "-i", video_path, "-vn", "-acodec", "aac", output_file]
        subprocess.run(command, stderr=subprocess.DEVNULL)
    except Exception as e:
        print(f"提取{video_path}失败")

def main(video_path):
    aweme_id = video_path.split("/")[-1].split(".")[0]
    output_dir = os.path.dirname(video_path)
    os.makedirs(output_dir,exist_ok=True)
    output_file = os.path.join(output_dir,f"{aweme_id}.m4a")
    #print(output_file)
    if not os.path.exists(output_file):  # Check if the output file already exists
        extract_audio(video_path, output_file)
    else:
        print(f"{output_file} 已存在，跳过提取。")

if __name__ == "__main__":

    usernames = ["xiaozhupeiqi"]
    for username in usernames:
        print(f"正在提取的用户{username}")
        video_list = glob.glob(f"/obsfs/asr_datasets/network_datasets/leaderboard/{username}/*.webm")
        max_workers = 10  
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            list(tqdm(executor.map(main,video_list),total=len(video_list)))