from pypinyin import pinyin, lazy_pinyin, Style
a = pinyin('我数了数树上的果子', style=Style.TONE3, heteronym=True)
a = lazy_pinyin('我数了数树上的果子', style=Style.TONE3, tone_sandhi=True)
print(a)


# https://github.com/mozillazg/python-pinyin
# https://github.com/BarryKCL/g2pW
# https://github.com/PaddlePaddle/PaddleSpeech/blob/develop/paddlespeech/t2s/frontend/g2pw  文本前端 tn和g2p
# https://huggingface.co/cisco-ai/mini-bart-g2p
# https://github.com/RVC-Boss/GPT-SoVITS/tree/main/GPT_SoVITS/text/g2pw
