#!/usr/bin/env bash

set -e
set -u
set -o pipefail

stage=1
stop_stage=2
part=$1
model="iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-pytorch"
data_dir="/mnt/lustre/wangweifei/tv_drama_meta/$part"
output_dir="/mnt/lustre/wangweifei/tv_drama_meta/$part/paraformer/result"
batch_size=64
gpu_inference=true    # whether to perform gpu decoding
gpuid_list="0"    # set gpus, e.g., gpuid_list="0,1"
njob=1    # the number of jobs for CPU decoding, if gpu_inference=false, use CPU decoding, please set njob


. ./parse_options.sh || exit 1;

if ${gpu_inference} == "true"; then
    nj=$(echo $gpuid_list | awk -F "," '{print NF}')
else
    nj=$njob
    batch_size=1
    gpuid_list=""
    for JOB in $(seq ${nj}); do
        gpuid_list=$gpuid_list"-1,"
    done
fi

mkdir -p $output_dir/split
split_scps=""
for JOB in $(seq ${nj}); do
    split_scps="$split_scps $output_dir/split/wav.$JOB.scp"
done
perl ./split_scp.pl ${data_dir}/check_audio_clip_wav.scp ${split_scps}


if [ $stage -le 1 ] && [ $stop_stage -ge 1 ];then
    echo "Decoding ..."
    gpuid_list_array=(${gpuid_list//,/ })
    for JOB in $(seq ${nj}); do
        {
        id=$((JOB-1))
        gpuid=${gpuid_list_array[$id]}
        mkdir -p ${output_dir}/output.$JOB
        python infer_paraformer.py \
            --model ${model} \
            --input ${output_dir}/split/wav.$JOB.scp \
            --output_dir ${output_dir}/output.$JOB \
            --batch_size ${batch_size} \
            --gpuid ${gpuid}
        }&
    done
    wait

    mkdir -p ${output_dir}/1best_recog
    for f in text; do
        if [ -f "${output_dir}/output.1/1best_recog/${f}" ]; then
          for i in $(seq "${nj}"); do
              cat "${output_dir}/output.${i}/1best_recog/${f}"
          done | sort -k1 >"${output_dir}/1best_recog/${f}"
        fi
    done
fi


