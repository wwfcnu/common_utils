# # tn usage
# from tn.chinese.normalizer import Normalizer
# normalizer = Normalizer(cache_dir="/mnt/lustre/wangweifei/repository/WeTextProcessing/tn")
# # normalizer.normalize("2.5平方电线")
# # itn usage
# # >>> from itn.chinese.inverse_normalizer import InverseNormalizer
# # >>> invnormalizer = InverseNormalizer(cache_dir="PATH_TO_GIT_CLONED_WETEXTPROCESSING/itn")
# # >>> invnormalizer.normalize("二点五平方电线")

# import sys
# # Path to your input text file and output file
# input_file = sys.argv[1]#'/mnt/lustre/wangweifei/repository/asr/data/test_tts/text'
# output_file = sys.argv[2]'/mnt/lustre/wangweifei/repository/asr/data/test_tts/text.tn'

# # Open the input file and process each line
# with open(input_file, 'r', encoding='utf-8') as infile, open(output_file, 'w', encoding='utf-8') as outfile:
#     for line in infile:
#         # Split line to separate the ID and text
#         id_part, text = line.strip().split('\t', 1)
        
#         # Perform normalization
#         normalized_text = normalizer.normalize(text)
        
#         # Write the result to the output file with original ID
#         outfile.write(f"{id_part}\t{normalized_text}\n")

import sys
import csv
import argparse
from tn.chinese.normalizer import Normalizer
from itn.chinese.inverse_normalizer import InverseNormalizer
import sys, os, argparse

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('ifile', help='input filename, assume utf-8 encoding')
    p.add_argument('ofile', help='output filename')
    p.add_argument('--to_upper', action='store_true', help='convert to upper case')
    p.add_argument('--to_lower', action='store_true', help='convert to lower case')
    p.add_argument('--has_key', action='store_true', help="input text has Kaldi's key as first field.")
    p.add_argument('--log_interval', type=int, default=10000, help='log interval in number of processed lines')
    args = p.parse_args()

    normalizer = Normalizer(cache_dir="/mnt/lustre/wangweifei/repository/WeTextProcessing/tn")

    n = 0
    with open(args.ifile, 'r',  encoding = 'utf8') as fi, open(args.ofile, 'w+', encoding = 'utf8') as fo:
        for line in fi:
            if args.has_key:
                cols = line.strip().split(maxsplit=1)
                key, text = cols[0].strip(), cols[1].strip() if len(cols) == 2 else ''
            else:
                text = line.strip()

            # wetextprocessing
            text = normalizer.normalize(text)


            # Cases
            if args.to_upper and args.to_lower:
                sys.stderr.write('text norm: to_upper OR to_lower?')
                exit(1)
            if args.to_upper:
                text = text.upper()
            if args.to_lower:
                text = text.lower()

            if args.has_key:
                print(key + '\t' + text, file = fo)
            else:
                print(text, file = fo)

            n += 1
            if n % args.log_interval == 0:
                print(f'text norm: {n} lines done.', file = sys.stderr)
    print(f'text norm: {n} lines done in total.', file = sys.stderr)
