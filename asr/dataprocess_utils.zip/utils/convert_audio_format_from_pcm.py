import os
import subprocess
import argparse
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ProcessPoolExecutor
from tqdm import tqdm  # 导入tqdm库
executor = ProcessPoolExecutor(max_workers=4)
def convert_single_file(wav_path):
    try:
        # 设置输出MP3文件名和路径
        # output_filename = os.path.basename(wav_path).replace('.pcm', '.mp3')
        # output_path = os.path.join(output_directory, output_filename)
        dataset = wav_path.split("/")[-3]
        output_path = wav_path.replace('.pcm', '.mp3').replace(dataset,f"{dataset}_mp3")
        os.makedirs(os.path.dirname(output_path),exist_ok=True)
        # 使用ffmpeg转换pcm到mp3，屏蔽输出
        command = ['ffmpeg', '-f', 's16le', '-ar', '16000', '-ac', '1', '-i', wav_path, output_path]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # 屏蔽输出
        
        # 如果成功，不返回任何信息
        return None
    except subprocess.CalledProcessError as e:
        return f"转换失败: {wav_path}. 错误: {e}"
    except Exception as e:
        return f"发生未知错误处理文件 {wav_path}: {e}"

def convert_pcm_to_mp3(wav_scp_path):
    # 创建输出目录（如果不存在）
    # os.makedirs(output_directory, exist_ok=True)

    # 读取wav.scp文件
    with open(wav_scp_path, 'r') as file:
        lines = file.readlines()

    wav_files = [line.strip().split('\t')[1] for line in lines]
    
    # 使用线程池进行多线程处理
    futures = []
    # with ThreadPoolExecutor(max_workers=num_threads) as executor:
    # 使用tqdm显示提交任务进度
    for wav_file in tqdm(wav_files, desc="提交转换任务"):
        # futures.append(executor.submit(convert_single_file, wav_file, output_directory))
        futures.append(executor.submit(convert_single_file, wav_file))

    # 获取结果并显示进度
    results = [future.result() for future in tqdm(futures, desc="处理转换结果")]
    
    # 仅打印失败的结果
    for result in results:
        if result is not None:
            print(result)



if __name__ == "__main__":
    # 设置argparse
    parser = argparse.ArgumentParser(description="Convert PCM audio files to MP3 format.")
    parser.add_argument('-w', '--wav_scp', type=str, required=True, help='Path to the wav.scp file.')
    # parser.add_argument('-o', '--output_dir', type=str, required=True, help='Directory to save converted MP3 files.')
    # parser.add_argument('-t', '--threads', type=int, default=4, help='Number of threads to use for conversion.')

    # 解析命令行参数
    args = parser.parse_args()

    # 调用转换函数
    # convert_pcm_to_mp3(args.wav_scp, args.output_dir)
    convert_pcm_to_mp3(args.wav_scp)
