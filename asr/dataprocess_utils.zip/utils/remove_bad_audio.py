import glob
import soundfile as sf
import argparse
import os
from tqdm import tqdm

from concurrent.futures import ProcessPoolExecutor
from multiprocessing import cpu_count
from functools import partial

executor = ProcessPoolExecutor(max_workers=cpu_count())


def remove_bad_flac(file_path):
    try:
        wav = sf.read(file_path)
    except:
        print(file_path)
        # os.remove(file_path)

def check_bad_wav(file_path):
    duration_threshold = 0.4       # 给定阈值
    try:
        data, sr = sf.read(file_path, dtype='int16')
        assert sr == 16000
        duration = (len(data)) / 16000
        if duration < duration_threshold:
            print(f"时长小于0.4s{file_path}")
            os.remove(file_path)

    except:
        print(f"文件读取失败：{file_path}")
        os.remove(file_path)

def check_duration(file_path, save_long_file, save_short_file):
    duration_threshold = 1.0
    try:
        data, sr = sf.read(file_path, dtype='int16')
        assert sr == 16000
        duration = (len(data)) / 16000
        filename = file_path.split("/")[-1].split(".")[0]
        # speaker_id = file_path.split("/")[-2]
        # uttid = f"{speaker_id}_{filename}"
        uttid = filename
        if duration < duration_threshold:
            print(f"时长小于1.0s {file_path}")
        else:
            if duration > 30:
                with open(save_long_file, 'a') as f:
                    f.write(f"{uttid}\t{file_path}\n")
                print(f"{duration}, 时长大于30s {file_path}")
            else:
                with open(save_short_file, 'a') as f:
                    f.write(f"{uttid}\t{file_path}\n")
    except:
        print(f"文件读取失败：{file_path}")

def main():
    parser = argparse.ArgumentParser(description='Remove bad FLAC files.')
    parser.add_argument('--dir', type=str, default='data/flac',
                        help='dir to the FLAC files.')
    args = parser.parse_args()
    data_dir = args.dir
    wav_files = glob.glob(data_dir + '/**/*.mp3', recursive=True)
    futures = []
    for wav_file in tqdm(wav_files):
        futures.append(executor.submit(remove_bad_flac, wav_file))
    result = [future.result() for future in tqdm(futures)]

def main_new():
    parser = argparse.ArgumentParser(description='Remove bad FLAC files.')
    parser.add_argument('--dir', type=str, default='data/flac',
                        help='dir to the FLAC files.')
    args = parser.parse_args()
    data_dir = args.dir
    wav_files = glob.glob(data_dir + '/**/*.mp3', recursive=True)
    futures = []
    for wav_file in tqdm(wav_files):
        futures.append(executor.submit(check_bad_wav, wav_file))
    result = [future.result() for future in tqdm(futures)]


def test():
    parser = argparse.ArgumentParser(description='Check and save long duration FLAC files.')
    parser.add_argument('-d','--dir', type=str, default='data/flac', help='Directory containing the FLAC files.')
    parser.add_argument('-sl','--save_long', type=str, default='long_duration_files.txt', help='File to save records of long duration audio files.')
    parser.add_argument('-ss','--save_short', type=str, default='short_duration_files.txt', help='File to save records of short duration audio files.')
    args = parser.parse_args()
    
    data_dir = args.dir
    save_long_file = args.save_long
    save_short_file = args.save_short
    
    wav_files = glob.glob(data_dir + '/meta_app*_mp3/**/*.mp3', recursive=True)
    futures = []
    for wav_file in tqdm(wav_files):
        futures.append(executor.submit(check_duration, wav_file, save_long_file, save_short_file))
    result = [future.result() for future in tqdm(futures)]

if __name__ == '__main__':
    # main_new()
    test()
    # main()