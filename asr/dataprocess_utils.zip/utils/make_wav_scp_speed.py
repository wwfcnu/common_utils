import os
import argparse

def generate_wav_scp(root_dir, output_file):
    with open(output_file, 'w') as f:
        total_dirs = sum(len(dirs) for _, dirs, _ in os.walk(root_dir))
        processed_dirs = 0

        for subdir, _, files in os.walk(root_dir):
            processed_dirs += 1
            if processed_dirs % 1000 == 0:  # 每处理1000个目录打印一次进度
                print(f"Processed {processed_dirs}/{total_dirs} directories")

            for file in files:
                if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac",".pcm")):
                    wav_path = os.path.join(root, file)
                    if os.path.getsize(wav_path) > 0:  # 检查文件大小是否大于 0
                        utt_id = os.path.splitext(file)[0]
                        f.write(f"{utt_id}\t{wav_path}\n")
                        f.flush()
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate wav.scp file from audio directories.')
    parser.add_argument('-i', '--input_dir', required=True, help='Input directory containing subdirectories with audio files.')
    parser.add_argument('-o', '--output_file', required=True, help='Output wav.scp file name.')

    args = parser.parse_args()

    generate_wav_scp(args.input_dir, args.output_file)
