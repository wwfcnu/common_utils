import os
import argparse
from tqdm import tqdm
def audio_to_flac(audio_in_path, audio_out_path, sample_rate=48000, no_log=True, segment_start:float=0, segment_end:float=None):
    log_cmd = ' -v quiet' if no_log else ''
    segment_cmd = f'-ss {segment_start} -to {segment_end}' if segment_end else ''
    os.system(
        f'ffmpeg -y -i "{audio_in_path}" -vn {log_cmd} -flags +bitexact '
        f'-ar {sample_rate} -ac 1 {segment_cmd} "{audio_out_path}"')


def audio_to_mp3(audio_in_path, audio_out_path, bit_rate='192k', no_log=True):
    log_cmd = ' -v quiet' if no_log else ''
    os.system(
        f'ffmpeg -y -i "{audio_in_path}" -vn {log_cmd}  '
        f'-b:a {bit_rate} -ac 1 "{audio_out_path}"')


def cut_audio(audio_input_path, audio_output_path, start_time, end_time):
    os.system(
        f'ffmpeg -y  -ss {start_time} -i "{audio_input_path}" -to {end_time - start_time}  "{audio_output_path}"')



def audio_to_wav(audio_in_path, audio_out_path, sample_rate=16000, no_log=True):
    log_cmd = ' -v quiet' if no_log else ''
    os.system(
        f'ffmpeg -y -i "{audio_in_path}" -vn {log_cmd}  '
        f'-ar {sample_rate} -ac 1 "{audio_out_path}"')

def main():
    parser = argparse.ArgumentParser(description='Convert audio files listed in wav.scp to WAV format.')
    parser.add_argument('-w', '--wav_scp', required=True, help='Path to the wav.scp file')
    # parser.add_argument('-o', '--output_dir', required=True, help='Output directory to save converted audio files')
    parser.add_argument('-s', '--sample-rate', type=int, default=16000, help='Sample rate for the output WAV files (default: 16000)')
    parser.add_argument('-n', '--no-log', action='store_false', help='Disable logging')

    args = parser.parse_args()

    wav_scp_path = []
    with open(args.wav_scp) as f:
        for line in f:
            wav_id, wav_path = line.strip().split()
            wav_scp_path.append(wav_path)

    # os.makedirs(args.output_dir, exist_ok=True)

    for audio_in_path in tqdm(wav_scp_path):
        # filename = os.path.basename(audio_in_path)
        # audio_out_path = os.path.join(args.output_dir, filename)
        audio_out_path = audio_in_path.replace("WAV","WAV_16k")
        os.makedirs(os.path.dirname(audio_out_path), exist_ok=True)
        audio_to_wav(audio_in_path, audio_out_path, args.sample_rate, args.no_log)

if __name__ == "__main__":
    main()