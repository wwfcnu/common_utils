#!/bin/bash
DIRECTORY="$1"
OUTPUT="$2"
find "$DIRECTORY" -type f \( \
    -name "*.wav" -o -name "*.mp3" -o -name "*.flac" -o \
    -name "*.m4a" -o -name "*.aac" -o -name "*.pcm" -o -name "*.webm" \
    \) -size +0c 2>/dev/null | \
awk -F/ '{
    file = $NF
    gsub(/\.[^\.]*$/, "", file)
    print file "\t" $0
}' > "$OUTPUT"
echo "wav.scp generated with $(wc -l < "$OUTPUT") entries"