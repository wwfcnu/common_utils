# import time
# from funasr import AutoModel
# from funasr.utils.postprocess_utils import rich_transcription_postprocess

# model_dir = "iic/SenseVoiceSmall"

# model = AutoModel(model=model_dir, trust_remote_code=True, device="cuda:0")

# # res = model.generate(
# #     input=f"{model.model_path}/example/en.mp3",
# #     cache={},
# #     language="zh", # "zh", "en", "yue", "ja", "ko", "nospeech"
# #     use_itn=False,
# #     batch_size=64, 
# # )
# def parse(cls, input_string: str):
#     """
#     Parse from SenseVoice output.
#     """
#     # '<|nospeech|><|EMO_UNKNOWN|><|Laughter|><|woitn|>'
#     # '<|en|><|NEUTRAL|><|Speech|><|withitn|>As you can see...'
#     pattern = r"<\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|>(.*)?"
#     match = re.match(pattern, input_string)
#     if match:
#         language, emotion, event, textnorm, text = match.groups()
#         return cls(language, emotion, event, textnorm, text)
#     else:
#         raise ValueError(f"Cannot parse the input string: {input_string}")

# start_time = time.time()       
# wav_scp = "/mnt/lustre/wangweifei/tv_drama_meta/10000_test_wav.scp"
# res = model.generate(
#     input=wav_scp,
#     cache={},
#     language="zh", # "zh", "en", "yue", "ja", "ko", "nospeech"
#     use_itn=False,
#     # ban_emo_unk=True,
#     batch_size=64, 
#     output_dir="/home/wangweifei/repository/wair/asr_project/transcribe/sensevoice"
# )

# # text = rich_transcription_postprocess(res[0]["text"])
# # print(text)
# print(f"Total time cost: {time.time() - start_time:.2f}s") #231.08s

# AudioPipeline环境


import time
import argparse
import re
from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess

# The parse function to extract language, emotion, event, textnorm, and text
def parse(input_string: str):
    """
    Parse from SenseVoice output.
    """
    # pattern = r"^(\S+)\s<\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|>(.*)$"
    pattern = r"^(\S+)\s<\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|>(.*)?"
    match = re.match(pattern, input_string)
    
    if match:
        wav_id, language, emotion, event, textnorm, text = match.groups()
        return {
            "wav_id": wav_id,
            "language": language,
            "emotion": emotion,
            "event": event,
            "textnorm": textnorm,
            "text": text.strip()
        }
    else:
        raise ValueError(f"Cannot parse the input string: {input_string}")

# Function to process the output file and parse it
def process_output(output_dir):
    output_file = f"{output_dir}/1best_recog/text"
    parsed_output_file = f"{output_dir}/1best_recog/parse_text"
    with open(output_file, 'r', encoding='utf-8') as f_in, open(parsed_output_file, 'w', encoding='utf-8') as f_out:
        for line in f_in:
            try:
                parsed_data = parse(line.strip())
                wav_id = parsed_data["wav_id"]
                text = parsed_data["text"]
                
                # Write the result to the parsed output file
                f_out.write(f"{wav_id}\t{text}\n")
            except ValueError as e:
                print(f"Error processing line: {e}")

# Main function to handle transcription and post-processing
def main():
    # Define the arguments
    parser = argparse.ArgumentParser(description="ASR transcription and result parsing using SenseVoice model.")
    parser.add_argument('--model', type=str, default="iic/SenseVoiceSmall", help='Path to the model directory')
    parser.add_argument('--gpuid', type=str, default="0", help='GPU device to use, e.g., "cuda:0" or "cpu"')
    parser.add_argument('--input', type=str, help='Path to the input file (wav.scp)')
    parser.add_argument('--language', type=str, default="auto", help='Language for transcription (e.g., "zh", "en", "yue", "ja", "ko", "nospeech")')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size for processing')
    # parser.add_argument('--output_dir', type=str, help='Directory to save the transcription output')
    parser.add_argument('--output_file', type=str, help='file to save the transcription output')


    # Parse the arguments
    args = parser.parse_args()

    # Load the model
    # model = AutoModel(model=args.model, trust_remote_code=True, device=f"cuda:{args.gpuid}")

    model = AutoModel(
        model=args.model,
        # trust_remote_code=True,
        # remote_code="./model.py",    
        vad_model="fsmn-vad",
        vad_kwargs={"max_single_segment_time": 30000},
        device=f"cuda:{args.gpuid}",
    )
    start_time = time.time()
    # en
    with open(args.input)as f,open(args.output_file,"w")as w:
        for line in f:
            wav_id, wav_path = line.strip().split("\t")
            res = model.generate(
                input=wav_path,
                cache={},
                language="auto",  # "zh", "en", "yue", "ja", "ko", "nospeech"
                use_itn=True,
                batch_size_s=60,
                merge_vad=True,  #
                merge_length_s=15,
            )
            text = rich_transcription_postprocess(res[0]["text"])
            # print(text)
            w.write(f"{wav_id}\t{text}")
            w.flush()
    # Perform transcription


    # Log the total time taken
    print(f"Total time cost for transcription: {time.time() - start_time:.2f}s")

    # Post-process the output file



if __name__ == "__main__":
    main()
    # process_output("/home/wangweifei/repository/wair/asr_project/transcribe/sensevoice")