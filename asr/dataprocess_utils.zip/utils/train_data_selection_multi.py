from pydub import AudioSegment
import random
import os
import argparse
from typing import Dict, Tuple, List
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
from tqdm import tqdm

def process_segment(params: Tuple[str, str, float, float, str]) -> bool:
    """
    处理单个音频片段的函数
    params: (wav_path, uttid, start, end, output_path)
    """
    wav_path, uttid, start, end, output_path = params
    try:
        # 加载音频文件
        audio = AudioSegment.from_file(wav_path)
        
        # 转换为单通道
        if audio.channels > 1:
            audio = audio.set_channels(1)
        
        # 设置采样率为16kHz
        if audio.frame_rate != 16000:
            audio = audio.set_frame_rate(16000)
        
        # 提取片段
        start_ms = int(start * 1000)
        end_ms = int(end * 1000)
        segment = audio[start_ms:end_ms]
        
        # 保存音频片段
        segment.export(output_path, format="wav")
        return True
    except Exception as e:
        print(f"Error processing {uttid}: {str(e)}")
        return False

def read_wav_scp(wav_scp_path: str) -> Dict[str, str]:
    """读取wav.scp文件，返回wav_id到wav路径的映射"""
    wav_dict = {}
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            wav_id, wav_path = line.strip().split(maxsplit=1)
            wav_dict[wav_id] = wav_path
    return wav_dict

def read_segments(segments_path: str) -> Dict[str, Tuple[str, float, float]]:
    """读取segments文件，返回uttid到(wav_id, start, end)的映射"""
    segments_dict = {}
    with open(segments_path, 'r', encoding='utf-8') as f:
        for line in f:
            uttid, wav_id, start, end = line.strip().split()
            segments_dict[uttid] = (wav_id, float(start), float(end))
    return segments_dict

def read_filter(filter_path: str) -> list:
    """读取filter.txt文件，返回uttid列表"""
    with open(filter_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f]

def filter_by_duration(uttids: List[str], 
                      segments_dict: Dict[str, Tuple[str, float, float]], 
                      min_duration: float = 5.0) -> List[str]:
    """筛选出时长大于指定秒数的uttid"""
    filtered_uttids = []
    for uttid in uttids:
        if uttid in segments_dict:
            _, start, end = segments_dict[uttid]
            duration = end - start
            if duration >= min_duration:
                filtered_uttids.append(uttid)
    return filtered_uttids

def extract_segments_parallel(wav_dict: Dict[str, str], 
                            segments_dict: Dict[str, Tuple[str, float, float]], 
                            selected_uttids: list,
                            output_dir: str,
                            num_processes: int):
    """使用多进程并行提取音频片段"""
    os.makedirs(output_dir, exist_ok=True)
    
    # 准备处理参数
    process_params = []
    for uttid in selected_uttids:
        if uttid in segments_dict:
            wav_id, start, end = segments_dict[uttid]
            if wav_id in wav_dict:
                wav_path = wav_dict[wav_id]
                output_path = os.path.join(output_dir, f"{uttid}.wav")
                process_params.append((wav_path, uttid, start, end, output_path))
    
    # 使用进程池并行处理
    with ProcessPoolExecutor(max_workers=num_processes) as executor:
        # 使用tqdm显示进度条
        results = list(tqdm(
            executor.map(process_segment, process_params),
            total=len(process_params),
            desc="Processing audio segments"
        ))
    
    # 统计处理结果
    successful = sum(1 for x in results if x)
    print(f"\nProcessed {successful} out of {len(process_params)} segments successfully")

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='Extract audio segments based on filter list.')
    
    parser.add_argument('--wav-scp', type=str, required=True,
                        help='Path to wav.scp file')
    parser.add_argument('--segments', type=str, required=True,
                        help='Path to segments file')
    parser.add_argument('--filter', type=str, required=True,
                        help='Path to filter.txt file')
    parser.add_argument('--output-dir', type=str, required=True,
                        help='Directory to save extracted segments')
    parser.add_argument('--sample-num', type=int, default=2000,
                        help='Number of utterances to sample (default: 2000)')
    parser.add_argument('--min-duration', type=float, default=5.0,
                        help='Minimum duration in seconds (default: 5.0)')
    parser.add_argument('--num-processes', type=int, 
                        default=max(1, multiprocessing.cpu_count() - 1),
                        help='Number of processes to use (default: CPU count - 1)')
    
    return parser.parse_args()

def main():
    # 解析命令行参数
    args = parse_args()
    
    # 读取所有文件
    print("Reading input files...")
    wav_dict = read_wav_scp(args.wav_scp)
    segments_dict = read_segments(args.segments)
    uttids = read_filter(args.filter)
    
    # 筛选出大于指定时长的uttid
    valid_uttids = filter_by_duration(uttids, segments_dict, args.min_duration)
    print(f"Found {len(valid_uttids)} utterances >= {args.min_duration}s from total {len(uttids)} utterances")
    
    if not valid_uttids:
        print("No valid utterances found!")
        return
    
    # 随机选择指定数量的uttid
    sample_num = min(args.sample_num, len(valid_uttids))
    selected_uttids = random.sample(valid_uttids, sample_num)
    
    # 使用多进程提取并保存音频片段
    print(f"\nStarting audio extraction using {args.num_processes} processes...")
    extract_segments_parallel(wav_dict, segments_dict, selected_uttids, 
                            args.output_dir, args.num_processes)

if __name__ == "__main__":
    main()