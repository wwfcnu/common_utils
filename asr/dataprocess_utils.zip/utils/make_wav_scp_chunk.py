import os
import argparse
import math

def generate_wav_scp_for_part(subdirs, output_file):
    with open(output_file, 'w') as f:
        processed_dirs = 0
        total_dirs = len(subdirs)

        for subdir in subdirs:
            processed_dirs += 1
            if processed_dirs % 1000 == 0:  # Print progress every 1000 directories
                print(f"Processed {processed_dirs}/{total_dirs} directories")

            for file in os.listdir(subdir):
                if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac",".pcm",".webm")):
                    wav_path = os.path.join(subdir, file)
                    if os.path.getsize(wav_path) > 0:  # Check if file size is greater than 0
                        utt_id = os.path.splitext(file)[0]
                        f.write(f"{utt_id}\t{wav_path}\n")
                        f.flush()

# def get_subdirectories(root_dir):
#     subdirs = []
#     for subdir, _, _ in os.walk(root_dir):
#         subdirs.append(subdir)
#     return subdirs

def get_subdirectories(root_dir):
    subdirs = []
    # List all entries in the root_dir
    for entry in os.listdir(root_dir):
        full_path = os.path.join(root_dir, entry)
        if os.path.isdir(full_path):
            subdirs.append(full_path)
    return subdirs
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate wav.scp file from audio directories.')
    parser.add_argument('-i', '--input_dir', required=True, help='Input directory containing subdirectories with audio files.')
    parser.add_argument('-o', '--output_file', required=True, help='Output wav.scp file name.')

    args = parser.parse_args()

    # Get the list of all subdirectories
    subdirs = get_subdirectories(args.input_dir)
    
    # Split subdirectories into 4 equal parts
    num_parts = 20
    part_size = math.ceil(len(subdirs) / num_parts)
    
    temp_files = []
    
    # Process each part and save to a temporary file
    for i in range(num_parts):
        part_subdirs = subdirs[i * part_size: (i + 1) * part_size]
        temp_file = f"{args.output_file}.part{i+1}"
        temp_files.append(temp_file)
        # if i == 15:
        #     with open("/mnt/lustre/wangweifei/podcast_15.txt","w")as w:
        #         for line in part_subdirs:
        #             line = line.strip()
        #             w.write(line + "\n")
        # if i < 15:
        #     print(f"Skipping part {i+1}...")
        #     continue
        print(f"Processing part {i+1} with {len(part_subdirs)} directories...")
        generate_wav_scp_for_part(part_subdirs, temp_file)

    # Merge all partial files into the final output
    with open(args.output_file, 'w') as outfile:
        for temp_file in temp_files:
            with open(temp_file, 'r') as infile:
                outfile.write(infile.read())
    
    print(f"All parts merged into {args.output_file}")
