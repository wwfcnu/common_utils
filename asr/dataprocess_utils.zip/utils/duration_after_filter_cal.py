import argparse

def stat_duration(segments_file, wer_file):
    segment_data = {}
    all_duration = 0
    with open(segments_file) as f1:  
        for line in f1:
            line = line.strip()
            if line:
                segment_id, _, start, end = line.split(" ")
                segment_data[segment_id] = [segment_id, start, end]
                interval = float(end)-float(start)
                all_duration += interval

    with open(wer_file) as f2:
        total_duration = 0
        for line in f2:
            line = line.strip()
            segment_id = line
            segment = segment_data.get(segment_id, [0, 0, 0])
            start = float(segment[1])
            end = float(segment[2])
            duration = end - start
            total_duration += duration

    time = round(total_duration / 3600, 2)
    all_time = round(all_duration / 3600, 2)
    return time, all_time


def stat_duration_from_segment(segments_file):
    all_duration = 0
    with open(segments_file) as f1:  
        for line in f1:
            line = line.strip()
            if line:
                segment_id, _, start, end = line.split()
                interval = float(end)-float(start)
                all_duration += interval

    all_time = round(all_duration / 3600, 2)
    return all_time


def run_main(args):
    time, all_time = stat_duration(args.segments, args.wer)
    print(f"筛选后的时长:{time}h")
    print(f"筛选前总时长:{all_time}h")


def run_test(args):
    all_time = stat_duration_from_segment(args.segments)
    print(f"筛选前总时长:{all_time}h")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate duration from files")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    # main 模式
    parser_main = subparsers.add_parser("main", help="Run main mode")
    parser_main.add_argument("-s", "--segments", type=str, required=True, help="File containing segment data")
    parser_main.add_argument("-w", "--wer", type=str, required=True, help="File containing WER data")

    # test 模式
    parser_test = subparsers.add_parser("test", help="Run test mode")
    parser_test.add_argument("-s", "--segments", type=str, required=True, help="File containing segment data")

    args = parser.parse_args()

    if args.mode == "main":
        run_main(args)
    elif args.mode == "test":
        run_test(args)
