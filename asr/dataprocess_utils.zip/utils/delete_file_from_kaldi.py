import os
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from multiprocessing import cpu_count
def delete_file(file_path):
    """删除指定的文件"""
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
            # return f"已删除文件: {file_path}"
        except Exception as e:
            return f"删除文件 {file_path} 时出现错误: {e}"
    else:
        return f"文件不存在: {file_path}"

def delete_files_from_wav_scp(wav_scp_file, num_workers):
    """读取 wav.scp 文件并多进程删除其中指定的文件"""
    files_to_delete = []

    # 读取 wav.scp 文件中的文件路径
    with open(wav_scp_file, "r") as f:
        for line in f:
            uttid, file_path = line.strip().split("\t")
            files_to_delete.append(file_path)

    # 使用 ProcessPoolExecutor 进行多进程删除
    with ProcessPoolExecutor(max_workers=10) as executor:  # cpu_count()
        futures = {executor.submit(delete_file, file): file for file in files_to_delete}

        # 使用 tqdm 显示进度条
        for future in tqdm(as_completed(futures), total=len(futures), desc="删除进度"):
            result = future.result()
            # print(result)

def main():
    parser = argparse.ArgumentParser(description="根据 wav.scp 文件删除指定的音频文件，支持多进程")
    
    # 接受 wav_scp 文件路径和进程数参数
    parser.add_argument("-w","--wav_scp", required=True, help="包含音频文件路径的 wav.scp 文件")
    parser.add_argument("--num_workers", type=int, default=8, help="并行处理的进程数，默认为 8")

    args = parser.parse_args()

    # 调用删除文件的函数
    delete_files_from_wav_scp(args.wav_scp, args.num_workers)

if __name__ == "__main__":
    main()
