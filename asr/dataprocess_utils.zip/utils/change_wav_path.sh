#!/bin/bash

# 改变路径 dialect_only改完了
# podcast路径


# datasets="part00 part01 part02 part03 part04"
# for dataset in $datasets;do
#     sed -i 's#/lustre#/mnt/lustre#g' /mnt/lustre/wangweifei/data/$dataset/check_audio_clip_wav.scp
#     sed -i 's#/lustre#/mnt/lustre#g' /mnt/lustre/wangweifei/data/$dataset/20240327_whisper_remain_wav.scp
# done


datasets="00 01 02 03 04 05 06 07 08 09 10 11"
for dataset in $datasets;do
    sed -i 's#/lustre#/mnt/lustre#g' /mnt/lustre/wangweifei/data/split_segments/segments_merge_path_$dataset

done