#!/bin/bash
utils_dir="/home/wangweifei/repository/wair/asr_project/utils"

# 1. vad切分
python $utils_dir/vad_parse.py -w /path/to/wav.scp -o /path/to/segment

# 2. 合并

bash $utils_dir/make_segments_merge.sh /path/to/segment /path/to/segment_merge_dir

# 3. 识别
python $utils_dir/asr_parse.py -w /path/to/wav.scp -s /path/to/segment_merge_dir -o /path/to/output_dir -g gpu_id -m paraformer

