from pydub import AudioSegment
import os
from tqdm import tqdm
import sys
from multiprocessing import cpu_count
from concurrent.futures import ProcessPoolExecutor

#executor = ProcessPoolExecutor(max_workers=cpu_count())
executor = ProcessPoolExecutor(max_workers=cpu_count())

def process(segments_file, output_folder, wav_scp_path):
    try:
        wav_id = segments_file.split("/")[-1].split(".")[0]
        output_dir = os.path.join(output_folder, wav_id)
        os.makedirs(output_dir, exist_ok=True)

        # Load the entire audio file
        wav_path = wav_scp_path.get(wav_id)
        audio = AudioSegment.from_file(wav_path)

        with open(segments_file, 'r') as f:
            lines = f.readlines()

        for line in tqdm(lines):
            parts = line.split()
            filename = parts[0]
            start_time = float(parts[2])
            end_time = float(parts[3])
            
            if end_time > start_time:
                output_file = os.path.join(output_dir, f'{filename}.wav')
                if os.path.exists(output_file):
                    print(f"{output_file} already exists, skipping")
                    continue

                segment = audio[start_time * 1000:end_time * 1000]
                if segment:
                    segment = segment.set_frame_rate(16000).set_channels(1)
                    segment.export(output_file, format='wav')
    except Exception as e:
        print(f"Failed to process file {segments_file}: {e}")

if __name__ == "__main__":
    # Get command-line arguments
    wav_scp_file = sys.argv[1]  # Path to wav.scp file
    segments_merge_path = sys.argv[2]  # Path to segments merge file
    num_parts = int(sys.argv[3])  # Number of parts
    output_part_dir = sys.argv[4]  # Output directory

    # Read wav.scp file
    wav_scp_path = {}
    with open(wav_scp_file) as f:
        for line in f:
            wav_id, wav_path = line.strip().split()
            wav_scp_path[wav_id] = wav_path

    # Read segments merge file
    segments_list = []
    with open(segments_merge_path) as f:
        for line in f:
            segment_file = line.strip()
            segments_list.append(segment_file)

    # Divide segments into parts
    segments_per_folder = len(segments_list) // num_parts

    segment_batches = [segments_list[i:i+segments_per_folder] for i in range(0, len(segments_list), segments_per_folder)]

  
    # Define output folders
    output_folders = [os.path.join(output_part_dir, str(i)) for i in range(0, num_parts + 1)]

    # Process segments using multiprocessing
    for i, batch in enumerate(segment_batches):
        output_folder = output_folders[i]
        futures = []
        for segments_file in tqdm(batch):
            futures.append(executor.submit(process, segments_file, output_folder, wav_scp_path))
        result = [future.result() for future in tqdm(futures)]


# python dialect_only_Audio_segment.py /mnt/lustre/wangweifei/dialect_only/wav.scp /mnt/lustre/wangweifei/dialect_only/dialect_only_segments_path.txt 100 /lustre/wangweifei/dialect_only_seg
