import os
import sys
import re 
def generate_wav_scp(directory):
    wav_scp_content = ""
    for root, dirs, files in os.walk(directory):
        for file in files:
            #if file.endswith(".m4a") or file.endswith(".mp3") or file.endswith(".wav") or file.endswith(".flac") or file.endswith(".aac"):        #这个需要修改
            if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac",".pcm",".webm")):
                wav_path = os.path.join(root, file)
                if os.path.getsize(wav_path) > 0:  # 检查文件大小是否大于 0
                    utt_id = os.path.splitext(file)[0]
                    wav_scp_content += f"{utt_id}\t{wav_path}\n"

    return wav_scp_content


def generate_wav_scp_new(directory):
    wav_scp_content = ""
    for root, dirs, files in os.walk(directory):
        for file in files:
            # if file.endswith(".m4a") or file.endswith(".mp3") or file.endswith(".wav") or file.endswith(".flac"):        #这个需要修改
            if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac",".pcm",".webm")):
                wav_path = os.path.join(root, file)
                utt_id = os.path.splitext(file)[0]
                speaker_id = wav_path.split("/")[-2]
                wav_scp_content += f"{speaker_id}_{utt_id}\t{wav_path}\n"

    return wav_scp_content

def generate_stroy_tts_wav_scp(directory):
    # 获取目录中的所有文件
    wav_scp_content = ""
    for root, dirs, files in os.walk(directory):
        for file in files:
            # if file.endswith(".m4a") or file.endswith(".mp3") or file.endswith(".wav") or file.endswith(".flac"):        #这个需要修改
            if file.endswith((".mp3", ".wav", ".flac", ".m4a", ".aac",".pcm",".webm")):
                wav_path = os.path.join(root, file)
                utt_id = os.path.splitext(file)[0]
                utt_id = rename_files(utt_id)
                wav_scp_content += f"{utt_id}\t{wav_path}\n"

    return wav_scp_content

def rename_files(filename):

    match = re.match(r'(.*-episode)(\d+)(.*)', filename)
    if match:
        # 提取文件名的不同部分 
        prefix = match.group(1)
        number = match.group(2)
        suffix = match.group(3)

        # 将数字部分格式化为三位数  CN-celeb
        new_number = number.zfill(3)

        # 构建新的文件名
        new_filename = f"{prefix}{new_number}{suffix}"

    return new_filename


def save_wav_scp(wav_scp_content, output_file):
    with open(output_file, "w") as file:
        file.write(wav_scp_content)

def main():
        # 设置包含 WAV 文件的目录
    input_directory = sys.argv[1]  #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/audio"
   
    # 生成 WAV.scp 内容
    wav_scp_content = generate_wav_scp(input_directory)

    # 设置输出文件路径
    output_file = sys.argv[2]   #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/wav.scp"

    # 将 WAV.scp 内容保存到文件
    save_wav_scp(wav_scp_content, output_file)

    print(f"{output_file} 文件已生成。")

def main_new():
        # 设置包含 WAV 文件的目录
    input_directory = sys.argv[1]  #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/audio"
   
    # 生成 WAV.scp 内容
    wav_scp_content = generate_wav_scp_new(input_directory)

    # 设置输出文件路径
    output_file = sys.argv[2]   #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/wav.scp"

    # 将 WAV.scp 内容保存到文件
    save_wav_scp(wav_scp_content, output_file)

    print(f"{output_file} 文件已生成。")


def test_story_tts():

    # 设置包含 WAV 文件的目录
    input_directory = sys.argv[1]  #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/audio"
   
    # 生成 WAV.scp 内容
    wav_scp_content = generate_stroy_tts_wav_scp(input_directory)

    # 设置输出文件路径
    output_file = sys.argv[2]   #"/mnt/data1/AudioDataset/lm/data/wuhanjinying/wav.scp"

    # 将 WAV.scp 内容保存到文件
    save_wav_scp(wav_scp_content, output_file)

    print(f"{output_file} 文件已生成。")





if __name__ == "__main__":

    main()
    # main_new()
    #test_story_tts()

# python make_wav_scp.py /lustre/chentingwei/tv_drama_sep /home/wangweifei/repository/wair/asr_project/data/tv_drama/wav.scp