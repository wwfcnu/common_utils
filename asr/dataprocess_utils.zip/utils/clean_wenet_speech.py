import json
import os
import subprocess
import tempfile
import time
from pathlib import Path
import librosa
import soundfile as sf
import torch
import torchaudio
from tqdm import tqdm
import glob
import numpy as np
from fish_audio_preprocess.utils.separate_audio import (
    init_model,
    merge_tracks,
    separate_audio
)

device = torch.device("cuda:0")

def main():
    meta_path = Path("/home/tangshuai/asr_datasets/asr_datasets/wenetspeech/WenetSpeech.json")
    dataset_path = Path("/home/tangshuai/asr_datasets/asr_datasets/wenetspeech")
    cleaned_path = Path("/mnt/dnefs/chentingwei/wenetspeech_segments/")
    if not cleaned_path.exists():
        cleaned_path.mkdir(parents=True)
    
    demucs = init_model("htdemucs", device)
    print("Model loaded")

    with open(meta_path) as f:
        dataset = json.load(f)["audios"]
    
    print(f"Dataset loaded, {len(dataset)} samples")

    for data_idx, data in tqdm(enumerate(dataset)):
        if data_idx < 19889:#  19845~59999, 75065 ~ end
            continue
        if data_idx > 60000 and data_idx < 75070:
            continue
        done_path = cleaned_path / data["aid"] / "done"
        done_path.parent.mkdir(parents=True, exist_ok=True)
        if done_path.exists():
            continue
        try:
            with tempfile.NamedTemporaryFile(suffix=".wav") as f:
                subprocess.check_call(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        str(dataset_path / data["path"]),
                        "-c:a",
                        "pcm_s16le",
                        "-threads",
                        "0",
                        "-ar",
                        "24000",
                        str(f.name),
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                raw_audio, sr = librosa.load(f.name, sr=None, mono=True)
            for idx, segment in enumerate(data["segments"]):
                if segment["confidence"] <= 0.95:
                    continue

                # Load audio
                begin = int(segment["begin_time"] * sr)
                end = int(segment["end_time"] * sr)
                segment_audio = raw_audio[begin:end]
                segment_audio = torch.from_numpy(segment_audio[None]).to(device)
                audio = torchaudio.functional.resample(
                    segment_audio, orig_freq=sr, new_freq=demucs.samplerate
                    )
                audio = torch.cat([audio, audio], dim=0)
                tracks = separate_audio(
                        demucs, audio, shifts=1, num_workers=4, progress=False
                    )
                audio = merge_tracks(tracks, filter=["vocals"])[0]
                vocals, sr = (
                    torchaudio.functional.resample(
                        audio, orig_freq=demucs.samplerate, new_freq=16000
                    ),
                    16000,
                )
                segment_audio_final = vocals.cpu().numpy()
                
                # Write audio
                temp_path = cleaned_path / data["aid"] / f"S{idx:05d}.wav"
                temp_path.parent.mkdir(parents=True, exist_ok=True)
                sf.write(temp_path, segment_audio_final, samplerate=sr)
                # Write text
                temp_path = temp_path.with_suffix(".txt")
                temp_path.write_text(segment["text"])

            # Write done file
            done_path.write_text("")
        except Exception as e:
            print(f"Error {e} on {data_idx}/{len(dataset)}")
            time.sleep(10)
            continue

    print("Done")

def process_single_file(audio_path="", device = torch.device("cuda:1")):
    import soundfile as sf
    demucs = init_model("htdemucs", device)
    print("Model loaded")
    raw_audio, sr = librosa.load(audio_path, sr=None, mono=True)
    raw_audio = torch.from_numpy(raw_audio[None]).to(device)
    audio = torchaudio.functional.resample(
                raw_audio, orig_freq=sr, new_freq=demucs.samplerate
            )
    audio = torch.cat([audio, audio], dim=0)
    tracks = separate_audio(
                demucs, audio, shifts=1, num_workers=0, progress=False
            )
    audio = merge_tracks(tracks, filter=["vocals"])[0]
    vocals, sr = (
                torchaudio.functional.resample(
                    audio, orig_freq=demucs.samplerate, new_freq=16000
                ),
                16000,
            )
    vocals = vocals.cpu().numpy()
    sf.write("/lustre/chentingwei/tv_drama_sep/separate.wav", vocals, 16000)
    

def process_tv_drama(audio_dir_path = "/mnt/lustre/wangweifei/chinese_tv/audio"):
    import soundfile as sf
    demucs = init_model("htdemucs", device)
    print("Model loaded")
    m4a_list = glob.glob(os.path.join(audio_dir_path, "*.m4a"))[28:]
    audio_save_path = "/mnt/lustre/wangweifei/chinese_tv/audio_sep"
    for audio_ind in tqdm(m4a_list):
        audio_temp = audio_ind
        audio_name = audio_temp.split('/')[-1].replace('.m4a', '.wav')
        if os.path.exists(os.path.join(audio_save_path, audio_name)):
            continue
        raw_audio, sr = librosa.load(audio_temp, sr=16000, mono=True)
        raw_audio = torch.from_numpy(raw_audio[None]).to(device)
        audio = torchaudio.functional.resample(
                raw_audio, orig_freq=sr, new_freq=demucs.samplerate
            )
        audio = torch.cat([audio, audio], dim=0)
        tracks = separate_audio(
                demucs, audio, shifts=1, num_workers=0, progress=False
            )
        audio = merge_tracks(tracks, filter=["vocals"])[0]
        vocals, sr = (
                torchaudio.functional.resample(
                    audio, orig_freq=demucs.samplerate, new_freq=16000
                ),
                16000,
            )
        vocals = vocals.cpu().numpy()
        sf.write(os.path.join(audio_save_path, audio_name), vocals, 16000)

def count_wenet_speech(txt_path="/home/chentingwei/datasets/audio_llm_datasets/audiollm_based_datasets/wenetspeech.txt"):
    content = open(txt_path, 'r').read().splitlines()
    speaker_num = set()
    for file_ind in tqdm(content):
        wav_path, text = file_ind.split('\t')
        speaker = wav_path.split('/')[-2]
        speaker_num.add(speaker)
    
    print("total file is {}".format(len(speaker_num)))

def process_wenetspeech_ori():
    meta_path = Path("/home/tangshuai/asr_datasets/asr_datasets/wenetspeech/WenetSpeech.json")
    dataset_path = Path("/home/tangshuai/asr_datasets/asr_datasets/wenetspeech")
    cleaned_path = Path("/mnt/dnefs/chentingwei/wenetspeech_origin/wavs/")
    save_txt_path = "/mnt/dnefs/chentingwei/wenetspeech_origin/wenetspeech3.txt"
    if not cleaned_path.exists():
        cleaned_path.mkdir(parents=True)
    
    with open(meta_path) as f:
        dataset = json.load(f)["audios"]
    
    print(f"Dataset loaded, {len(dataset)} samples")
    with open(save_txt_path, 'w') as file_write:
        for data_idx, data in tqdm(enumerate(dataset)):
            if data_idx < 36784:
                continue
            done_path = cleaned_path / data["aid"] / "done"
            done_path.parent.mkdir(parents=True, exist_ok=True)
            if done_path.exists():
                continue
            try:
                with tempfile.NamedTemporaryFile(suffix=".wav") as f:
                    subprocess.check_call(
                        [
                            "ffmpeg",
                            "-y",
                            "-i",
                            str(dataset_path / data["path"]),
                            "-c:a",
                            "pcm_s16le",
                            "-threads",
                            "0",
                            "-ar",
                            "24000",
                            str(f.name),
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    raw_audio, sr = librosa.load(f.name, sr=16000, mono=True)
                for idx, segment in enumerate(data["segments"]):
                    if segment["confidence"] <= 0.95:
                        continue

                    # Load audio
                    begin = int(segment["begin_time"] * sr)
                    end = int(segment["end_time"] * sr)
                    segment_audio = raw_audio[begin:end]
                    segment_audio_final = segment_audio
                    # Write audio
                    temp_path = cleaned_path / data["aid"] / f"S{idx:05d}.wav"
                    temp_path.parent.mkdir(parents=True, exist_ok=True)
                    if os.path.exists(temp_path):
                        continue
                    sf.write(temp_path, segment_audio_final, samplerate=sr)
                    # Write text
                    #temp_path = temp_path.with_suffix(".txt")
                    #temp_path.write_text(segment["text"])
                    write_content = "{}\t{}\n".format(temp_path, segment["text"])
                    file_write.write(write_content)

                # Write done file
                done_path.write_text("")
            except Exception as e:
                print(f"Error {e} on {data_idx}/{len(dataset)}")
                time.sleep(10)
                continue

    print("Done")


def process_single_mp3(audio_dir_path = "/home/wangweifei/repository/wair/asr_project"):
    import soundfile as sf
    demucs = init_model("htdemucs", device)
    print("Model loaded")
    m4a_list = glob.glob(os.path.join(audio_dir_path, "*.mp3"))
    audio_save_path = "/home/wangweifei/repository/wair/asr_project"
    for audio_ind in tqdm(m4a_list):
        audio_temp = audio_ind
        audio_name = audio_temp.split('/')[-1].replace('.mp3', '.wav')
        if os.path.exists(os.path.join(audio_save_path, audio_name)):
            continue
        raw_audio, sr = librosa.load(audio_temp, sr=16000, mono=True)
        raw_audio = torch.from_numpy(raw_audio[None]).to(device)
        audio = torchaudio.functional.resample(
                raw_audio, orig_freq=sr, new_freq=demucs.samplerate
            )
        audio = torch.cat([audio, audio], dim=0)
        tracks = separate_audio(
                demucs, audio, shifts=1, num_workers=0, progress=False
            )
        audio = merge_tracks(tracks, filter=["vocals"])[0]
        vocals, sr = (
                torchaudio.functional.resample(
                    audio, orig_freq=demucs.samplerate, new_freq=16000
                ),
                16000,
            )
        vocals = vocals.cpu().numpy()
        sf.write(os.path.join(audio_save_path, audio_name), vocals, 16000)


def process_long_tv_drama(audio_dir_path="/mnt/lustre/wangweifei/chinese_tv/audio"):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    demucs = init_model("htdemucs").to(device)
    print("Model loaded")

    m4a_list = glob.glob(os.path.join(audio_dir_path, "*.m4a"))
    audio_save_path = "/mnt/lustre/wangweifei/chinese_tv/audio_sep"
    os.makedirs(audio_save_path, exist_ok=True)
    
    max_duration = 40 * 60  # 40 minutes in seconds
    
    for audio_ind in tqdm(m4a_list):
        audio_temp = audio_ind
        audio_name = os.path.basename(audio_temp).replace('.m4a', '.wav')
        
        if os.path.exists(os.path.join(audio_save_path, audio_name)):
            continue
        
        raw_audio, sr = librosa.load(audio_temp, sr=16000, mono=True)
        total_duration = librosa.get_duration(y=raw_audio, sr=sr)
        
        if total_duration > max_duration:
            segments = []
            segment_duration = max_duration
            num_segments = int(total_duration // segment_duration)
            for i in range(num_segments):
                start = int(i * segment_duration * sr)
                end = int((i + 1) * segment_duration * sr)
                segment = raw_audio[start:end]
                segments.append(segment)
            
            # Add the last segment if there's remaining audio
            remaining_start = int(num_segments * segment_duration * sr)
            if remaining_start < len(raw_audio):
                segments.append(raw_audio[remaining_start:])
        else:
            segments = [raw_audio]
        
        processed_segments = []
        
        for segment in segments:
            raw_audio = torch.from_numpy(segment[None]).to(device)
            audio = torchaudio.functional.resample(
                    raw_audio, orig_freq=sr, new_freq=demucs.samplerate
                )
            audio = torch.cat([audio, audio], dim=0)
            tracks = separate_audio(
                    demucs, audio, shifts=1, num_workers=0, progress=False
                )
            audio = merge_tracks(tracks, filter=["vocals"])[0]
            vocals, sr = (
                    torchaudio.functional.resample(
                        audio, orig_freq=demucs.samplerate, new_freq=16000
                    ),
                    16000,
                )
            vocals = vocals.cpu().numpy()
            processed_segments.append(vocals)
        
        combined_vocals = np.concatenate(processed_segments, axis=-1)
        sf.write(os.path.join(audio_save_path, audio_name), combined_vocals, 16000)


if __name__ == "__main__":
    #process_single_file(audio_path="/lustre/chentingwei/tv_drama/401710.m4a")
    #process_wenetspeech_ori()

    #count_wenet_speech()
    #main()
    #process_single_mp3()
    
    # process_tv_drama()
    process_long_tv_drama()