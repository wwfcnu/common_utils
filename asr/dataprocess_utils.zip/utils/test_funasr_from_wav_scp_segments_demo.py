# 实现读取wav.scp和segments，组成audio_segments的batch输入到model进行识别
# 如果batch中某个音频识别报错，需要检查一下这个segments片段的时长


from pydub import AudioSegment
import numpy as np

audio = AudioSegment.from_file("/home/wangweifei/repository/wair/asr_project/test.m4a")

audio = audio.set_channels(1)  # 转为单通道（单声道）
audio = audio.set_frame_rate(16000)  # 设置采样率为 16kHz
sr = 16000  # 采样率

segments = [
    ("uttid_0", "wav_id", 0.0, 10.0),
    ("uttid_1", "wav_id", 10.0, 20.0),
    ("uttid_2", "wav_id", 20.0, 30.0),
]

audio_segments = []
for uttid, wav_id, start, end in segments:
    # pydub 使用毫秒作为时间单位
    start_ms = int(start * 1000)
    end_ms = int(end * 1000)
    
    # 切片音频段
    segment = audio[start_ms:end_ms]
    audio_segments.append(segment)

# 如果需要转换为 numpy 数组（类似 soundfile 的输出）
audio_arrays = []
for segment in audio_segments:
    # 转换为 numpy 数组，单通道音频直接转换
    audio_array = np.array(segment.get_array_of_samples(), dtype=np.float32)
    
    # 归一化到 [-1, 1] 范围（可选）
    audio_array = audio_array / 32768.0  # 16位音频的最大值
    
    audio_arrays.append(audio_array)



# audio_segments = []
# for uttid, wav_id, start, end in segments:
#     start_sample = int(start * sr)
#     end_sample = int(end * sr)
#     audio_segments.append(audio[start_sample:end_sample])



from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess

model = AutoModel(
    model="iic/SenseVoiceSmall",
    device="cuda:0",
    #batch_size=4
)
# audio_segments需要是单通道的数据
res = model.generate(audio_arrays,
    language="auto",  # "zn", "en", "yue", "ja", "ko", "nospeech"
    cache={},
    use_itn=True,
    batch_size = 4 ,        
    # output_dir=""
)
print(res)

'''
[{'key': 'rand_key_2yW4Acq9GFz6Y', 'text': '<|zh|><|NEUTRAL|><|Speech|><|withitn|>大家好，我们是井然无序。今天我们请到的是我们的好朋友谢老板。嗯，谢老板目前正在上海居家隔离当中，其实他。'}, {'key': 'rand_key_2yW4Acq9GFz6Y', 'text': '<|zh|><|NEUTRAL|><|Speech|><|withitn|>他今年是刚刚从西安搬家到上海，在他搬家之前，在西安也是经历了一场大规模的隔离，所以他是两届隔离选手。'}, {'key': 'rand_key_2yW4Acq9GFz6Y', 'text': '<|zh|><|NEUTRAL|><|Speech|><|withitn|>我们这期节目是一期补录，因为上一期我们聊的内容没有录上。我们上一期聊了谢老板。'}]

'''
# 输出识别结果
# for i, (uttid, _, start, end) in enumerate(segments):
#     print(f"{uttid}: {results[i]['text']}")
# utils/test_funasr_from_wav_scp_segments.py 是循环读取wav.scp中的wav文件进行识别，但是没有预加载音频 