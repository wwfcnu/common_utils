import os
import glob
# 读取标注文件
def process(input_text_file,input_wav_dir,output_dir):

    with open(input_text_file, 'r') as f:
        lines = f.readlines()

    # 切分音频文件
    for line in lines:
        # 解析标注行
        id,_ = line.split('\t')
        #start, end = map(float, start_end.strip('[]').split(','))
        
        start, end = map(float ,id.split('-')[-2:])
        # 构造输入文件名和输出文件名
        #input_file = '/mnt/data1/AudioDataset/asr_datasets/magicdata_ramc/MDT2021S003/WAV/CTS-CN-F2F-2019-11-04-387.wav'
        filename = input_text_file.split("/")[-1].replace(".txt",".wav")
        input_wav_file = os.path.join(input_wav_dir,filename)
  
        #output_file = f'output/CTS-CN-F2F-2019-11-04-387-{start}-{end}.wav'
        output_file = f'{output_dir}/{id}.wav'
        # 调用sox切分音频文件
        os.system(f'sox {input_wav_file} {output_file} trim {start} ={end}')


if __name__=="__main__":


    input_text_files = glob.glob("/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/wav_seg/text/*.txt")
    for input_text_file in input_text_files:
        input_wav_dir = "/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/WAV"
        output_dir = "/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/wav_seg/wav"
        process(input_text_file,input_wav_dir,output_dir)