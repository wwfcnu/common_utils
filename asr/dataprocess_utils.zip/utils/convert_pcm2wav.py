import argparse
import os
from pydub import AudioSegment


def pcm_to_wav(input_pcm_path: str, output_wav_path: str, 
               sample_width: int = 2, frame_rate: int = 16000, channels: int = 1):
    """
    将 PCM 文件转换为 WAV 文件
    
    Args:
        input_pcm_path: 输入的 PCM 文件路径
        output_wav_path: 输出的 WAV 文件路径
        sample_width: 采样宽度（字节），默认 2 (16-bit)
        frame_rate: 采样率，默认 16000 Hz
        channels: 声道数，默认 1 (单声道)
    """
    try:
        # 加载 PCM 音频文件
        audio = AudioSegment.from_file(
            input_pcm_path, 
            # format="raw",
            sample_width=sample_width, 
            frame_rate=frame_rate, 
            channels=channels
        )
        
        # 导出为 WAV 文件
        audio.export(output_wav_path, format="wav")
        print(f"✓ 转换成功: {input_pcm_path} -> {output_wav_path}")
        return True
    except Exception as e:
        print(f"✗ 转换失败: {input_pcm_path}, 错误: {str(e)}")
        return False


def process_wav_scp(wav_scp_path: str, output_dir: str, 
                    sample_width: int = 2, frame_rate: int = 16000, channels: int = 1):
    """
    批量处理 wav.scp 文件中的所有 PCM 文件
    
    Args:
        wav_scp_path: wav.scp 文件路径（格式: utt_id file_path）
        output_dir: 输出目录
        sample_width: 采样宽度（字节）
        frame_rate: 采样率
        channels: 声道数
    """
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 统计信息
    total = 0
    success = 0
    failed = 0
    
    # 读取 wav.scp 文件
    print(f"正在读取 {wav_scp_path}...")
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            # 解析每一行：utt_id file_path
            parts = line.split(maxsplit=1)
            if len(parts) < 2:
                print(f"⚠ 跳过格式错误的行: {line}")
                continue
            
            utt_id, pcm_path = parts
            total += 1
            
            # 生成输出文件路径
            output_wav_path = os.path.join(output_dir, f"{utt_id}.wav")
            
            # 转换文件
            if pcm_to_wav(pcm_path, output_wav_path, sample_width, frame_rate, channels):
                success += 1
            else:
                failed += 1
    
    # 输出统计信息
    print("\n" + "="*50)
    print(f"转换完成!")
    print(f"总计: {total} 个文件")
    print(f"成功: {success} 个文件")
    print(f"失败: {failed} 个文件")
    print(f"输出目录: {output_dir}")
    print("="*50)


def main():
    parser = argparse.ArgumentParser(
        description='批量将 PCM 文件转换为 WAV 文件',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument(
        '--wav_scp',"-w",
        type=str,
        required=True,
        help='输入的 wav.scp 文件路径 (格式: utt_id file_path)'
    )
    
    parser.add_argument(
        '--output_dir',"-o",
        type=str,
        required=True,
        help='输出 WAV 文件的目录'
    )
    
    parser.add_argument(
        '--sample_width',
        type=int,
        default=2,
        help='采样宽度（字节）: 1=8bit, 2=16bit, 4=32bit'
    )
    
    parser.add_argument(
        '--frame_rate',
        type=int,
        default=16000,
        help='采样率（Hz）'
    )
    
    parser.add_argument(
        '--channels',
        type=int,
        default=1,
        help='声道数: 1=单声道, 2=立体声'
    )
    
    args = parser.parse_args()
    
    # 检查输入文件是否存在
    if not os.path.exists(args.wav_scp):
        print(f"错误: 找不到文件 {args.wav_scp}")
        return
    
    # 执行批量转换
    process_wav_scp(
        args.wav_scp,
        args.output_dir,
        args.sample_width,
        args.frame_rate,
        args.channels
    )


if __name__ == "__main__":
    main()