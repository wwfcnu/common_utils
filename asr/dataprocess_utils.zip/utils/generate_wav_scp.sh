#!/bin/bash

# 设置需要遍历的目录
directory="$1"

# 创建输出文件 wav.scp
output_file="$2"
> $output_file  # 清空文件内容

# 遍历指定目录下的所有音频文件并生成 wav.scp 内容
find "$directory" -type f \( -name "*.mp3" -o -name "*.wav" -o -name "*.flac" -o -name "*.m4a" -o -name "*.aac" -o -name "*.pcm" \) | while read filepath; do
    if [ -s "$filepath" ]; then  # 检查文件大小是否大于0
        utt_id=$(basename "$filepath" | sed 's/\.[^.]*$//')  # 提取文件名作为 utt_id
        echo -e "${utt_id}\t${filepath}" >> "$output_file"
    fi
done

echo "wav.scp 文件已生成，存储在：$output_file"
