import os
import numpy as np
from subprocess import run, CalledProcessError
from tqdm import tqdm

SAMPLE_RATE = 16000

def load_audio(file: str, sr: int = SAMPLE_RATE):
    """使用ffmpeg加载音频文件，支持大文件"""
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        print(f"Failed to load audio: {e.stderr.decode()}")
        return None  # 返回 None 表示加载音频失败
    return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0

def save_audio_segment(audio_data, start_sample, end_sample, output_path, sr=SAMPLE_RATE):
    """保存音频片段"""
    # 提取片段
    segment = audio_data[start_sample:end_sample]
    
    # 转换为16位整数
    segment_int16 = (segment * 32768.0).astype(np.int16)
    
    # 使用ffmpeg保存
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-y",  # 覆盖输出文件
        "-f", "s16le",
        "-ar", str(sr),
        "-ac", "1",
        "-i", "-",
        "-acodec", "pcm_s16le",
        output_path
    ]
    
    try:
        run(cmd, input=segment_int16.tobytes(), check=True, capture_output=True)
    except CalledProcessError as e:
        print(f"Failed to save audio segment {output_path}: {e.stderr.decode()}")
        return False
    return True

def load_wavscp(wavscp_file):
    """加载wav.scp文件"""
    wav_dict = {}
    with open(wavscp_file, 'r', encoding='utf-8') as f:
        for line in f:
            wav_id, wav_path = line.strip().split(maxsplit=1)
            wav_dict[wav_id] = wav_path
    return wav_dict

def load_segments(segments_file):
    """加载segments文件"""
    segments_dict = {}
    with open(segments_file, 'r', encoding='utf-8') as f:
        for line in f:
            uutid, wav_id, start, end = line.strip().split()
            if wav_id not in segments_dict:
                segments_dict[wav_id] = []
            segments_dict[wav_id].append({
                'uutid': uutid,
                'start': float(start),
                'end': float(end)
            })
    return segments_dict

def process_audio(wav_dict, segments_dict, output_dir):
    """处理音频文件"""
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 遍历每个wav文件
    for wav_id, segments in tqdm(segments_dict.items()):
        if wav_id not in wav_dict:
            print(f"Warning: {wav_id} not found in wav.scp")
            continue
            
        # 读取音频文件
        wav_path = wav_dict[wav_id]
        print(f"Processing {wav_path}...")
        
        # 使用新的load_audio函数
        audio_data = load_audio(wav_path, SAMPLE_RATE)
        if audio_data is None:
            print(f"Error: Failed to load {wav_path}")
            continue
        
        # 切分并保存每个片段
        for segment in segments:
            uutid = segment['uutid']
            start_time = segment['start']
            end_time = segment['end']
            
            # 转换时间为样本索引
            start_sample = int(start_time * SAMPLE_RATE)
            end_sample = int(end_time * SAMPLE_RATE)
            
            # 检查边界
            if start_sample >= len(audio_data):
                print(f"Warning: Start time {start_time}s exceeds audio length for {uutid}")
                continue
            if end_sample > len(audio_data):
                print(f"Warning: End time {end_time}s exceeds audio length for {uutid}, truncating")
                end_sample = len(audio_data)
            
            # 保存音频片段
            output_path = os.path.join(output_dir, f"{uutid}.wav")
            success = save_audio_segment(audio_data, start_sample, end_sample, output_path, SAMPLE_RATE)
            
            if not success:
                print(f"Failed to save segment {uutid}")

def main(wavscp_file, segments_file, output_dir):
    """主函数"""
    print("Loading wav.scp...")
    wav_dict = load_wavscp(wavscp_file)
    
    print("Loading segments...")
    segments_dict = load_segments(segments_file)
    
    print("Processing audio files...")
    process_audio(wav_dict, segments_dict, output_dir)
    
    print("Done!")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Split audio files according to segments file")
    parser.add_argument("wavscp", help="Path to wav.scp file")
    parser.add_argument("segments", help="Path to segments file")
    parser.add_argument("outdir", help="Output directory for segments")
    args = parser.parse_args()
    
    main(args.wavscp, args.segments, args.outdir)
