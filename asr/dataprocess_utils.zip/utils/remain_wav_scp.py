# ximalaya的xi1

import os
import sys
wav_scp_path = {}
# 读取原始的wav.scp
wav_scp_file = sys.argv[1]
output_dir = sys.argv[2]
remain_wav_scp_file = sys.argv[3]

with open(wav_scp_file) as f1:
    for line in f1:
            
        wav_id, wav_path = line.strip().split("\t", 1)
        #file_path = os.path.join(output_dir, wav_id + ".txt")
        file_path = os.path.join(output_dir, wav_id + ".segments")
        if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
            print(f"{file_path} already exists, skipping")
        else:
            wav_scp_path[wav_id] = wav_path


# 将wav_scp_path 写入文件wav.scp.3.remain中

with open(remain_wav_scp_file, "w") as f:
    for wav_id, wav_path in wav_scp_path.items():
        f.write(f"{wav_id}\t{wav_path}\n")



# python wav.scp result_dir(可以识别结果的路径，也可以是segments_merge的路径) remain_wav.scp 