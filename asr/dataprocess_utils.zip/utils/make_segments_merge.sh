#!/bin/bash

# 设置路径变量
utils_dir="/home/wangweifei/repository/wair/asr_project/utils"
segment_dir="$1"
segment_merge_dir="$2"
output_txt="$3" # 新增：输出的segments_paths.txt文件路径


# 检查参数是否为空
if [ -z "$segment_dir" ] || [ -z "$segment_merge_dir" ]; then
    echo "Usage: $0 <segment_dir> <segment_merge_dir>"
    exit 1
fi

# 检查目录是否存在
if [ ! -d "$segment_dir" ]; then
    echo "Error: $segment_dir does not exist or is not a directory."
    exit 1
fi

# if [ ! -d "$segment_merge_dir" ]; then
#     echo "Error: $segment_merge_dir does not exist or is not a directory."
#     exit 1
# fi

if [ ! -d "$segment_merge_dir" ]; then
    echo "$segment_merge_dir does not exist. Creating directory..."
    mkdir -p "$segment_merge_dir"
    if [ $? -ne 0 ]; then
        echo "Error: Unable to create $segment_merge_dir directory."
        exit 1
    fi
fi

# 遍历segment_dir目录下所有以.segments结尾的文件
for segment_file in "$segment_dir"/*.segments; do
    # 检查文件是否存在并且大小是否大于0
    if [ -s "$segment_file" ]; then
        # 提取文件名
        filename=$(basename "$segment_file")
        # 检查是否已经存在同名文件于segment_merge_dir中
        if [ -e "$segment_merge_dir/$filename" ]; then
            echo "Skipping $filename. Already exists in $segment_merge_dir."
            continue
        fi
        
        # 不足10s的合并
        python "$utils_dir/hebing.py" "$segment_file" "$segment_merge_dir/$filename.temp"
        
        # 改一下编号
        python "$utils_dir/change_index.py" "$segment_merge_dir/$filename.temp" "$segment_merge_dir/$filename"
        
        # 删除临时文件
        rm -f "$segment_merge_dir/$filename.temp"
    else
        echo "Skipping $segment_file. Empty or not accessible."
    fi
done


# 清空输出的txt文件
> "$output_txt"
# 新增：遍历segment_merge_dir目录下所有.segments文件，将其路径写入txt文件中
for merged_segment_file in "$segment_merge_dir"/*.segments; do
    if [ -s "$merged_segment_file" ]; then
        echo "$merged_segment_file" >> "$output_txt"
    fi
done

echo "Segments paths have been written to $output_txt."