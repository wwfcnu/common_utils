#!/usr/bin/env python3
# coding:utf-8

# Copyright (c) 2022 SDCI Co. Ltd (author: veelion)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import json
import time
import asyncio
import argparse
import websockets
import soundfile as sf
import statistics
# import ffmpeg
import numpy as np
import logging
import torch
import torchaudio
from subprocess import CalledProcessError, run
import librosa
# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

WS_START = json.dumps({
    'signal': 'start',
    'nbest': 1,
    'appkey': 'test',
    'continuous_decoding': True,
    'enable_voice_detection': False,
    'enable_itn': False,
    "enable_punc": False,
})
WS_END = json.dumps({
    'signal': 'end'
})


async def ws_rec(data, ws_uri):
    begin = time.time()
    conn = await websockets.connect(ws_uri, ping_timeout=200)
    # step 1: send start
    await conn.send(WS_START)
    ret = await conn.recv()
    # step 2: send audio data
    await conn.send(data)
    # step 3: send end
    await conn.send(WS_END)
    # step 4: receive result
    texts = []
    tail_elapsed = 0
    while 1:
        ret = await conn.recv()
        ret = json.loads(ret)
        if ret['type'] == 'final_result':
            try:
                nbest = json.loads(ret['nbest'])
                text = nbest[0]['sentence']
                tail_elapsed = ret['tail_elapsed']
                confidence = nbest[0]['confidence']
            except:
                text = ""
                confidence = ""
            texts.append(text)
        elif ret['type'] == 'speech_end':
            break
        else:
            nbest = json.loads(ret['nbest'])
            text = nbest[0]['sentence']
            # print(text)
    # step 5: close
    try:
        await conn.close()
    except Exception as e:
        # this except has no effect, just log as debug
        # it seems the server does not send close info, maybe
        print(e)
    time_cost = time.time() - begin
    return {
        'text': ''.join(texts),
        'tail_elapsed': tail_elapsed / 1000.0,
        'time': time_cost,
        'confidence': confidence
    }


def get_args():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument(
        '-u', '--ws_uri', default='wss://asr-dx.wair.ac.cn/general',  #wss://asr-dx.wair.ac.cn/offline wss://asr-dx.wair.ac.cn/pingbiao-offline wss://asr-cds.wair.ac.cn/offline wss://asr-dx.wair.ac.cn/xiaochu-offline
        help="websocket_server_main's uri, e.g. ws://127.0.0.1:10086")
    # parser.add_argument(
    #     '-w', '--data_list', required=True,
    #     help='path to data_list_file')
    parser.add_argument(
        '-w', '--wav_scp', required=True,
        help='path to wav_scp_file')
    parser.add_argument(
        '-s', '--save_to', required=True,
        help='path to save transcription')
    parser.add_argument(
        '-n', '--num_concurrence', type=int, required=True,
        help='num of concurrence for query')
    # parser.add_argument('-p','--process_text', default=None, help='processed text file')

    args = parser.parse_args()
    return args

def print_result(info):
    length = max([len(k) for k in info])
    for k, v in info.items():
        print(f'{k: >{length}} : {v}')

# def load_audio(file: str, sr: int, start: float, end: float):
#     """
#     Open an audio file and read as mono waveform, resampling as necessary

#     Parameters
#     ----------
#     file: str
#         The audio file to open

#     sr: int
#         The sample rate to resample the audio if necessary

#     Returns
#     -------
#     A NumPy array containing the audio waveform, in float32 dtype.
#     """
#     try:
#         # This launches a subprocess to decode audio while down-mixing and resampling as necessary.
#         # Requires the ffmpeg CLI and `ffmpeg-python` package to be installed.
#         out, _ = (
#             ffmpeg.input(file, threads=0, ss=start, t=end-start)
#             .output("-", format="s16le", acodec="pcm_s16le", ac=1, ar=sr)
#             .run(cmd=["ffmpeg", "-nostdin"], capture_stdout=True, capture_stderr=True)
#         )
#     except ffmpeg.Error as e:
#         raise RuntimeError(f"Failed to load audio: {e.stderr.decode()}") from e

#     # return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0
#     return out

def load_audio(file: str, sr: int):
    """
    Open an audio file and read as mono waveform, resampling as necessary

    Parameters
    ----------
    file: str
        The audio file to open

    sr: int
        The sample rate to resample the audio if necessary

    Returns
    -------
    A NumPy array containing the audio waveform, in float32 dtype.
    """
        # This launches a subprocess to decode audio while down-mixing and resampling as necessary.
        # Requires the ffmpeg CLI and `ffmpeg-python` package to be installed.
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    # fmt: on
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        raise RuntimeError(f"Failed to load audio: {e.stderr.decode()}") from e


    # return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0
    return out

def parse_raw(json_line):
    obj = json.loads(json_line)
    assert 'key' in obj
    assert 'wav' in obj
    assert 'txt' in obj
    key = obj['key']
    wav_file = obj['wav']
    txt = obj['txt']
    try:
        if 'start' in obj:
            assert 'end' in obj
            if 'm4a' in wav_file:
                sample_rate = 16000
                # start_frame = int(obj['start'] * sample_rate)
                # end_frame = int(obj['end'] * sample_rate)
                raw_data = load_audio(wav_file, sample_rate, obj['start'], obj['end'])
                waveform = raw_data
            else:
                sample_rate = torchaudio.backend.sox_io_backend.info(
                    wav_file).sample_rate
                start_frame = int(obj['start'] * sample_rate)
                end_frame = int(obj['end'] * sample_rate)
                waveform, _ = torchaudio.backend.sox_io_backend.load(
                    filepath=wav_file,
                    num_frames=end_frame - start_frame,
                    frame_offset=start_frame)
        else:
                waveform, sample_rate = torchaudio.load(wav_file)
        example = dict(key=key,
                        txt=txt,
                        wav=waveform,
                        sample_rate=sample_rate)
    except Exception as ex:
        logging.warning('Failed to read {}'.format(wav_file))
        logging.warning('Failed to read error {}'.format(ex))
        example = dict(key=key,
                        txt=txt,
                        wav=b'',
                        sample_rate=16000)
    
    return example

def parse_raw_new(line):    # 解析wav.scp中的行，返回字典
    key,wav_file = line.split(maxsplit=1)
    try:
        # if wav_file.endswith(".wav"):
        if wav_file.endswith((".wav", ".WAV")):  
            waveform, orig_sample_rate = sf.read(wav_file,dtype='int16')
            # assert sample_rate == 16000
            # wave_data = waveform.tobytes()
            # 如果采样率不是16k，进行重采样
            if orig_sample_rate != 16000:
                # 先将数据转换为float32以避免精度损失
                waveform = waveform.astype(np.float32) / 32768.0
                # 使用librosa进行重采样
                waveform = librosa.resample(
                    waveform, 
                    orig_sr=orig_sample_rate, 
                    target_sr=16000
                )
                # 将数据转回int16格式
                waveform = (waveform * 32768.0).astype(np.int16)

            wave_data = waveform.tobytes()
            sample_rate = 16000
        else:
            sample_rate = 16000
            raw_data = load_audio(wav_file, sample_rate)
            wave_data = raw_data
        example = dict(key=key,
                    wav=wave_data,
                    sample_rate=sample_rate)
    except Exception as e:
        logging.warning('Failed to read {}'.format(wav_file))
        logging.warning('Failed to read error {}'.format(e))
        example = dict(key=key,
                        wav=b'',
                        sample_rate=16000)

    return example

async def main(args):

    # 已经处理的文本
    process_wav_ids = set()
    if os.path.exists(args.save_to):
        with open(args.save_to,"r")as f:
            for line in f:
                line = line.strip().split("\t")
                # if len(line)==2:
                wav_id = line[0]
                process_wav_ids.add(wav_id)
        print(f"已经处理{len(process_wav_ids)}")

    lists = []
    with open(args.wav_scp, 'r', encoding='utf8') as fin:
        for line in fin:
            line = line.strip()
            wav_id,_ = line.split(maxsplit=1)
            if wav_id not in process_wav_ids:
                lists.append(line)

    print(f"剩余:{len(lists)}")

    num = 1000
    chunks = [lists[i:i + num] for i in range(0, len(lists), num)]
    for i, chunk in enumerate(chunks):
        tasks = []
        for line in chunk:
            #print(line)
            example = parse_raw_new(line)
            #print(f"example:{example}")
            # 音频时长小于0.5s?
           # if len(example['wav']) < 16000: continue
            task = asyncio.create_task(ws_rec(example['wav'], args.ws_uri))
            # print("data length {}".format(str(len(example['wav']))))
            # sf.write('/home/tangshuai/repository/asr/wenet/examples/wair/s1/exp_bpe/conformer_3w_256/test_attention_rescoring_chunk-1/network_data/test.wav', np.array(np.frombuffer(example['wav'], np.int16)), 16000)
            tasks.append((example['key'], task))
            if len(tasks) < args.num_concurrence:
                continue
            print((f'i={i}, start {args.num_concurrence} '
               f'queries @ {time.strftime("%m-%d %H:%M:%S")}'))
            with open(args.save_to, 'a+', encoding='utf8') as fsave:
                for uttid, task in tasks:
                    try:
                        result = await task
                        # logging.info(f'{uttid}的识别结果:{result["text"]}')
                        # fsave.write(uttid + '\t' + result["text"] + '\t' + str(result["confidence"]) + '\n')
                        fsave.write(uttid + '\t' + result["text"] + '\n')
                    except Exception as e:
                        print(f"--------报错----{uttid}:{e}")
                        continue
            tasks = []
            print(f'\tdone @ {time.strftime("%m-%d %H:%M:%S")}')
        if tasks:
            with open(args.save_to, 'a+', encoding='utf8') as fsave:
                for uttid, task in tasks:
                    try:
                        result = await task
                        # fsave.write(uttid + '\t' + result["text"] + '\t' + str(result["confidence"]) + '\n')
                        fsave.write(uttid + '\t' + result["text"] + '\n')
                    except:
                        continue

if __name__ == '__main__':
    args = get_args()
    asyncio.run(main(args))
