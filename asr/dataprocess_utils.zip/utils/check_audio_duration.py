import argparse
import wave
import os
from tqdm import tqdm

def short_wav(file_path, duration_threshold):
    with wave.open(file_path, 'rb') as wav_file:
        duration = wav_file.getnframes() / float(wav_file.getframerate())
        return duration < duration_threshold

# def find_short_wavs(directory, duration_threshold):
#     short_wavs = []
#     for root, dirs, files in os.walk(directory):
#         for file in files:
#             if file.endswith('.wav'):
#                 file_path = os.path.join(root, file)
#                 if short_wav(file_path, duration_threshold):
#                     short_wavs.append(file_path)
#     return short_wavs

# def find_short_wavs(directory, duration_threshold):
#     short_wavs = []
#     all_wav_files = []

#     # Collect all .wav files
#     for root, _, files in os.walk(directory):
#         for file in files:
#             if file.endswith('.wav'):
#                 all_wav_files.append(os.path.join(root, file))

#     # Process files with progress bar
#     for file_path in tqdm(all_wav_files, desc="Processing files", unit="file"):
#         if short_wav(file_path, duration_threshold):
#             short_wavs.append(file_path)

#     return short_wavs

def find_short_wavs(directory, duration_threshold):
    short_wavs = []
    for root, dirs, files in os.walk(directory):
        wav_files = [file for file in files if file.endswith('.wav')]
        for file in tqdm(wav_files, desc=f"Processing {root}", unit="file"):
            file_path = os.path.join(root, file)
            if short_wav(file_path, duration_threshold):
                short_wavs.append(file_path)
    return short_wavs

def main():
    parser = argparse.ArgumentParser(description="Check Audio")
    parser.add_argument("directory", help="Directory to search for .wav files")
    parser.add_argument("--threshold", type=float, default=0.4, help="Duration threshold for considering a .wav file short (in seconds)")
    parser.add_argument("--output", help="Output file to write the short .wav file paths", required=True)
    args = parser.parse_args()

    short_wavs = find_short_wavs(args.directory, args.threshold)
    
    with open(args.output, 'w') as output_file:
        for file_path in short_wavs:
            output_file.write(f"{file_path}\n")

def filter_wav():

    short_wavs = set()
    with open("/home/wangweifei/repository/wair/asr_project/transcribe/tv_drama/tv_part05_short_wavs.txt")as f:
        for line in f:
            wav_path = line.strip()
            short_wavs.add(wav_path)

    with open("/mnt/lustre/wangweifei/tv_drama_meta/part05/check_audio_clip_wav.scp")as f,open("/mnt/lustre/wangweifei/tv_drama_meta/part05/check_audio_clip_wav.scp.new","w")as w:
        for line in f:
            wav_id,wav_path = line.strip().split("\t")
            if wav_path not in short_wavs:
                w.write(line)
                





if __name__ == "__main__":
    #main()
    filter_wav()