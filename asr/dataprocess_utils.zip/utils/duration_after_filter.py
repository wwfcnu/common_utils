import argparse

def stat_duration(segments_file, wer_file):
    segment_data = {}
    all_duration = 0
    with open(segments_file) as f1:  
        for line in f1:
            line = line.strip()
            if line:
                segment_id, _, start, end = line.split(" ")
                segment_data[segment_id] = [segment_id, start, end]
                interval = float(end)-float(start)
                all_duration += interval

    with open(wer_file) as f2:
        total_duration = 0
        for line in f2:
            line = line.strip()
            segment_id = line
            # start = float(segment_data.get(segment_id)[1])
            # end = float(segment_data.get(segment_id)[2])
            segment = segment_data.get(segment_id, [0, 0, 0])
            start = float(segment[1])
            end = float(segment[2])

            duration = end - start
            total_duration += duration

    time = round(total_duration / 3600, 2)
    all_time = round(all_duration / 3600,2)
    return time,all_time

def stat_duration_from_segment(segments_file):
    segment_data = {}
    all_duration = 0
    with open(segments_file) as f1:  
        for line in f1:
            line = line.strip()
            if line:
                segment_id, _, start, end = line.split()
                segment_data[segment_id] = [segment_id, start, end]
                interval = float(end)-float(start)
                all_duration += interval

    all_time = round(all_duration / 3600,2)
    return all_time

def main():
    parser = argparse.ArgumentParser(description='Calculate duration from two files')
    parser.add_argument('-s', '--segments', type=str, required=True, help='File containing segment data')
    parser.add_argument('-w', '--wer', type=str, required=True, help='File containing WER data')
    args = parser.parse_args()

    time,all_time = stat_duration(args.segments, args.wer)
    print(f"筛选后的时长:{time}h")
    print(f"筛选前总时长:{all_time}h")

def test():
    parser = argparse.ArgumentParser(description='Calculate duration from two files')
    parser.add_argument('-s', '--segments', type=str, required=True, help='File containing segment data')

    args = parser.parse_args()

    all_time = stat_duration_from_segment(args.segments)

    print(f"筛选前总时长:{all_time}h")
if __name__ == "__main__":
    main()
    # test() 
