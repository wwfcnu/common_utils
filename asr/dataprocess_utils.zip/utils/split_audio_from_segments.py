from pydub import AudioSegment
import os
from tqdm import tqdm

def load_wavscp(wavscp_file):
    """加载wav.scp文件"""
    wav_dict = {}
    with open(wavscp_file, 'r', encoding='utf-8') as f:
        for line in f:
            wav_id, wav_path = line.strip().split(maxsplit=1)
            wav_dict[wav_id] = wav_path
    return wav_dict

def load_segments(segments_file):
    """加载segments文件"""
    segments_dict = {}
    with open(segments_file, 'r', encoding='utf-8') as f:
        for line in f:
            uutid, wav_id, start, end = line.strip().split()
            if wav_id not in segments_dict:
                segments_dict[wav_id] = []
            segments_dict[wav_id].append({
                'uutid': uutid,
                'start': float(start),
                'end': float(end)
            })
    return segments_dict

def process_audio(wav_dict, segments_dict, output_dir):
    """处理音频文件"""
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 遍历每个wav文件
    for wav_id, segments in tqdm(segments_dict.items()):
        if wav_id not in wav_dict:
            print(f"Warning: {wav_id} not found in wav.scp")
            continue
            
        # 读取音频文件
        wav_path = wav_dict[wav_id]
        try:
            audio = AudioSegment.from_file(wav_path)
            
            # 转换为单通道
            if audio.channels > 1:
                audio = audio.set_channels(1)
            
            # 转换采样率为16kHz
            if audio.frame_rate != 16000:
                audio = audio.set_frame_rate(16000)
            
            # 切分并保存每个片段
            for segment in segments:
                uutid = segment['uutid']
                # pydub使用毫秒为单位
                start_ms = int(segment['start'] * 1000)
                end_ms = int(segment['end'] * 1000)
                
                # 提取片段
                segment_audio = audio[start_ms:end_ms]
                
                # 保存音频（16位PCM WAV格式）
                output_path = os.path.join(output_dir, f"{uutid}.wav")
                segment_audio.export(
                    output_path,
                    format="wav",
                    parameters=["-ac", "1", "-ar", "16000", "-acodec", "pcm_s16le"]
                )
                
        except Exception as e:
            print(f"Error processing {wav_path}: {e}")
            continue

def main(wavscp_file, segments_file, output_dir):
    """主函数"""
    print("Loading wav.scp...")
    wav_dict = load_wavscp(wavscp_file)
    
    print("Loading segments...")
    segments_dict = load_segments(segments_file)
    
    print("Processing audio files...")
    process_audio(wav_dict, segments_dict, output_dir)
    
    print("Done!")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Split audio files according to segments file")
    parser.add_argument("wavscp", help="Path to wav.scp file")
    parser.add_argument("segments", help="Path to segments file")
    parser.add_argument("outdir", help="Output directory for segments")
    args = parser.parse_args()
    
    main(args.wavscp, args.segments, args.outdir)