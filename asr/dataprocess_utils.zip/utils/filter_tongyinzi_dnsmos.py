#/mnt/lustre/wangweifei/repository/asr/data/CCTV/drama/filter_paraformer
#/mnt/lustre/wangweifei/repository/asr/data/CCTV/drama/all/dnsmos
import argparse

def main(dnsmos_file, tongyinzi_file, tongyinzi_dnsmos, threshold):
    wav2dnsmos = {}
    
    # 读取 dnsmos 文件并存储到字典中
    with open(dnsmos_file) as f:
        for line in f:
            wav_id, dnsmos = line.strip().split("\t")
            wav2dnsmos[wav_id] = dnsmos

    # 读取 tongyinzi 文件并根据阈值过滤
    with open(tongyinzi_file) as f, open(tongyinzi_dnsmos, "w") as w:
        for line in f:
            wav_id = line.strip()
            dnsmos = wav2dnsmos.get(wav_id)
            if dnsmos and float(dnsmos) >= threshold:
                w.write(wav_id + "\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filter wav IDs based on DNSMOS threshold")
    parser.add_argument("--dnsmos_file", type=str, help="Path to the DNSMOS file")
    parser.add_argument("--tongyinzi_file", type=str, help="Path to the Tongyinzi file")
    parser.add_argument("--tongyinzi_dnsmos", type=str, help="Output file path for filtered results")
    parser.add_argument("--threshold", type=float, help="Threshold for DNSMOS filtering")

    args = parser.parse_args()
    main(args.dnsmos_file, args.tongyinzi_file, args.tongyinzi_dnsmos, args.threshold)
