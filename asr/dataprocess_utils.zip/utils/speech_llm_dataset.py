import os
import re
import argparse
from collections import defaultdict
from pydub import AudioSegment
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from multiprocessing import cpu_count
# 定义每个子进程处理一个前缀的音频合并
def process_prefix_audio(prefix, audio_files, output_dir, output_segments_file):
    combined_audio = AudioSegment.empty()
    segments = []
    start_time = 0
    files_to_delete = []

    try:
        # 按编号排序文件
        audio_files.sort(key=lambda x: int(x[0].split("_")[-1]))

        # 遍历该组中的每个音频文件，逐个合并
        for uttid, file_path in audio_files:
            # 加载音频文件
            audio = AudioSegment.from_mp3(file_path)
            
            # 计算音频时长（以秒为单位）
            duration = len(audio) / 1000.0  # pydub 以毫秒为单位
            
            # 结束时间 = 开始时间 + 时长
            end_time = start_time + duration
            
            # 生成 segments 信息，格式为：uttid prefix start_time end_time
            segments.append(f"{uttid} {prefix} {start_time:.3f} {end_time:.3f}")
            
            # 更新开始时间为当前结束时间
            start_time = end_time
            
            # 将当前音频合并到最终的合并音频中
            combined_audio += audio

            # 添加到删除列表
            files_to_delete.append(file_path)

        # 保存合并后的音频文件
        output_audio_file = os.path.join(output_dir, f"{prefix}.mp3")
        combined_audio.export(output_audio_file, format="mp3")
        # print(f"音频文件已合并为: {output_audio_file}")

        # 将 segments 追加写入文件
        with open(output_segments_file, "a") as seg_file:
            for segment in segments:
                seg_file.write(segment + "\n")
        # print(f"Segments 已追加写入: {output_segments_file}")

        # 返回需要删除的文件
        return files_to_delete

    except Exception as e:
        print(f"合并 {prefix} 音频文件时出现错误: {e}")
        return []


def merge_audio_by_prefix_concurrent(wav_scp_file, output_dir, output_segments_file, delete_small_files, num_workers):
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 创建一个字典用于按前缀分组音频文件
    audio_groups = defaultdict(list)

    # 读取 wav.scp 文件并按前缀分组
    with open(wav_scp_file, "r") as f:
        for line in f:
            # 每行格式: uttid path/to/audio.mp3
            uttid, file_path = line.strip().split("\t")
            # prefix = re.match(r'(.*?)(_.*)?$', uttid).group(1)  # 提取前缀（如aaa, bbb）
            prefix = '_'.join(uttid.split('_')[:-1])
            audio_groups[prefix].append((uttid, file_path))
    
    # 准备任务参数列表
    tasks = [(prefix, audio_files, output_dir, output_segments_file) for prefix, audio_files in audio_groups.items()]
    
    # 使用 ProcessPoolExecutor 执行多进程任务，并添加进度条
    all_files_to_delete = []
    with ProcessPoolExecutor(max_workers=cpu_count()) as executor:
        futures = {executor.submit(process_prefix_audio, *task): task for task in tasks}
        
        # 使用 tqdm 显示进度条
        for future in tqdm(as_completed(futures), total=len(futures), desc="合并进度"):
            try:
                result = future.result()  # 等待任务完成
                all_files_to_delete.extend(result)
            except Exception as exc:
                print(f"任务执行时出现错误: {exc}")
    
    # 删除小文件（如果指定了）
    if delete_small_files:
        for file_path in all_files_to_delete:
            try:
                os.remove(file_path)
                print(f"已删除小文件: {file_path}")
            except Exception as e:
                print(f"删除文件 {file_path} 时出现错误: {e}")
    else:
        print("跳过删除小文件操作。")


# 使用 argparse 接受命令行参数
def main():
    parser = argparse.ArgumentParser(description="合并音频并生成 segments 文件")
    
    # 定义三个参数：wav_scp, output_dir, output_segments, num_workers
    parser.add_argument("-w","--wav_scp", required=True, help="包含音频文件路径的 wav.scp 文件")
    parser.add_argument("-o","--output_dir", required=True, help="合并后的音频文件输出目录")
    parser.add_argument("-s","--output_segments", required=True, help="输出的 segments 文件路径")
    parser.add_argument("-d","--delete_small_files", action="store_true", help="是否删除小文件，默认为不删除")
    parser.add_argument("-n","--num_workers", type=int, default=4, help="进程数，默认为 4")

    args = parser.parse_args()
    
    # 调用合并函数
    merge_audio_by_prefix_concurrent(args.wav_scp, args.output_dir, args.output_segments, args.delete_small_files, args.num_workers)


if __name__ == "__main__":
    main()
