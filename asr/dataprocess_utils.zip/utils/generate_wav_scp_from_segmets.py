'''
# 生成wav.scp从segments文件中
# 读取segments文件，{uttid} {wav_id} {start} {end}
# 指定一个路径前缀prefix_path：{/mnt/lustre/wair-audio/data/tts_datasets/podcast/part05_processed} 可以指定的参数
# 完整路径为 wav_path = {prefix_path}/{wav_id}/{uttid}.mp3
# 最终得到的wav.scp文件为{uttid}\t{wav_path}
'''
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse

def generate_wav_scp(prefix_path, segments_file, output_file):
    with open(segments_file, "r", encoding="utf-8") as seg_f, \
         open(output_file, "w", encoding="utf-8") as out_f:
        for line in seg_f:
            parts = line.strip().split()
            if len(parts) != 4:
                continue  # 跳过格式不对的行
            uttid, wav_id, start, end = parts
            wav_path = f"{prefix_path}/{wav_id}/{uttid}.mp3"
            out_f.write(f"{uttid}\t{wav_path}\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate wav.scp from segments file.")
    parser.add_argument("-p", "--prefix_path", required=True, help="Prefix path for wav files")
    parser.add_argument("-s", "--segments", required=True, help="Input segments file")
    parser.add_argument("-o", "--output", required=True, help="Output wav.scp file")

    args = parser.parse_args()
    generate_wav_scp(args.prefix_path, args.segments, args.output)