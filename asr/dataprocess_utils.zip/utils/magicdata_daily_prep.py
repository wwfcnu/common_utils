#!/usr/bin/env python
# coding=utf-8

import os, sys, shutil, argparse, codecs
from random import shuffle


parser = argparse.ArgumentParser(description='Generate data directory, and text wav.scp utt2spk files in the directory')

parser.add_argument('-i', '--input_dirs', nargs='+', help="Input directories", required=True)
parser.add_argument('-t', '--transcripts', help="Input directories", required=True)
parser.add_argument('-o', '--output_dir', help="Output directory", required=True)
parser.add_argument("-ds", "--dont-shuffle", action='store_true', default=False, help="Do not shuffle the data")

args = parser.parse_args()


input_dirs = args.input_dirs
trans_dir = args.transcripts
output_dir = args.output_dir

def process(src_str):
    puncs = ['[+]','[*]','[LAUGHTER]', '[SONANT]', '[MUSIC]', '[ENS]', '[NPS]', '[SYSTEM]', '[PII]', '+']
    for punc in puncs:
        src_str = src_str.replace(punc, '')
    return src_str

wavs = []
dirs = []
for dir in input_dirs:
    cur_dirs = os.listdir(dir)
    for d in cur_dirs:
        files = os.listdir(os.path.join(dir, d))
        for file in files:
            if(file.endswith('.wav')):
                wavs.append(file)
                dirs.append(os.path.join(dir, d))

text_dict = dict()
#file = "UTTRANSINFO.txt"
file = "UTTERANCEINFO.txt"
with codecs.open(os.path.join(trans_dir, file), mode='r', encoding='utf-8', errors='ignore') as fi:
    # Skip the first line
    next(fi)
    for line in fi:
        lines = line.strip().split('\t')

        # if len(lines) < 5:
        #     text_dict[lines[1]] = ""
        # else:

        PROMPT = lines[3]
        Trans = lines[4]

        text_dict[lines[1].replace(".wav","")] = process(Trans)
#print(text_dict)
#print wavs
utts = []
for i,x in enumerate(wavs):
		utts.insert(i, x.split('.wav')[0])
		
utt2wav = dict(zip(utts, wavs))   
utt2dir = dict(zip(utts, dirs))

if(args.dont_shuffle):
	utts.sort()
else:
    shuffle(utts)
	
out_utts = utts
out_utts.sort()

if os.path.exists(output_dir):
    shutil.rmtree(output_dir)
	
os.makedirs(output_dir) 
	
with open(output_dir + '/text', 'w+') as text:
    for ele in out_utts:
        utt_id = ele
        trn = text_dict[utt_id]
        if trn != '':
            text.write("%s %s\n" % (utt_id, trn))
			
with open(output_dir + '/wav.scp', 'w+') as wavscp:
    for ele in out_utts:
        utt_id = ele
        abs_path = os.path.abspath(utt2dir[ele] + '/' + utt2wav[ele])
        wavscp.write("%s %s\n" % (utt_id, abs_path))
			
with open(output_dir + '/utt2spk', 'w+') as utt2spk:
    for ele in out_utts:
        utt_id = ele
        skp_id = ele.split('-', maxsplit=1)[0]
        utt2spk.write("%s %s\n" % (utt_id, skp_id))
			
