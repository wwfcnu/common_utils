from pydub import AudioSegment
import numpy as np
from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess
import os
import argparse
from collections import defaultdict

def load_processed_uttids(output_text_path):
    """
    加载已处理的 uttid 集合
    返回: set of processed uttids
    """
    processed = set()
    if os.path.exists(output_text_path):
        print(f"Found existing output file: {output_text_path}")
        with open(output_text_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 1:
                        processed.add(parts[0])
        print(f"Loaded {len(processed)} already processed utterances")
    return processed

def load_wav_scp(wav_scp_path):
    """
    加载 wav.scp 文件
    返回: {wav_id: wav_path} 的字典
    """
    wav_dict = {}
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split('\t')
                if len(parts) >= 2:
                    wav_id = parts[0]
                    wav_path = parts[1]
                    wav_dict[wav_id] = wav_path
    return wav_dict

def load_segments(segments_path, processed_uttids=None):
    """
    加载 segments 文件并按 wav_id 分组,过滤已处理的 uttid
    返回: {wav_id: [(uttid, start, end), ...]} 的字典
    """
    if processed_uttids is None:
        processed_uttids = set()
    
    segments_by_wav = defaultdict(list)
    total_segments = 0
    skipped_segments = 0
    
    with open(segments_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split()
                if len(parts) >= 4:
                    uttid = parts[0]
                    total_segments += 1
                    
                    # 跳过已处理的 uttid
                    if uttid in processed_uttids:
                        skipped_segments += 1
                        continue
                    
                    wav_id = parts[1]
                    start = float(parts[2])
                    end = float(parts[3])
                    segments_by_wav[wav_id].append((uttid, start, end))
    
    print(f"Total segments: {total_segments}, Skipped: {skipped_segments}, To process: {total_segments - skipped_segments}")
    return dict(segments_by_wav)

def process_wav_segments(wav_path, segments_list, target_sr=16000):
    """
    处理单个音频文件的多个段落
    返回: (audio_arrays, uttids)
    """
    try:
        # 加载音频文件
        audio = AudioSegment.from_file(wav_path)
        audio = audio.set_channels(1)  # 转为单通道
        audio = audio.set_frame_rate(target_sr)  # 设置采样率
        
        audio_arrays = []
        uttids = []
        
        # 处理所有段落
        for uttid, start, end in segments_list:
            start_ms = int(start * 1000)
            end_ms = int(end * 1000)
            
            # 切片音频段
            segment = audio[start_ms:end_ms]
            
            # 转换为 numpy 数组
            audio_array = np.array(segment.get_array_of_samples(), dtype=np.float32)
            
            # 归一化到 [-1, 1] 范围
            audio_array = audio_array / 32768.0  # 16位音频的最大值
            
            audio_arrays.append(audio_array)
            uttids.append(uttid)
        
        return audio_arrays, uttids
        
    except Exception as e:
        print(f"Error processing audio file '{wav_path}': {e}")
        return [], []

def run_asr_batch(wav_scp_path, segments_path, output_text_path, 
                  model_name="iic/SenseVoiceSmall", device="cuda:0", 
                  batch_size=16, language="auto"):
    """
    批量语音识别主函数 - 按 wav_id 循环处理,跳过已处理的 uttid
    """
    # 加载已处理的 uttid
    processed_uttids = load_processed_uttids(output_text_path)
    
    # 加载配置文件
    print("Loading wav.scp and segments...")
    wav_dict = load_wav_scp(wav_scp_path)
    segments_by_wav = load_segments(segments_path, processed_uttids)
    
    print(f"Loaded {len(wav_dict)} wav files")
    print(f"Found segments for {len(segments_by_wav)} wav_ids to process")
    
    # 如果没有需要处理的段落,直接返回
    if not segments_by_wav:
        print("No new segments to process. All done!")
        return
    
    # 初始化模型
    print("Loading ASR model...")
    model = AutoModel(
        model=model_name,
        device=device,
    )
    
    # 打开输出文件(追加模式)
    with open(output_text_path, 'a', encoding='utf-8') as output_file:
        
        # 循环处理每个 wav_id
        for wav_id in segments_by_wav.keys():
            if wav_id not in wav_dict:
                print(f"Warning: wav_id '{wav_id}' not found in wav.scp")
                continue
                
            wav_path = wav_dict[wav_id]
            if not os.path.exists(wav_path):
                print(f"Warning: audio file '{wav_path}' not found")
                continue
            
            segments_list = segments_by_wav[wav_id]
            print(f"\nProcessing wav_id: {wav_id} ({len(segments_list)} segments)")
            print(f"Audio file: {wav_path}")
            
            # 处理当前音频文件的所有段落
            audio_arrays, uttids = process_wav_segments(wav_path, segments_list)
            
            if not audio_arrays:
                print(f"No valid segments for wav_id: {wav_id}")
                continue
            
            print(f"Generated {len(audio_arrays)} audio segments")
            
            # 对当前 wav_id 的所有段落进行批量推理
            print(f"Running ASR inference for wav_id: {wav_id}...")
            try:
                res = model.generate(
                    audio_arrays,
                    language=language,
                    cache={},
                    use_itn=True,  # 开启
                    batch_size=batch_size,
                )
                
                # 写入结果
                for i, result in enumerate(res):
                    if i < len(uttids):
                        uttid = uttids[i]
                        text = result.get('text', '')
                        # 可选:清理文本中的标记
                        # text = rich_transcription_postprocess(text)
                        output_file.write(f"{uttid}\t{text}\n")
                        # print(f"  {uttid}: {text[:50]}...")
                
                output_file.flush()  # 确保立即写入文件
                print(f"Completed wav_id: {wav_id} ({len(res)} utterances)")
                
            except Exception as e:
                print(f"Error during ASR inference for wav_id {wav_id}: {e}")
                continue
    
    print(f"\nASR batch processing completed! Results written to {output_text_path}")

def main():
    parser = argparse.ArgumentParser(description='Batch ASR with wav.scp and segments - grouped by wav_id (skip processed)')
    parser.add_argument('--wav-scp', required=True, help='Path to wav.scp file')
    parser.add_argument('--segments', required=True, help='Path to segments file')
    parser.add_argument('--output-text', required=True, help='Path to output text file')
    parser.add_argument('--model', default='iic/SenseVoiceSmall', help='ASR model name')
    parser.add_argument('--device', default='cuda:0', help='Device to use')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size for segments of same wav_id')
    parser.add_argument('--language', default='auto', help='Language code')
    
    args = parser.parse_args()
    
    run_asr_batch(
        wav_scp_path=args.wav_scp,
        segments_path=args.segments,
        output_text_path=args.output_text,
        model_name=args.model,
        device=args.device,
        batch_size=args.batch_size,
        language=args.language
    )

if __name__ == "__main__":
    main()
    # 命令行用法示例:
    # python batch_asr_skip_processed.py --wav-scp wav.scp --segments segments --output-text sensevoice.txt
    # 如果中断后重新运行,会自动跳过已处理的utterance