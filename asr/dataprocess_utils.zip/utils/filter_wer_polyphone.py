import re
import argparse

# def find_different_words_with_positions(text1, text2):
#     words1 = text1.split()
#     words2 = text2.split()

#     different_words_in_text1 = [(word, index) for index, word in enumerate(words1) if word not in words2]
#     different_words_in_text2 = [(word, index) for index, word in enumerate(words2) if word not in words1]

#     return different_words_in_text1, different_words_in_text2
import difflib

def compute_wer_with_pinyin(lab_text, rec_text):
    lab = lab_text.strip().split()
    rec = rec_text.strip().split()

    matcher = difflib.SequenceMatcher(None, lab, rec)
    N = len(lab)
    C = S = D = I = 0

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            C += (i2 - i1)
        elif tag == 'replace':
            for ref_char, hyp_char in zip(lab[i1:i2], rec[j1:j2]):
                ref_pinyin = lazy_pinyin(ref_char)[0]
                hyp_pinyin = lazy_pinyin(hyp_char)[0]
                if ref_pinyin == hyp_pinyin:
                    C += 1  # 看作正确
                else:
                    S += 1  # 真正替换错误
            # 如果替换段长度不同，需要补充为 D 或 I
            extra = abs((i2 - i1) - (j2 - j1))
            if i2 - i1 > j2 - j1:
                D += extra
            elif j2 - j1 > i2 - i1:
                I += extra
        elif tag == 'delete':
            D += (i2 - i1)
        elif tag == 'insert':
            I += (j2 - j1)

    wer = (S + D + I) / N if N > 0 else 0
    # return {
    #     "WER": round(wer * 100, 2),
    #     "N": N,
    #     "C": C,
    #     "S": S,
    #     "D": D,
    #     "I": I,
    # }
    return wer,N,C,S,D,I

def find_different_words_with_positions(text1, text2):
    words1 = text1.split()
    words2 = text2.split()
    
    different_words_text1 = []
    different_words_text2 = []
    
    for idx, word1 in enumerate(words1):
        if idx >= len(words2) or word1 != words2[idx]:
            different_words_text1.append((word1, idx))
    
    for idx, word2 in enumerate(words2):
        if idx >= len(words1) or word2 != words1[idx]:
            different_words_text2.append((word2, idx))
    
    return different_words_text1, different_words_text2
    
from pypinyin import lazy_pinyin

def is_homophone(word1, word2):
    return lazy_pinyin(word1) == lazy_pinyin(word2)


def cal_tongyinzi(lab,rec):
    # 比较拼音是否一样
    different_words_in_text1, different_words_in_text2 = find_different_words_with_positions(lab, rec)

    lab_diff = ''.join([f"{word[0]}" for word in different_words_in_text1])
    rec_diff = ''.join([f"{word[0]}" for word in different_words_in_text2])

    # print(lab_diff,rec_diff)
    tongyinzi = is_homophone(lab_diff, rec_diff)
    #print(tongyinzi)

    return tongyinzi

def filter_tongyinzi_wer(text_data):
    utt_parts = text_data.strip().split('\n\nutt: ')
    result = []
    for utt_part in utt_parts:
        lines = utt_part.splitlines()
        if not lines[0].strip():
            lines = lines[1:]  # Remove the empty line at the beginning if it exists
        wer_line = lines[1]
        wer_match = re.search(r'WER: (\d+\.\d+) %', wer_line) 
        D_match = re.search(r'D=(\d+)', wer_line)
        I_match = re.search(r'I=(\d+)', wer_line)

        # lab,rec
        lab_line = lines[2]
        rec_line = lines[3]
        
        lab_match = re.search(r"lab:\s*(.*)$",lab_line)
        rec_match = re.search(r"rec:\s*(.*)$",rec_line)
        lab =lab_match.group(1)
        rec =rec_match.group(1)
        # print(lab,rec)

        # 放宽筛选，容忍同音字
        wer,N,C,S,D,I = compute_wer_with_pinyin(lab, rec)
        # if wer <= 0.05:
        if wer <= 0.05 and D == 0 and I == 0:
            utt = lines[0]
            #result.append(f"{utt}\t{wer_value:.2%}")
            result.append(f"{utt}")
        # if wer_match:
        #     wer_value = float(wer_match.group(1)) / 100  # Convert WER percentage to a float
        #     D_value = float(D_match.group(1))
        #     I_value = float(I_match.group(1))
        #     if wer_value <= 0.05 and D_value == 0 and I_value ==0:
        #         tongyinzi = cal_tongyinzi(lab,rec)
        #         if tongyinzi:
        #             utt = lines[0]
        #             #result.append(f"{utt}\t{wer_value:.2%}")
        #             result.append(f"{utt}")
    return '\n'.join(result).replace("utt: ","")


def filter_wer(text_data):
    utt_parts = text_data.strip().split('\n\nutt: ')
    result = []
    for utt_part in utt_parts:
        lines = utt_part.splitlines()
        if not lines[0].strip():
            lines = lines[1:]  # Remove the empty line at the beginning if it exists
        wer_line = lines[1]
        wer_match = re.search(r'WER: (\d+\.\d+) %', wer_line)
        if wer_match:
            wer_value = float(wer_match.group(1)) / 100  # Convert WER percentage to a float
            if wer_value <= 0.05:
                utt = lines[0]
                #result.append(f"{utt}\t{wer_value:.2%}")
                result.append(f"{utt}")
    return '\n'.join(result).replace("utt: ","")

def main():
    parser = argparse.ArgumentParser(description="Filter non-zero wer data from a file and write it to another file")
    parser.add_argument("-i", "--input", help="Input file path", required=True)
    parser.add_argument("-o", "--output", help="Output file path", required=True)
    args = parser.parse_args()

    file_path = args.input
    output_file_path = args.output

    with open(file_path, 'r', encoding='utf-8') as file:
        data = file.read()

    # Apply filtering function
    filtered_data = filter_tongyinzi_wer(data)

    # Write filtered data to a new file
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(filtered_data + "\n")

def main_new():
    parser = argparse.ArgumentParser(description="Filter non-zero wer data from a file and write it to another file")
    parser.add_argument("-i", "--input", help="Input file path", required=True)
    parser.add_argument("-o", "--output", help="Output file path", required=True)
    args = parser.parse_args()

    file_path = args.input
    output_file_path = args.output

    with open(file_path, 'r', encoding='utf-8') as file:
        data = file.read()

    # Apply filtering function
    filtered_data = filter_wer(data)

    # Write filtered data to a new file
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(filtered_data + "\n")

if __name__ == "__main__":
    main()
    #main_new()
