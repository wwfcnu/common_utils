#!/usr/bin/env python3
# coding:utf-8

# Copyright (c) 2022 SDCI Co. Ltd (author: veelion)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import json
import time
import asyncio
import argparse
import websockets
import soundfile as sf
import statistics
import numpy as np
from subprocess import CalledProcessError, run

def load_audio(file: str, sr: int = 16000):
    """
    Open an audio file and read as mono waveform, resampling as necessary

    Parameters
    ----------
    file: str
        The audio file to open

    sr: int
        The sample rate to resample the audio if necessary

    Returns
    -------
    A NumPy array containing the audio waveform, in float32 dtype.
    """

    # This launches a subprocess to decode audio while down-mixing
    # and resampling as necessary.  Requires the ffmpeg CLI in PATH.
    # fmt: off
    cmd = [
        "ffmpeg",
        "-nostdin",
        "-threads", "0",
        "-i", file,
        "-f", "s16le",
        "-ac", "1",
        "-acodec", "pcm_s16le",
        "-ar", str(sr),
        "-"
    ]
    # fmt: on
    try:
        out = run(cmd, capture_output=True, check=True).stdout
    except CalledProcessError as e:
        raise RuntimeError(f"Failed to load audio: {e.stderr.decode()}") from e

    #return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0
    return np.frombuffer(out, np.int16)

WS_START = json.dumps({
    'signal': 'start',
    'nbest': 1,
    'appkey': 'test',
    'continuous_decoding': False,
    'enable_voice_detection': False,
    'enable_itn': False,
    "enable_punc": False,
})

WS_END = json.dumps({
    'signal': 'end'
})


async def ws_rec(data, ws_uri):
    begin = time.time()
    conn = await websockets.connect(ws_uri, ping_timeout=200)
    # step 1: send start
    await conn.send(WS_START)
    ret = await conn.recv()
    # step 2: send audio data
    await conn.send(data)
    # step 3: send end
    await conn.send(WS_END)
    # step 4: receive result
    texts = []
    while 1:
        ret = await conn.recv()
        ret = json.loads(ret)
        # print(f"请求结果：{ret}")
        if ret['type'] == 'final_result':
            # 加入try
            try:
                nbest = json.loads(ret['nbest'])
                text = nbest[0]['sentence']
                confidence = nbest[0]['confidence']

            except:
                text = ""
                confidence = ""
            texts.append(text)
        elif ret['type'] == 'speech_end':
            break
    # step 5: close
    try:
        await conn.close()
    except Exception as e:
        # this except has no effect, just log as debug
        # it seems the server does not send close info, maybe
        print(e)
    time_cost = time.time() - begin
    return {
        'text': ''.join(texts),
        'time': time_cost,
        'confidence':confidence
    }


def get_args():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument(
        '-u', '--ws_uri', default='wss://asr-dx.wair.ac.cn/offline',
        help="websocket_server_main's uri, e.g. ws://127.0.0.1:10086")
    parser.add_argument(
        '-w', '--wav_scp', required=True,
        help='path to wav_scp_file')
    # parser.add_argument(
    #     '-t', '--trans', required=True,
    #     help='path to trans_text_file of wavs')
    parser.add_argument(
        '-s', '--save_to', required=True,
        help='path to save transcription')
    parser.add_argument(
        '-n', '--num_concurrence', type=int, required=True,
        help='num of concurrence for query')
    args = parser.parse_args()
    return args

def get_args_new():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument(
        '-u', '--ws_uri', required=True,
        help="websocket_server_main's uri, e.g. ws://127.0.0.1:10010")
    parser.add_argument(
        '-w', '--wav_file', required=True,
        help='path to wav_file')
    args = parser.parse_args()
    return args

def print_result(info):
    length = max([len(k) for k in info])
    for k, v in info.items():
        print(f'\t{k: >{length}} : {v}')

async def main_new(args):
    wav_file = args.wav_file
    ws_uri = args.ws_uri
    data, sr = sf.read(wav_file, dtype='int16')
    assert sr == 16000
    duration = (len(data)) / 16000
    print(f"wav_file: {wav_file}, duration: {duration}")
    rsp = await ws_rec(data.tobytes(), ws_uri)
    text = rsp['text']
    cost_time = rsp['time']
    print(f"reco text: {text}, cost_time: {cost_time}")

async def main(args):
    wav_scp = []
    total_duration = 0
    with open(args.wav_scp) as f:
        for line in f:
            zz = line.strip().split()
            assert len(zz) == 2
            data, sr = sf.read(zz[1], dtype='int16')
            assert sr == 16000
            duration = (len(data)) / 16000
            total_duration += duration
            wav_scp.append((zz[0], data.tobytes()))
    print(f'{len(wav_scp) = }, {total_duration = }')

    tasks = []
    failed = 0
    texts = []
    request_times = []
    begin = time.time()
    for i, (_uttid, data) in enumerate(wav_scp):
        task = asyncio.create_task(ws_rec(data, args.ws_uri))
        tasks.append((_uttid, task))
        if len(tasks) < args.num_concurrence:
            continue
        print((f'{i=}, start {args.num_concurrence} '
               f'queries @ {time.strftime("%m-%d %H:%M:%S")}'))
        for uttid, task in tasks:
            try:
                result = await task
                # texts.append(f'{uttid}\t{result["text"]}\n')
                texts.append(f'{uttid}\t{result["text"]}\t{result["confidence"]}\n')
            except Exception as e:
                print(f"--报错音频{uttid}：{e}")
                continue
            request_times.append(result['time'])
        tasks = []
        print(f'\tdone @ {time.strftime("%m-%d %H:%M:%S")}')
    if tasks:
        for uttid, task in tasks:
            try:
                result = await task
                texts.append(f'{uttid}\t{result["text"]}\t{result["confidence"]}\n')
                # print(texts)
            except Exception as e:
                print(e)
            request_times.append(result['time'])
    request_time = time.time() - begin
    rtf = request_time / total_duration
    print('For all concurrence:')
    print_result({
        'failed': failed,
        'total_duration': total_duration,
        'request_time': request_time,
        'RTF': rtf,
    })
    print('For one request:')
    print_result({
        'mean': statistics.mean(request_times),
        'median': statistics.median(request_times),
        'max_time': max(request_times),
        'min_time': min(request_times),
    })
    with open(args.save_to, 'w', encoding='utf8') as fsave:
        fsave.write(''.join(texts))
    # caculate CER
    # cmd = (f'python ./utils/compute-wer.py --char=1 --v=1 '
    #        f'{args.trans} {args.save_to} > '
    #        f'/home/wangweifei/repository/wair/baseline_test_datasets/wair_result_offline/{os.path.basename(args.save_to)}.wer')
    # print(cmd)
    # os.system(cmd)
    print('done')


if __name__ == '__main__':
    args = get_args()
    asyncio.run(main(args))
    # args = get_args_new()
    # asyncio.run(main_new(args))
