import os
import time
import torch
# from funasr_onnx import SenseVoiceSmall
# from funasr_onnx.utils.postprocess_utils import rich_transcription_postprocess
from omnisense import OmniSenseVoiceSmall, OmniTranscription

# model_dir = "iic/SenseVoiceSmall"
# model = SenseVoiceSmall(model_dir, batch_size=10, quantize=False, device_id=1)

# # inference
# wav_or_scp = ["tests/data/example.wav"]
# for textnorm in ["woitn", "withitn"]:
#     print(f"\n====== Text normalization: {textnorm} ======")
#     start_time = time.time()
#     res = model(wav_or_scp, language="auto", textnorm=textnorm)
#     print(f"Time cost: {time.time() - start_time:.2f}s")

#     print(res)
    # print([rich_transcription_postprocess(i) for i in res])




# # Function to write results to a text file
# def write_to_file(output_file, res,wav_ids):
#     with open(output_file, "a") as f:
#         # for transcription in res:
#         #     f.write(str(transcription) + "\n")  # Writing each transcription to the file
#         for idx, transcription in enumerate(res):
#             f.write(f"{wav_ids[idx]}\t{transcription}\n") 
# # Batch processing function
# def process_in_batches(wav_scp_list, wav_id_list, batch_num, model, output_file):
#     for i in range(0, len(wav_scp_list), batch_num):
#         batch_wav_paths = wav_scp_list[i:i + batch_num]
#         batch_wav_ids = wav_id_list[i:i + batch_num]
#         print(f"Processing batch {i // batch_num + 1}")
#         res = model.transcribe(batch_wav_paths, language="auto", textnorm="woitn", timestamps=True, num_workers=64,batch_size=64)
#         write_to_file(output_file, res, batch_wav_ids)


# start_time = time.time()
# # Parameters
# model_dir = "iic/SenseVoiceSmall"
# model = OmniSenseVoiceSmall(model_dir, quantize=False, device_id=0 if torch.cuda.is_available() else -1)
# wav_scp = "/mnt/lustre/wangweifei/tv_drama_meta/mos_check_audio_clip_wav_00_06.scp"
# batch_num  = 3000  # Define the size of the batch 5000:39g 3000:28
# output_file = "/home/wangweifei/repository/wair/asr_project/transcribe/sensevoice/transcription_results.txt"

# # Inference

# wav_scp_list = []
# wav_id_list = []
# with open(wav_scp) as f:
#     for line in f:
#         wav_id, wav_path = line.strip().split("\t")
#         wav_scp_list.append(wav_path)
#         wav_id_list.append(wav_id)

# # Ensure output file is empty before writing new results
# if os.path.exists(output_file):
#     os.remove(output_file)

# # Process and save transcriptions in batches
# process_in_batches(wav_scp_list[:10000],wav_id_list, batch_num, model, output_file)
# # res = model.transcribe(wav_scp_list, language="auto", textnorm="woitn", timestamps=True,num_workers=64,batch_size=64)
# # write_to_file(output_file, res,wav_id_list)
# print(f"Total time cost: {time.time() - start_time:.2f}s")


def calculate_rtf(file_path, total_time_cost):
    import  re 
    # Read the file content
    with open(file_path, 'r') as f:
        content = f.read()

    # Regex pattern to extract the duration from the transcription results
    pattern = r"duration=(\d+\.\d+)"

    # Find all durations in the transcription results
    durations = re.findall(pattern, content)

    # Convert all durations to float and calculate the total duration
    total_duration = sum(map(float, durations))

    # Calculate the Real-Time Factor (RTF)
    rtf = total_time_cost / total_duration if total_duration > 0 else 0

    return total_duration, rtf


file_path = "/home/wangweifei/repository/wair/asr_project/transcribe/sensevoice/transcription_results.txt"

total_time_cost = 101.83  # Total processing time in seconds

total_duration, rtf = calculate_rtf(file_path, total_time_cost)

print(f"Total duration: {total_duration:.2f} seconds") # 39565.80 seconds
print(f"RTF (Real-Time Factor): {rtf:.4f}") # RTF (Real-Time Factor): 0.0026


# whisper_A800 Successfully installed OmniSenseVoice-0.0.1 cytoolz-0.12.3 funasr-1.1.6 funasr_onnx-0.4.1 intervaltree-3.1.0 kaldi-native-fbank-1.20.0 kaldialign-0.9.1 lhotse-1.27.0 lilcom-1.8.0 modelscope-1.18.0 onnx-1.16.2 tabulate-0.9.0 toolz-0.12.1
