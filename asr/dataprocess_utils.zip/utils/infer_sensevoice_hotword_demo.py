#pip install kaldi_native_fbank
from pathlib import Path
from modelscope import snapshot_download
# model_dir = snapshot_download('dengcunqin/SenseVoiceSmall_hotword')
model_dir = "/home/wangweifei/.cache/modelscope/hub/dengcunqin/SenseVoiceSmall_hotword"
import sys
sys.path.append(model_dir)

from sensevoice_bin_hot import SenseVoiceSmall
from funasr_onnx.utils.postprocess_utils import rich_transcription_postprocess

model = SenseVoiceSmall(model_dir, batch_size=10, quantize=False)

# wav_or_scp = [model_dir+"/asr_example.wav".format(Path.home(), model_dir)]
wav_or_scp = ["/mnt/lustre/wangweifei/asr_datasets/15xiao/16k/65.wav","/mnt/lustre/wangweifei/asr_datasets/15xiao/16k/66.wav"]

res = model(wav_or_scp,hotwords_str='',hotwords_score=1.0)
print('SenseVoiceSmall output:',[rich_transcription_postprocess(i) for i in res])

res = model(wav_or_scp,hotwords_str='覃琪舒婳|打磨院',hotwords_score=1.0)
print('SenseVoiceSmall_hotword output:',[rich_transcription_postprocess(i) for i in res])

'''
SenseVoiceSmall output: ['我想知道五零九班琴棋书画同学的作文批改情况', '查询五零九班杨锦瑜同学的作文']
当前热词： ['覃琪舒婳', '打磨院']
SenseVoiceSmall_hotword output: ['我想知道五零九班琴琪书画同学的作文批改情况', '查询五零九班杨锦瑜同学的作文']

''''
# wav_or_scp = [model_dir+"/A2_0.wav".format(Path.home(), model_dir)]

# res = model(wav_or_scp,hotwords_str='',hotwords_score=1.0)
# print('SenseVoiceSmall output:',[rich_transcription_postprocess(i) for i in res])

# res = model(wav_or_scp,hotwords_str='秀妹',hotwords_score=1.0)
# print('SenseVoiceSmall_hotword output:',[rich_transcription_postprocess(i) for i in res])