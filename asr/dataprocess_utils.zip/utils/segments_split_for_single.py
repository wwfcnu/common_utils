import argparse
import os

def main(input_file, output_dir, segments_path=None):
    data = {}
    with open(input_file, 'r') as f:
        for line in f:
            line = line.strip().split()
            data.setdefault(line[1], []).append((line[0], line[2], line[3]))

    # 将每个 wav_id 对应的行写入文件
    for wav_id, segments in data.items():
        with open(f"{output_dir}/{wav_id}.segments", "w") as w:
            for segment in segments:
                w.write(f"{segment[0]} {wav_id} {segment[1]} {segment[2]}\n")

    # 如果提供了segments_path，则将output_dir下所有文件的路径写入到segments_path中
    if segments_path:
        with open(segments_path, "w") as sp:
            for filename in os.listdir(output_dir):
                if filename.endswith("segments"):
                    sp.write(os.path.join(output_dir, filename) + "\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process segments data and split them into individual files based on wav_id.")
    parser.add_argument("input_file", type=str, help="Path to the input segments file.")
    parser.add_argument("output_dir", type=str, help="Directory to save the output segmented files.")
    parser.add_argument("--segments_path", type=str, help="Path to save the list of segment files.")
    args = parser.parse_args()

    main(args.input_file, args.output_dir, args.segments_path)
# 讲一个完整的semgnets文件切分成每个单独文件的segments