# jieba分词，包括词表，自有词典，专有词汇和英文缩写的处理，特殊符号处理'的处理，中英文混合处理，英文的处理
# 通用模型中英文缩写就不拆开了(比如B2B--如果asr的词典中有它直接就能输出、APP等 )

import argparse
import jieba
import re

'''
cut(self, sentence, cut_all=False, HMM=True, use_paddle=False):
1. 更换主词典和自定义词典
jieba.set_dictionary('/mnt/lustre/wangweifei/utils/jieba_dict/jieba.count')
jieba.load_userdict("/mnt/lustre/wangweifei/utils/jieba_dict/xiaochu_zhaocai.dict")

import jieba
# 加载主词典和自定义词典
jieba.set_dictionary('/mnt/lustre/wangweifei/utils/jieba_dict/jieba.count')
jieba.load_userdict("/mnt/lustre/wangweifei/utils/jieba_dict/xiaochu_zhaocai.dict")

text = "五G紫东太初大模型武汉人工智能研究院武智院  I'M GOOD       我是中国人  ok"
text = "i am a chinese teacher唯物论合适的恭喜ok 噢OK只有这样子you're ppt qq"
line_cut = jieba.cut(text, HMM=False)
line_ = ' '.join(line_cut)

# 去除多余的空格 用单个空格替换所有连续的空白字符（包括空格、换行符 \n、制表符 \t 等）
result = re.sub(r'\s+', ' ', line_).strip().replace(" ' ","'")

print(line_cut)
print(line_)
print(result)

'''
import jieba
import re
import os
import argparse
import multiprocessing
from functools import partial
from tqdm import tqdm

# 默认词典路径
DEFAULT_JIEBA_DICT = '/mnt/lustre/wangweifei/utils/jieba_dict/jieba.count'
DEFAULT_USER_DICT = '/mnt/lustre/wangweifei/utils/jieba_dict/xiaochu_zhaocai.dict'

def process_chunk(chunk, hmm=False):
    """处理文本块"""
    results = []
    for line in chunk:
        if not line.strip():
            results.append('')
            continue
        
        line_cut = jieba.cut(line.strip(), HMM=hmm)
        line_segmented = ' '.join(line_cut)
        result = re.sub(r'\s+', ' ', line_segmented).strip().replace(" ' ", "'")
        results.append(result)
    
    return results

def process_file_parallel(input_file, output_file, jieba_dict=DEFAULT_JIEBA_DICT, user_dict=DEFAULT_USER_DICT, hmm=False, num_processes=None):
    """
    使用多进程并行处理文件
    
    Args:
        input_file (str): 输入文件路径
        output_file (str): 输出文件路径
        jieba_dict (str): jieba词典路径
        user_dict (str): 用户词典路径
        hmm (bool): 是否使用HMM模型
        num_processes (int): 进程数，默认为CPU核心数
    """
    if num_processes is None:
        num_processes = multiprocessing.cpu_count()
    
    print("正在初始化 jieba...")
    # 初始化jieba
    if jieba_dict and os.path.exists(jieba_dict):
        jieba.set_dictionary(jieba_dict)
        print(f"使用jieba词典: {jieba_dict}")
    else:
        print(f"警告: jieba词典路径 {jieba_dict} 不存在，使用默认词典")
    
    if user_dict and os.path.exists(user_dict):
        jieba.load_userdict(user_dict)
        print(f"使用用户词典: {user_dict}")
    else:
        print(f"警告: 用户词典路径 {user_dict} 不存在，跳过加载用户词典")
    
    # # 预加载词典，加快初始化
    # jieba.dt.initialize()
    
    # # 启用并行模式
    # jieba.enable_parallel(num_processes)
    
    print("正在读取输入文件...")
    # 读取整个文件
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    total_lines = len(lines)
    print(f"总计需要处理 {total_lines} 行文本")
    
    # 计算每个进程处理的行数
    chunk_size = max(1, len(lines) // num_processes)
    chunks = [lines[i:i + chunk_size] for i in range(0, len(lines), chunk_size)]
    
    print(f"开始使用 {num_processes} 个进程并行处理...")
    # 创建处理函数
    process_func = partial(process_chunk, hmm=hmm)
    
    # 使用进程池并行处理，并显示进度
    with multiprocessing.Pool(processes=num_processes) as pool:
        results = list(tqdm(
            pool.imap(process_func, chunks),
            total=len(chunks),
            desc="处理进度",
            unit="块"
        ))
    
    print("正在写入输出文件...")
    # 合并结果并写入文件
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for chunk_result in results:
            for line in chunk_result:
                f_out.write(line + '\n')
    
    print(f"处理完成。输出保存到: {output_file}")
    print(f"使用的进程数: {num_processes}")

def process_file_batch(input_file, output_file, jieba_dict=DEFAULT_JIEBA_DICT, user_dict=DEFAULT_USER_DICT, hmm=False, batch_size=10000):
    """
    批量处理文件以提高I/O效率
    
    Args:
        input_file (str): 输入文件路径
        output_file (str): 输出文件路径
        jieba_dict (str): jieba词典路径
        user_dict (str): 用户词典路径
        hmm (bool): 是否使用HMM模型
        batch_size (int): 每批处理的行数
    """
    print("正在初始化 jieba...")
    # 初始化jieba
    if jieba_dict and os.path.exists(jieba_dict):
        jieba.set_dictionary(jieba_dict)
        print(f"使用jieba词典: {jieba_dict}")
    else:
        print(f"警告: jieba词典路径 {jieba_dict} 不存在，使用默认词典")
    
    if user_dict and os.path.exists(user_dict):
        jieba.load_userdict(user_dict)
        print(f"使用用户词典: {user_dict}")
    else:
        print(f"警告: 用户词典路径 {user_dict} 不存在，跳过加载用户词典")
    
    # 预加载词典，加快初始化
    jieba.dt.initialize()
    
    # 创建自定义分词器以避免全局锁
    tokenizer = jieba.Tokenizer()
    if jieba_dict and os.path.exists(jieba_dict):
        tokenizer.set_dictionary(jieba_dict)
    if user_dict and os.path.exists(user_dict):
        tokenizer.load_userdict(user_dict)
    
    # 计算总行数以显示进度
    total_lines = sum(1 for _ in open(input_file, 'r', encoding='utf-8'))
    print(f"总计需要处理 {total_lines} 行文本")
    
    print("开始处理文件...")
    with open(input_file, 'r', encoding='utf-8') as f_in, open(output_file, 'w', encoding='utf-8') as f_out:
        lines = []
        pbar = tqdm(total=total_lines, desc="处理进度", unit="行")
        
        for line in f_in:
            lines.append(line.strip())
            
            # 当累积了足够多的行时处理
            if len(lines) >= batch_size:
                for text in lines:
                    if not text:
                        f_out.write('\n')
                    else:
                        line_cut = tokenizer.cut(text, HMM=hmm)
                        line_segmented = ' '.join(line_cut)
                        result = re.sub(r'\s+', ' ', line_segmented).strip().replace(" ' ", "'")
                        f_out.write(result + '\n')
                pbar.update(len(lines))
                lines = []
        
        # 处理剩余的行
        for text in lines:
            if not text:
                f_out.write('\n')
            else:
                line_cut = tokenizer.cut(text, HMM=hmm)
                line_segmented = ' '.join(line_cut)
                result = re.sub(r'\s+', ' ', line_segmented).strip().replace(" ' ", "'")
                f_out.write(result + '\n')
        
        pbar.update(len(lines))
        pbar.close()
    
    print(f"处理完成。输出保存到: {output_file}")

def count_lines(file_path):
    """计算文件行数"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return sum(1 for _ in f)

def main():
    parser = argparse.ArgumentParser(description='使用jieba进行文本分词处理')
    parser.add_argument('input_file', help='输入文本文件路径')
    parser.add_argument('output_file', help='输出文本文件路径')
    parser.add_argument('--jieba_dict', default=DEFAULT_JIEBA_DICT, help='jieba词典文件路径')
    parser.add_argument('--user_dict', default=DEFAULT_USER_DICT, help='用户词典文件路径')
    parser.add_argument('--hmm', action='store_true', help='使用HMM模型进行分词')
    parser.add_argument('--parallel', action='store_true', help='使用并行处理')
    parser.add_argument('--processes', type=int,default=4, help='并行处理的进程数')
    parser.add_argument('--batch_size', type=int, default=10000, help='批处理的行数')
    
    args = parser.parse_args()
    
    # 检查输入文件是否存在
    if not os.path.isfile(args.input_file):
        print(f"错误: 输入文件 '{args.input_file}' 不存在")
        return
    
    start_time = time.time()
    
    if args.parallel:
        process_file_parallel(
            args.input_file, 
            args.output_file, 
            args.jieba_dict, 
            args.user_dict, 
            args.hmm, 
            args.processes
        )
    # else:
    #     process_file_batch(
    #         args.input_file, 
    #         args.output_file, 
    #         args.jieba_dict, 
    #         args.user_dict, 
    #         args.hmm, 
    #         args.batch_size
    #     )
    
    end_time = time.time()
    print(f"处理用时: {end_time - start_time:.2f} 秒")

if __name__ == "__main__":
    import time
    main()
    #python script.py input output  --parallel