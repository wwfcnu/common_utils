import sys
# input_file = "/mnt/data1/AudioDataset/wair/data/bilibili/game/langrensha/segments"
# output_file = "output.txt"
input_file = sys.argv[1]
output_file = sys.argv[2]

##最大持续时间和最大静音时间
# max_time_diff = 30
# max_silence = 2
max_time_diff = 10
max_silence = 2

start_times = []
end_times = []
speakers = []


# 读取文件
with open(input_file, 'r', encoding='utf-8') as f:
    lines = f.readlines()
    for line in lines:

        parts = line.strip().split(' ')
        #print(parts)
        start_time = parts[2]
        end_time = parts[3]
        start_times.append(float(start_time))
        end_times.append(float(end_time))
        speakers.append(parts[1])
     

new_start_time = start_times[0]
new_end_time = end_times[0]
new_speaker = speakers[0]




with open(output_file, 'w', encoding='utf-8') as f:
    for i in range(1, len(start_times)):
        if speakers[i] == new_speaker and start_times[i] - new_end_time <= max_silence:
            # 合并相同说话人的说话内容
            if end_times[i] - new_start_time <= max_time_diff:
                # 合并后时间差不超过 max_time_diff
                new_end_time = end_times[i]
                
                
            else:
                # 合并后时间差超过 max_time_diff，输出之前的说话内容
                f.write("%s-%s-%s %s %s %s\n" % (new_speaker,str(new_start_time), str(new_end_time),new_speaker,str(new_start_time), str(new_end_time)))
                #f.write("%s_%s %s %s %s\n" % (new_speaker,sentence_count,new_speaker,str(new_start_time), str(new_end_time)))
                
                
                # 更新起始时间和说话内容
                new_start_time = start_times[i]
                new_end_time = end_times[i]
                new_speaker = speakers[i]
                
            

               
        else:
            # 输出之前的说话内容
            f.write("%s-%s-%s %s %s %s\n" % (new_speaker,str(new_start_time), str(new_end_time),new_speaker,str(new_start_time), str(new_end_time)))
            #f.write("%s_%s %s %s %s\n" % (new_speaker,sentence_count,new_speaker,str(new_start_time), str(new_end_time)))
            
            # 更新起始时间和说话内容
            new_start_time = start_times[i]
            new_end_time = end_times[i]
            new_speaker = speakers[i]
            

          
         


    # 输出最后一个说话人的内容

    f.write("%s-%s-%s %s %s %s\n" % (new_speaker,str(new_start_time), str(new_end_time),new_speaker,str(new_start_time), str(new_end_time)))
    #f.write("%s_%s %s %s %s\n" % (new_speaker,sentence_count,new_speaker,str(new_start_time), str(new_end_time)))