import argparse
from pydub import AudioSegment
import os
from tqdm import tqdm

def calculate_duration_with_pydub(wav_scp_path, output_path):
    total_duration = 0.0
    durations = []

    with open(wav_scp_path, "r", encoding="utf-8") as wav_scp:
        for line in tqdm(wav_scp):
            parts = line.strip().split(maxsplit=1)
            if len(parts) != 2:
                print(f"Skipping invalid line: {line.strip()}")
                continue
            
            wav_id, wav_path = parts
            try:
                # 使用 pydub 读取音频文件
                audio = AudioSegment.from_file(wav_path)
                duration = len(audio) / 1000.0  # pydub 的长度以毫秒为单位，转换为秒
                total_duration += duration
                durations.append((wav_id, duration))
            except Exception as e:
                print(f"Error processing {wav_path}: {e}")

    # 打印总时长
    total_duration = total_duration / 3600
    print(f"总时长: {total_duration:.2f} h")
    
    # 输出时长文件
    with open(output_path, "w", encoding="utf-8") as output_file:
        for wav_id, duration in durations:
            output_file.write(f"{wav_id}\t{duration:.2f}\n")

        output_file.write(f"总时长：{total_duration}\n")



def main():
    # 设置参数解析
    parser = argparse.ArgumentParser(description="Calculate durations of audio files from wav.scp.")
    parser.add_argument("--input",'-i', required=True, help="Path to the wav.scp file (input).")
    parser.add_argument("--output",'-o', required=True, help="Path to the output duration file.")
    args = parser.parse_args()

    # 调用计算函数
    calculate_duration_with_pydub(args.input, args.output)

if __name__ == "__main__":
    main()
