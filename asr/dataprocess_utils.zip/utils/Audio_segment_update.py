import os
import sys
from pydub import AudioSegment
from tqdm import tqdm
from multiprocessing import cpu_count
from concurrent.futures import ProcessPoolExecutor
import argparse

def process_segment_data(input_file):
    """
    Process the input segments file and return a dictionary of segments based on wav_id.

    Args:
        input_file (str): Path to the input segments file.
    
    Returns:
        dict: Dictionary containing segments information indexed by wav_id.
    """
    data = {}
    try:
        with open(input_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split()
                    wav_id = parts[1]
                    segment_info = (parts[0], parts[2], parts[3])
                    data.setdefault(wav_id, []).append(segment_info)
    except FileNotFoundError:
        print(f"Error: The input file '{input_file}' was not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: An error occurred while reading the input file: {e}")
        sys.exit(1)
    return data

def process_segment_file(wav_id, segments, output_folder, wav_scp_path):
    """
    Process a single segment file and export the audio segments.

    Args:
        wav_id (str): The wav_id for the audio file.
        segments (list): List of segment information.
        output_folder (str): Output directory to save the processed audio segments.
        wav_scp_path (dict): Dictionary mapping wav_id to audio file path.
    """
    try:
        output_dir = os.path.join(output_folder, wav_id)
        os.makedirs(output_dir, exist_ok=True)

        # Load the entire audio file
        wav_path = wav_scp_path.get(wav_id)
        audio = AudioSegment.from_file(wav_path)

        for segment in segments:
            filename, start_time, end_time = segment
            start_time = float(start_time)
            end_time = float(end_time)
            
            if end_time > start_time:
                output_file = os.path.join(output_dir, f'{filename}.wav')
                if os.path.exists(output_file):
                    print(f"{output_file} already exists, skipping")
                    continue

                segment_audio = audio[start_time * 1000:end_time * 1000]
                if segment_audio:
                    segment_audio = segment_audio.set_frame_rate(16000).set_channels(1)
                    segment_audio.export(output_file, format='wav')
    except Exception as e:
        print(f"Failed to process segments for wav_id {wav_id}: {e}")

def load_wav_scp(wav_scp_file):
    """
    Load the wav.scp file and return a dictionary mapping wav_id to audio file path.

    Args:
        wav_scp_file (str): Path to the wav.scp file.
    
    Returns:
        dict: Dictionary mapping wav_id to audio file path.
    """
    wav_scp_path = {}
    try:
        with open(wav_scp_file, 'r') as f:
            for line in f:
                wav_id, wav_path = line.strip().split()
                wav_scp_path[wav_id] = wav_path
    except FileNotFoundError:
        print(f"Error: The wav.scp file '{wav_scp_file}' was not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: An error occurred while reading the wav.scp file: {e}")
        sys.exit(1)
    return wav_scp_path

def divide_segments_into_batches(segments_dict, num_parts):
    """
    Divide the segments dictionary into batches for parallel processing.

    Args:
        segments_dict (dict): Dictionary containing segments information indexed by wav_id.
        num_parts (int): Number of parts to divide the segments into.
    
    Returns:
        list: List of dictionaries, each containing a subset of the segments.
    """
    items = list(segments_dict.items())
    segments_per_batch = len(items) // num_parts
    return [dict(items[i:i+segments_per_batch]) for i in range(0, len(items), segments_per_batch)]

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Process audio segments from video files.")
    
    parser.add_argument("--wav-scp-file", type=str, required=True, help="Path to wav.scp file")
    parser.add_argument("--input-segments-file", type=str, required=True, help="Path to the input segments file.")
    parser.add_argument("--num-parts", type=int, required=True, help="Number of parts to divide the segments into")
    parser.add_argument("--output-part-dir", type=str, required=True, help="Output directory for the processed audio segments")

    args = parser.parse_args()

    # Step 1: Process the input segments file into a dictionary
    segments_dict = process_segment_data(args.input_segments_file)

    # Load the wav.scp file
    wav_scp_path = load_wav_scp(args.wav_scp_file)

    # Divide segments into parts
    segment_batches = divide_segments_into_batches(segments_dict, args.num_parts)

    # Define output folders
    output_folders = [os.path.join(args.output_part_dir, str(i)) for i in range(args.num_parts +1)]

    # Process segments using multiprocessing
    executor = ProcessPoolExecutor(max_workers=cpu_count())
    for i, batch in enumerate(segment_batches):
        output_folder = output_folders[i]
        futures = [executor.submit(process_segment_file, wav_id, segments, output_folder, wav_scp_path) for wav_id, segments in tqdm(batch.items(), desc=f"Batch {i+1}/{args.num_parts +1}")]
        for future in tqdm(futures, desc="Waiting for batch to complete"):
            future.result()

if __name__ == "__main__":
    main()

# eg：python audio_segments_update.py --wav-scp-file --input-segments-file --num-parts --output-part-dir