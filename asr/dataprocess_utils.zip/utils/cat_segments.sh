#!/bin/bash

# 读取segments_path.txt中每个segments的文件路径，然后合并这些文件到一个segments中


# 读取文件路径
segments_path_file=$1

# 检查文件是否存在
if [ ! -f "$segments_path_file" ]; then
    echo "Error: $segments_path_file not found."
    exit 1
fi

# 合并文件路径中的内容到一个segments文件
output_file=$2
> "$output_file"  # 清空或创建一个新文件

while IFS= read -r filepath; do
    # 检查文件是否存在
    if [ ! -f "$filepath" ]; then
        echo "Warning: $filepath not found, skipping."
        continue
    fi
    
    # 将文件内容追加到输出文件中
    cat "$filepath" >> "$output_file"
done < "$segments_path_file"

echo "Segments merged into $output_file successfully."
