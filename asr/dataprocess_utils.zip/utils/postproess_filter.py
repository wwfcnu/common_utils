"""
音频数据筛选脚本
根据filter_id筛选wav.scp和text文件
"""

import argparse
import os

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='根据filter_id筛选wav.scp和text文件',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
使用示例:
  python filter_audio.py -w wav.scp -t text -f filter_id
  python filter_audio.py --wav-scp data/wav.scp --text data/text --filter-id data/filter_id \\
                         --output-wav filtered/wav.scp --output-text filtered/text
        '''
    )
    
    # 输入文件参数
    parser.add_argument('-w', '--wav-scp', 
                        required=True,
                        help='原始wav.scp文件路径')
    
    parser.add_argument('-t', '--text',
                        required=True, 
                        help='原始text文件路径')
    
    parser.add_argument('-f', '--filter-id',
                        required=True,
                        help='筛选ID文件路径')
    
    # 输出文件参数
    parser.add_argument('-ow', '--output-wav',
                        default='filtered_wav.scp',
                        help='输出wav.scp文件路径 (默认: filtered_wav.scp)')
    
    parser.add_argument('-ot', '--output-text',
                        default='filtered_text',
                        help='输出text文件路径 (默认: filtered_text)')
    
    # 其他选项
    parser.add_argument('-v', '--verbose',
                        action='store_true',
                        help='显示详细信息')
    
    parser.add_argument('--check-files',
                        action='store_true',
                        help='检查输入文件是否存在')
    
    return parser.parse_args()


def check_input_files(args):
    """检查输入文件是否存在"""
    files_to_check = [
        (args.wav_scp, 'wav.scp'),
        (args.text, 'text'),
        (args.filter_id, 'filter_id')
    ]
    
    missing_files = []
    for file_path, file_type in files_to_check:
        if not os.path.exists(file_path):
            missing_files.append(f"{file_type}: {file_path}")
    
    if missing_files:
        print("错误: 以下输入文件不存在:")
        for missing in missing_files:
            print(f"  - {missing}")
        return False
    
    return True


def filter_audio_data(wav_scp_path, text_path, filter_id_path, 
                     output_wav_scp_path, output_text_path, verbose=False):
    """
    根据filter_id筛选音频数据
    
    Args:
        wav_scp_path: 原始wav.scp文件路径
        text_path: 原始text文件路径  
        filter_id_path: 筛选ID文件路径
        output_wav_scp_path: 输出wav.scp文件路径
        output_text_path: 输出text文件路径
        verbose: 是否显示详细信息
    """
    
    # 读取筛选ID列表
    filter_ids = set()
    try:
        with open(filter_id_path, 'r', encoding='utf-8') as f:
            for line in f:
                wav_id = line.strip()
                if wav_id:  # 忽略空行
                    filter_ids.add(wav_id)
        print(f"读取到 {len(filter_ids)} 个筛选ID")
    except FileNotFoundError:
        print(f"错误: 找不到文件 {filter_id_path}")
        return
    except Exception as e:
        print(f"读取filter_id文件时出错: {e}")
        return
    
    # 筛选wav.scp文件
    filtered_wav_count = 0
    try:
        with open(wav_scp_path, 'r', encoding='utf-8') as input_f, \
             open(output_wav_scp_path, 'w', encoding='utf-8') as output_f:
            
            for line in input_f:
                line = line.strip()
                if not line:
                    continue
                    
                parts = line.split('\t')
                if len(parts) >= 2:
                    wav_id = parts[0]
                    if wav_id in filter_ids:
                        output_f.write(line + '\n')
                        filtered_wav_count += 1
                        if verbose:
                            print(f"  筛选wav记录: {wav_id}")
                else:
                    if verbose:
                        print(f"警告: wav.scp中格式不正确的行: {line}")
        
        print(f"筛选后的wav.scp包含 {filtered_wav_count} 条记录")
    except FileNotFoundError:
        print(f"错误: 找不到文件 {wav_scp_path}")
        return
    except Exception as e:
        print(f"处理wav.scp文件时出错: {e}")
        return
    
    # 筛选text文件
    filtered_text_count = 0
    try:
        with open(text_path, 'r', encoding='utf-8') as input_f, \
             open(output_text_path, 'w', encoding='utf-8') as output_f:
            
            for line in input_f:
                line = line.strip()
                if not line:
                    continue
                    
                parts = line.split('\t')
                if len(parts) >= 2:
                    wav_id = parts[0]
                    if wav_id in filter_ids:
                        output_f.write(line + '\n')
                        filtered_text_count += 1
                        if verbose:
                            print(f"  筛选text记录: {wav_id}")
                else:
                    if verbose:
                        print(f"警告: text中格式不正确的行: {line}")
        
        print(f"筛选后的text包含 {filtered_text_count} 条记录")
    except FileNotFoundError:
        print(f"错误: 找不到文件 {text_path}")
        return
    except Exception as e:
        print(f"处理text文件时出错: {e}")
        return
    
    # 检查数据一致性
    if filtered_wav_count != filtered_text_count:
        print(f"警告: wav.scp和text的记录数量不一致! wav:{filtered_wav_count}, text:{filtered_text_count}")
    
    print("筛选完成!")


def main():
    """主函数"""
    args = parse_arguments()
    
    if args.check_files:
        if not check_input_files(args):
            return 1
    
    print("开始筛选音频数据...")
    print(f"输入文件:")
    print(f"  wav.scp: {args.wav_scp}")
    print(f"  text: {args.text}")
    print(f"  filter_id: {args.filter_id}")
    print(f"输出文件:")
    print(f"  filtered_wav.scp: {args.output_wav}")
    print(f"  filtered_text: {args.output_text}")
    print("-" * 50)
    
    filter_audio_data(
        wav_scp_path=args.wav_scp,
        text_path=args.text,
        filter_id_path=args.filter_id,
        output_wav_scp_path=args.output_wav,
        output_text_path=args.output_text,
        verbose=args.verbose
    )
    



if __name__ == "__main__":
    main()