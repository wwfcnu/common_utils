import argparse
import os
import shutil
import subprocess
from concurrent.futures import ProcessPoolExecutor
from functools import partial

from tqdm import tqdm


def ffmpeg_convert(file_from, file_to):
    try:
        subprocess.call(
            [
                "ffmpeg",
                "-loglevel",
                "warning",
                "-y",
                "-i",
                file_from,
                "-ac",
                "1",
                "-ar",
                "16000",
                "-acodec",
                "pcm_s16le",
                file_to,
            ]
        )
    except Exception as e:
        print(file_to, e)
    return



def video2wav(args):
    video_format = {".mov", ".avi", ".flv", ".ogg", ".mp4", ".mkv", ".webm"}
    if not os.path.exists(args.wav_dir):
        os.makedirs(args.wav_dir, exist_ok=True)

    # Start multiprocess
    executor = ProcessPoolExecutor(max_workers=args.workers)
    print(f"> Using {args.workers} workers!")
    futures = []
    files = os.listdir(args.root_dir)
    #files = set([x for x in files if x[-4:] in video_format])
    files = set([x for x in files if os.path.splitext(x)[1].lower() in video_format])

    print("Total videos to convert: ", len(files))

    for file_name in files:
        file_raw = os.path.join(args.root_dir, file_name)
        # file_to = os.path.join(
        #     args.wav_dir, file_name.split(".")[-2][-11:] + args.format
        # )
        file_to = os.path.join(args.wav_dir, os.path.splitext(file_name)[0] + args.format)

        if os.path.exists(file_to):
            continue
        futures.append(executor.submit(partial(ffmpeg_convert, file_raw, file_to)))

    result_list = [future.result() for future in tqdm(futures)]
    print(len(result_list), "wavs resampled.")


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--format",
        type=str,
        default=".m4a",
        help="Set audio format, find other options in ffmpeg documentation.",
    )

    parser.add_argument(
        "--root_dir",
        type=str,
        default="./download",
        help="Dictionary path of downloaded videos.",
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default="./data",
        help="Dictionary path to save audio files.",
    )

    parser.add_argument("--workers", type=int, default=16, help="Multiprocess workers.")
    args = parser.parse_args()

    if not os.path.exists(args.save_dir):
        os.makedirs(args.save_dir, exist_ok=True)

    args.wav_dir = os.path.join(args.save_dir, "audios")

    os.makedirs(args.wav_dir, exist_ok=True)


    # convert video to wav
    video2wav(args)


if __name__ == "__main__":
    main()