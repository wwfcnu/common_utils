import argparse
import sys

def read_wav_scp(wav_scp_path):
    """Read wav.scp file and return a dictionary of uttid to wav_path"""
    wav_dict = {}
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            uttid, wav_path = line.strip().split(maxsplit=1)
            wav_dict[uttid] = wav_path
    return wav_dict

def write_results(results, output_path):
    """Write results to output file in format: uttid\ttext"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for uttid, text in results:
            f.write(f"{uttid}\t{text}\n")

def paraformer_offline(wav_scp_path, output_path):
    from funasr import AutoModel
    
    # Initialize model
    model = AutoModel(model="paraformer-zh")
    
    # Read wav.scp
    wav_dict = read_wav_scp(wav_scp_path)
    
    # Process each utterance
    results = []
    for uttid, wav_path in wav_dict.items():
        try:
            res = model.generate(input=wav_path, batch_size_s=300, batch_size_threshold_s=60, hotword='魔搭')
            text = res[0]['text']
        except Exception as e:
            print(e)
            text = ""
        results.append((uttid, text))
    
    # Write results
    write_results(results, output_path)
    return results

def paraformer_online(wav_scp_path, output_path):
    from funasr import AutoModel
    import soundfile
    
    # Initialize model
    chunk_size = [0, 10, 5]  # [0, 10, 5] 600ms, [0, 8, 4] 480ms
    encoder_chunk_look_back = 4
    decoder_chunk_look_back = 1
    model = AutoModel(model="paraformer-zh-streaming")
    
    # Read wav.scp
    wav_dict = read_wav_scp(wav_scp_path)
    
    # Process each utterance
    results = []
    for uttid, wav_path in wav_dict.items():
        speech, sample_rate = soundfile.read(wav_path)
        chunk_stride = chunk_size[1] * 960  # 600ms
        
        cache = {}
        total_chunk_num = int(len(speech - 1) / chunk_stride + 1)
        final_text = []
        
        for i in range(total_chunk_num):
            speech_chunk = speech[i * chunk_stride:(i + 1) * chunk_stride]
            is_final = i == total_chunk_num - 1
            try:
                response = model.generate(
                    input=speech_chunk,
                    cache=cache,
                    is_final=is_final,
                    chunk_size=chunk_size,
                    encoder_chunk_look_back=encoder_chunk_look_back,
                    decoder_chunk_look_back=decoder_chunk_look_back
                )
                res = response[0]['text']
            except Exception as e:
                print(e)
                res = ""

            final_text.append(res)
        final_result = " ".join(final_text)

        results.append((uttid, final_result))
    
    # Write results
    write_results(results, output_path)
    return results

def parse_args():
    parser = argparse.ArgumentParser(description='Run Paraformer ASR with wav.scp input')
    parser.add_argument('--asr_type', choices=['offline', 'online'], required=True,
                      help='ASR type: offline or online')
    parser.add_argument('--wav_scp', required=True,
                      help='Path to wav.scp file')
    parser.add_argument('--output', required=True,
                      help='Path to output result file')
    return parser.parse_args()

def main():
    args = parse_args()
    
    print(f"Running {args.asr_type} ASR...")
    print(f"Input wav.scp: {args.wav_scp}")
    print(f"Output file: {args.output}")
    
    try:
        if args.asr_type == 'offline':
            results = paraformer_offline(args.wav_scp, args.output)
        else:  # online
            results = paraformer_online(args.wav_scp, args.output)
        print("Processing completed successfully!")
        
    except Exception as e:
        print(f"Error occurred: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()