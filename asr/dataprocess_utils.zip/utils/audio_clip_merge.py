import os
import glob
import re

# 合并
def process_concat(input_dir,output_dir):
    # Set the maximum time difference between speaker turns
    max_time_diff = 10
    max_silence = 2
    # Loop through all files in the input directory
    for filename in os.listdir(input_dir):
        if filename.endswith(".txt"):
            # Set the input and output file paths
            input_file = os.path.join(input_dir, filename)
            output_file = os.path.join(output_dir, filename)
            
            # Apply the same code to each file
            start_times = []
            end_times = []
            speakers = []
            texts = []

            with open(input_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines:
                    parts = line.strip().split('\t')
                    start_time, end_time = parts[0].strip()[1:-1].split(',')
                    start_times.append(float(start_time))
                    end_times.append(float(end_time))
                    speakers.append(parts[1])
                    texts.append(parts[3])


            new_start_time = start_times[0]
            new_end_time = end_times[0]
            new_text = texts[0]
            new_speaker = speakers[0]
            
            id = filename.split('.')[0]

            with open(output_file, 'w', encoding='utf-8') as f:
                for i in range(1, len(start_times)):
                    if speakers[i] == new_speaker and start_times[i] - new_end_time <= max_silence:
                        # 合并相同说话人的说话内容
                        if end_times[i] - new_start_time <= max_time_diff:
                            # 合并后时间差不超过 max_time_diff
                            new_end_time = end_times[i]
                            new_text += texts[i]
                        else:
                            # 合并后时间差超过 max_time_diff，输出之前的说话内容
                            f.write("%s-%s-%s\t%s\n" % (id,str(new_start_time), str(new_end_time), new_text))
                            # 更新起始时间和说话内容
                            new_start_time = start_times[i]
                            new_end_time = end_times[i]
                            new_speaker = speakers[i]
                            new_text = texts[i]
                    else:
                        # 输出之前的说话内容
                    
                        f.write("%s-%s-%s\t%s\n" % (id,str(new_start_time), str(new_end_time), new_text))
                        
                        # 更新起始时间和说话内容
                        new_start_time = start_times[i]
                        new_end_time = end_times[i]
                        new_speaker = speakers[i]
                        new_text = texts[i]


                # 输出最后一个说话人的内容

                f.write("%s-%s-%s\t%s\n" % (id,str(new_start_time), str(new_end_time), new_text))


# 去除text没有中文的行
def remove_line(text_temp_dir,output_text_dir):
    special_symbols = ["[*]", "[+]", "[LAUGHTER]", "[SONANT]", "[MUSIC]", "[SYSTEM]", "[ENS]"]

    text_list = glob.glob(f"{text_temp_dir}/*.txt")

    for text_file in text_list:

        filename = text_file.split("/")[-1]
        output_file = os.path.join(output_text_dir,filename)
        with open(text_file, 'r') as f, open(output_file, 'w') as w:
            for line in f:
                wav_id, text = line.strip().split("\t")

                found_special_symbol = False  # 初始化一个变量来记录是否找到特殊符号
                for symbol in special_symbols:
                    if re.search(re.escape(symbol), text):
                        print(f"{text}中包含特殊符号: {symbol}")
                        found_special_symbol = True  # 找到了特殊符号，设置为True
                        break
                if not found_special_symbol:  # 如果未找到特殊符号
                    #print(text)
                    w.write(line)



if __name__== "__main__":


    #datasets = ["changsha","nanchang","shanghai","sichuan","tianjin","zhengzhou"]
    input_dir = "/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/TXT"
    text_temp_dir = "/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/wav_seg/text_tmp"
   
    text_output_dir = "/home/tangshuai/asr_datasets/asr_datasets/baseline_test_datasets/magicdata_dialect/changsha/wav_seg/text"

    # os.makedirs(text_temp_dir, exist_ok=True) 
    # os.makedirs(text_output_dir, exist_ok=True) 
    process_concat(input_dir,text_temp_dir)

    remove_line(text_temp_dir,text_output_dir)