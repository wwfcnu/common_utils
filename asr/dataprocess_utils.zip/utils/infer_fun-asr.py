

import time
import argparse
import re
from funasr import AutoModel

# Main function to handle transcription and post-processing
def main():
    # Define the arguments
    parser = argparse.ArgumentParser(description="ASR transcription and result parsing using Fun-ASR-Nano-2512 model.")
    parser.add_argument('--model', type=str, default="FunAudioLLM/Fun-ASR-Nano-2512", help='Path to the model directory')
    parser.add_argument('--gpuid', type=str, default="0", help='GPU device to use, e.g., "cuda:0" or "cpu"')
    parser.add_argument('--input', type=str, help='Path to the input file (wav.scp)')
    parser.add_argument('--language', type=str, default="auto", help='Language for transcription (e.g., "zh", "en", "yue", "ja", "ko", "nospeech")')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size for processing')
    parser.add_argument('--output_dir', type=str, help='Directory to save the transcription output')
    parser.add_argument('--itn', action='store_true', default=True, help='Whether to use inverse text normalization')
    parser.add_argument('--hotwords', nargs='+', default=['开放时间'], help='热词列表（用空格分隔，例如: --hotwords 热词1 热词2）'
    )


    # Parse the arguments
    args = parser.parse_args()

    # Load the model
    model = AutoModel(model=args.model, trust_remote_code=True, remote_code="./model.py",device=f"cuda:{args.gpuid}")

    start_time = time.time()

    # Perform transcription
    res = model.generate(
        input=args.input,
        cache={},
        language=args.language,
        itn=args.itn,
        batch_size=args.batch_size,
        output_dir=args.output_dir,
        hotwords=args.hotwords
    )

    # Log the total time taken
    print(f"Total time cost for transcription: {time.time() - start_time:.2f}s")

    # Post-process the output file


if __name__ == "__main__":
    main()
