from faster_whisper import WhisperModel
import codecs
import sys
import os
from tqdm import tqdm
import concurrent.futures
import os
import shutil
import argparse


# 写一个whisper的pipeline类，batch_size在whisper里面就是线程数

class whisper_infer_pipeline:
    def __init__(self,whisper_model_path,gpuid) -> None:
        self.gpuid = gpuid
        self.model = WhisperModel(whisper_model_path, device="cuda", device_index=[int(gpuid)])
    
    def __call__(self, clip):

        wav_id = clip[0]
        wav_path = clip[1]
        segs, info = self.model.transcribe(wav_path)#,language="zh"
        segs = list(segs)
        hypothesis = "".join(seg.text for seg in segs)

        return '{0}'.format(wav_id + '\t' + hypothesis + '\n')

def whisper_infer(args):
    model_path = args.model
    gpuid = args.gpuid

    # 加载模型
    infer_pipeline = whisper_infer_pipeline(model_path,gpuid)

    wav_scp_file = args.input
    output_dir = args.output_dir
    max_workers = args.batch_size

    clips = []
    with open(wav_scp_file)as f:
        for line in f:
            audio_clip = line.strip().split()
            clips.append(audio_clip)

    os.makedirs(os.path.join(output_dir,"1best_recog"), exist_ok=True)
    result_file_path = codecs.open(f"{output_dir}/1best_recog/text", 'w+', 'utf8')
    #with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {executor.submit(infer_pipeline, clip): clip for clip in clips}
        for future in tqdm(concurrent.futures.as_completed(future_to_url),total=len(future_to_url),colour="blue"):
            clip = future_to_url[future]
            try:
                data = future.result()
            except Exception as exc:
                print('%r generated an exception: %s' % (clip, exc))
            else:
                result_file_path.write(data)
                result_file_path.flush()
    result_file_path.close()





if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default="/home/wangweifei/repository/wair/asr_project/models/faster-whisper-large-v3")
    parser.add_argument('--input', type=str, default="./data/test/wav.scp")
    parser.add_argument('--output_dir', type=str, default="./results/")
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--gpuid', type=str, default="0")
    args = parser.parse_args()
    whisper_infer(args)