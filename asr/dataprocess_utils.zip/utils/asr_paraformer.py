from modelscope.pipelines import pipeline
from modelscope.utils.constant import Tasks
import codecs
import sys
import os
from dnsmos_local import ComputeScore


inference_pipeline = pipeline(
    task=Tasks.auto_speech_recognition,
    model='iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-pytorch',
    #batch_size = 8,
    ngpu=0
    )
p808_model_path = os.path.join('/home/wangweifei/repository/DNS-Challenge/DNSMOS/DNSMOS', 'model_v8.onnx')


primary_model_path = os.path.join('/home/wangweifei/repository/DNS-Challenge/DNSMOS/DNSMOS', 'sig_bak_ovr.onnx')

compute_score = ComputeScore(primary_model_path, p808_model_path)


# wav_scp = sys.argv[1]
# output_dir = sys.argv[2]
# inference_pipeline(wav_scp, output_dir=output_dir)



def filter_and_process(file):
    res = ""
    try:
        mos_score = compute_score(file, 16000)
        if float(mos_score["P808_MOS"]) >= 3.4:
            try:
                rec_result = inference_pipeline(file)
                res = rec_result[0]['text']
            except Exception as e:
                print(f"识别文件{file}发生错误:{e}")
    
    except Exception as e:
        print(f"处理文件{file}报错：{e}")

    return res

def process(file):
    try:
        # rec_result = inference_pipeline('https://isv-data.oss-cn-hangzhou.aliyuncs.com/ics/MaaS/ASR/test_audio/asr_vad_punc_example.wav')

        rec_result = inference_pipeline(file)
        # print(rec_result[0]['text'])
        res = rec_result[0]['text']
    except Exception as e:
        print(e)
        res = ""
    return res


def tt(temp):
    temp = temp.strip()
    # print(temp)
    if len(temp.split()) == 2:  # source_info_list format: "key\taudio"
        key, audio = temp.split(maxsplit=1)
        sys.stderr.write('\tkey:' + key + '\taudio:' + audio + '\n')
        sys.stderr.flush()
        #text = process(audio)
        text = filter_and_process(audio)
        if text:       
            return '{0}'.format(key + '\t' + text + '\n')

    else:
        return '{0}'.format("Invalid line: " + temp + "\n")


from concurrent.futures import ThreadPoolExecutor, as_completed


def main():
    source_info_list = codecs.open(sys.argv[1], 'r', 'utf8')
    result_file_path = codecs.open(sys.argv[2], 'w+', 'utf8')
    # audio_num = len(source_info_list.readlines())
    
    # MAX_WORKER = int(sys.argv[3])
    # executor = ThreadPoolExecutor(max_workers=MAX_WORKER)
    # # Create a task and add it to the list
    # all_task = [executor.submit(tt,temp) for temp in source_info_list]
    # for future in as_completed(all_task):
    #     data = future.result()
    #     result_file_path.write(data)
    #     result_file_path.flush()
    for line in source_info_list:
        data = tt(line)
        result_file_path.write(data)
        result_file_path.flush()
    source_info_list.close()
    result_file_path.close()

if __name__ == '__main__':
    
    main()
 

