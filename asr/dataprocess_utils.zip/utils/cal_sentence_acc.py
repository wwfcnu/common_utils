import re
import argparse

def filter_wer(text_data):
    utt_parts = text_data.strip().split('\n\nutt: ')
    result = []
    for utt_part in utt_parts:
        lines = utt_part.splitlines()
        if not lines[0].strip():
            lines = lines[1:]  # Remove the empty line at the beginning if it exists
        wer_line = lines[1]
        wer_match = re.search(r'WER: (\d+\.\d+) %', wer_line)
        if wer_match:
            wer_value = float(wer_match.group(1)) / 100  # Convert WER percentage to a float
            # if wer_value <= 0.05:
            if wer_value == 0.00:
                utt = lines[0]
                #result.append(f"{utt}\t{wer_value:.2%}")
                result.append(f"{utt}")
    return '\n'.join(result).replace("utt: ","")


def main():
    parser = argparse.ArgumentParser(description="Filter non-zero wer data from a file and write it to another file")
    parser.add_argument("-i", "--input", help="Input file path", required=True) # /home/wangweifei/repository/wair/baseline_test_datasets/paraformer_9.6w/WER/aishell/wer
    parser.add_argument("-o", "--output", help="Output file path", required=True)
    args = parser.parse_args()

    file_path = args.input
    output_file_path = args.output

    with open(file_path, 'r', encoding='utf-8') as file:
        data = file.read()

    # Apply filtering function
    filtered_data = filter_wer(data)

    # Write filtered data to a new file
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(filtered_data + "\n")

if __name__ == "__main__":
    main()