# 检查emilia的pipeline处理结果
'''
输入wav.scp，检查json文件是否大于20，大于就跳过
检查一下看有多少是未处理的
bash A800_run.sh /mnt/lustre/wangweifei/repository/asr/data/qingting/pingshu/emilia_result/wav.scp.org 0  /mnt/lustre/wangweifei/asr_datasets/network_datasets/qingting/pingshu_processed
/mnt/lustre/wangweifei/asr_datasets/network_datasets/qingting/qtfm_pingshu/18387996.m4a: [Errno 13] Permission denied: '/mnt/lustre/wangweifei/asr_datasets/network_datasets/qingting/pingshu_processed/18387996/18387996.json'
找出目录下ls -ld 权限是root的目录
'''
import os
import argparse
import tqdm
import pwd

def get_audio_wav_scp(wav_scp_path):
    """Get all audio files from wav.scp."""
    audio_lines = []
    with open(wav_scp_path) as f:
        for line in f:
            line = line.strip()
            audio_lines.append(line)
    return audio_lines

def check_directory_owner(dir_path):
    """Check if the directory owner is root."""
    try:
        # 获取目录的所有者的uid
        dir_stat = os.stat(dir_path)
        owner_uid = dir_stat.st_uid
        # 使用 pwd 模块获取用户名
        owner_name = pwd.getpwuid(owner_uid).pw_name
        print(owner_name)
        return owner_name == "root"
    except FileNotFoundError:
        return False  # 如果目录不存在，返回False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-i",
        "--input_folder_path",
        type=str,
        default="",
        help="input folder path, this will override config if set",
    )
    parser.add_argument(
        "-o",
        "--output_dir",
        type=str,
        default="",
        help="output directory",
    )
    parser.add_argument(
        "-r",
        "--error_wav_scp",
        type=str,
        default="error_wav.scp",
        help="Output file to save unprocessed audio lines (default: remain_wav.scp)",
    )
    parser.add_argument(
        "-q",
        "--quxian_file",
        type=str,
        default="quxian.txt",
        help="Output file to save paths with root ownership (default: quxian.txt)",
    )

    args = parser.parse_args()

    input_folder_path = args.input_folder_path
    output_dir = args.output_dir
    remain_wav_scp = args.remain_wav_scp
    quxian_file = args.quxian_file

    # 获取所有音频文件
    audio_lines = get_audio_wav_scp(input_folder_path)  # 输入wav.scp

    # 打开remain_wav.scp和quxian.txt文件
    with open(remain_wav_scp, "w") as remain_file, open(quxian_file, "w") as quxian_output:

        for audio_line in tqdm.tqdm(audio_lines):
            # 注意这里应该用wav_id,而不是用路径的名称。遇到路径不一样但是名称一样的就容易问题
            audio_name = audio_line.split("\t")[0]
            path = audio_line.split("\t")[1]
            save_path = os.path.join(output_dir, audio_name)

            json_file = os.path.join(save_path, f"{audio_name}.json")

            # 检查是否存在大小大于20字节的json文件
            if os.path.exists(json_file) and os.path.getsize(json_file) > 20:
                print(f"{json_file} already exists, skipping")
            else:
                # 1.将不满足条件的写入新的文件remain_wav.scp
                remain_file.write(f"{audio_line}\n")

                # 2.判断一下这个save_path文件目录的权限，如果是root，记录一下写入一个新的文件quxian.txt
                if os.path.exists(save_path):
                    if check_directory_owner(save_path):
                        quxian_output.write(f"{save_path}\n")
def test():
    check_directory_owner("/mnt/lustre/wangweifei/asr_datasets/network_datasets/qingting/pingshu_processed/18387996")

if __name__ == "__main__":
    test()