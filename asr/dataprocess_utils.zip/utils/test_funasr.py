import os
import shutil
import argparse
# from modelscope.pipelines import pipeline
# from modelscope.utils.constant import Tasks

# def modelscope_infer(args):
#     os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpuid)
#     inference_pipeline = pipeline(
#         task=Tasks.auto_speech_recognition,
#         model=args.model,
#         output_dir=args.output_dir,
#         batch_size=args.batch_size,
#     )
#     inference_pipeline(input=args.input)

# if __name__ == "__main__":
#     parser = argparse.ArgumentParser()
#     parser.add_argument('--model', type=str, default="iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-pytorch")#iic

#     parser.add_argument('--input', type=str, default="./data/test/wav.scp")
#     parser.add_argument('--output_dir', type=str, default="./results/")
#     parser.add_argument('--batch_size', type=int, default=64)
#     parser.add_argument('--gpuid', type=str, default="0")
#     args = parser.parse_args()
#     modelscope_infer(args)
# from funasr import AutoModel
# # paraformer-zh is a multi-functional asr model
# # use vad, punc, spk or not as you need
# model = AutoModel(model="paraformer-zh",  vad_model="",  punc_model="", 
#                   # spk_model="cam++", 
#                   )
# res = model.generate(input=f"{model.model_path}/example/asr_example.wav", 
#                      batch_size_s=300, 
#                      hotword='魔搭')
# print(res)
# import torchaudio

# a = torchaudio.load("/mnt/lustre/wangweifei/asr_datasets/example_audio_1.mp3")
# print(a)

# paraformer离线和流式
def paraformer_offline():
    from funasr import AutoModel
    # paraformer-zh is a multi-functional asr model
    # use vad, punc, spk or not as you need
    model = AutoModel(model="paraformer-zh",  
                    #   vad_model="fsmn-vad", 
                    #   vad_kwargs={"max_single_segment_time": 60000},
                    #   punc_model="ct-punc", 
                    # spk_model="cam++"
                    )
    wav_file = f"{model.model_path}/example/asr_example.wav"
    res = model.generate(input=wav_file, batch_size_s=300, batch_size_threshold_s=60, hotword='魔搭')
    print(res)

# paraformer流式
def paraformer_online():
    from funasr import AutoModel

    chunk_size = [0, 10, 5] #[0, 10, 5] 600ms, [0, 8, 4] 480ms
    encoder_chunk_look_back = 4 #number of chunks to lookback for encoder self-attention
    decoder_chunk_look_back = 1 #number of encoder chunks to lookback for decoder cross-attention

    model = AutoModel(model="paraformer-zh-streaming")

    import soundfile
    import os

    wav_file = os.path.join(model.model_path, "example/asr_example.wav")
    speech, sample_rate = soundfile.read(wav_file)
    chunk_stride = chunk_size[1] * 960 # 600ms

    cache = {}
    final_result =  ""
    total_chunk_num = int(len((speech)-1)/chunk_stride+1)
    for i in range(total_chunk_num):
        speech_chunk = speech[i*chunk_stride:(i+1)*chunk_stride]
        is_final = i == total_chunk_num - 1
        res = model.generate(input=speech_chunk, cache=cache, is_final=is_final, chunk_size=chunk_size, encoder_chunk_look_back=encoder_chunk_look_back, decoder_chunk_look_back=decoder_chunk_look_back)
        print(res)
        final_result += res[0]['text']
    print(final_result)
if __name__ == "__main__":
    # paraformer_offline()
    paraformer_online()
