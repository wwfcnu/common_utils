#!/bin/bash
segment_merge_dir=$1
output_txt=$2
for merged_segment_file in "$segment_merge_dir"/*.segments; do
    if [ -s "$merged_segment_file" ]; then
        echo "$merged_segment_file" >> "$output_txt"
    fi
done