# import whisperx
# import gc 
# import os

# # # export TF_ENABLE_ONEDNN_OPTS=0

# device = "cuda" 
# audio_file = "/home/wangweifei/asr_datasets/public_class/bili_publiclecture2/192.wav"
# # audio_file = "/home/wangweifei/repository/wair/asr_project/transcribe/seg_test/55826500-6abe-4857-93c1-3802020e7bdf.mp3"
# batch_size = 1 # reduce if low on GPU mem
# compute_type = "float16" # change to "int8" if low on GPU mem (may reduce accuracy)

# # 1. Transcribe with original whisper (batched)
# # model = whisperx.load_model("large-v2", device, compute_type=compute_type)

# model = whisperx.load_model("large-v2", device, compute_type=compute_type,language="zh")# device_index="0"

# # save model to local path (optional)
# # model_dir = ""
# # model = whisperx.load_model("large-v2",device, compute_type=compute_type,download_root=model_dir)

# audio = whisperx.load_audio(audio_file)
# result = model.transcribe(audio, batch_size=batch_size)


# # 2. Align whisper output
# model_a, metadata = whisperx.load_align_model(language_code=result["language"], device=device)
# result = whisperx.align(result["segments"], model_a, metadata, audio, device, return_char_alignments=False)

# #print(result["segments"]) # after alignment
# # print(f"对齐后的result:{result}")
# # import json

# # 打开文件以写入模式
# # with open("result.json", "w") as f:
# #     # 将结果对象转换为JSON格式并写入文件
# #     json.dump(result, f, indent=4 ,ensure_ascii=False)
# # hypothesis = "".join(seg["text"] for seg in result["segments"])
# # print(hypothesis)


# # 3. Assign speaker labels

# model_dir = "/home/wangweifei/repository/"
# diarize_model = whisperx.DiarizationPipeline(model_name=f"{model_dir}/pyannote/speaker-diarization/config.yaml",device=device)

# # add min/max number of speakers if known
# # diarize_segments = diarize_model(audio)
# # diarize_model(audio, min_speakers=min_speakers, max_speakers=max_speakers)

# # result = whisperx.assign_word_speakers(diarize_segments, result)
# # print(diarize_segments)
# # print(result["segments"]) # segments are now assigned speaker IDs

# from pyannote.audio import Pipeline
# pipeline = Pipeline.from_pretrained("/home/wangweifei/repository/pyannote/speaker-diarization/config.yaml")
# print(pipeline)
# 针对不能拉取huggingface的模型问题：https://aws.amazon.com/cn/blogs/machine-learning/streamline-diarization-using-ai-as-an-assistive-technology-zoo-digitals-story/
# speaker_verification.py中import哪里

import whisperx
import gc 

device = "cuda" 
audio_file = "/home/wangweifei/repository/wair/asr_project/data/example_audio_1.mp3"
batch_size = 1 # reduce if low on GPU mem
compute_type = "float16" # change to "int8" if low on GPU mem (may reduce accuracy)

# 1. Transcribe with original whisper (batched)
model = whisperx.load_model("large-v2", device, compute_type=compute_type)

# save model to local path (optional)
# model_dir = "/path/"
# model = whisperx.load_model("large-v2", device, compute_type=compute_type, download_root=model_dir)

audio = whisperx.load_audio(audio_file)
result = model.transcribe(audio, batch_size=batch_size)
print(result["segments"]) # before alignment

# delete model if low on GPU resources
# import gc; gc.collect(); torch.cuda.empty_cache(); del model

# 2. Align whisper output
model_a, metadata = whisperx.load_align_model(language_code=result["language"], device=device)
result = whisperx.align(result["segments"], model_a, metadata, audio, device, return_char_alignments=False)

print(result["segments"]) # after alignment
import json
with open("result1.json", "w") as f:
    # 将结果对象转换为JSON格式并写入文件
    json.dump(result, f, indent=4 ,ensure_ascii=False)
# delete model if low on GPU resources
# import gc; gc.collect(); torch.cuda.empty_cache(); del model_a

# 3. Assign speaker labels
diarize_model = whisperx.DiarizationPipeline("/home/wangweifei/repository/pyannote/speaker-diarization/config.yaml", device=device)

# add min/max number of speakers if known
diarize_segments = diarize_model(audio)
# diarize_model(audio, min_speakers=min_speakers, max_speakers=max_speakers)

result = whisperx.assign_word_speakers(diarize_segments, result)
print(diarize_segments)
print(result["segments"]) # segments are now assigned speaker IDs
with open("result2.json", "w") as f:
    # 将结果对象转换为JSON格式并写入文件
    json.dump(result, f, indent=4 ,ensure_ascii=False)

#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