import pynini
from pynini.lib import utf8, byte
from pynini import cdrewrite

sigma = utf8.VALID_UTF8_CHAR.star

# rule1 = pynini.cross("pai2zhang3", "排长")
# rule2 = pynini.cross("pai2chang2", "排长")
# rule3 = pynini.cross('qi4ju4', '器具')
# rule4 = pynini.cross('pai2zhang4qi4', '排障器')


# rule = (rule1 | rule2 | rule3 | rule4).optimize()
# rule = cdrewrite(rule, "", "", sigma)

# rule.write('replace-2.fst')

replacements = {
    "金渝十": "金鱼石",
    "京鲤高速": "京礼高速",
    "沙子塘": "砂子塘",
    "临里站": "伶俐站",
    "研博度": "岩泊渡",
    "武陵园": "武陵源",
    "长德": "常德",
    "零五收费站": "临武收费站",
    # "零武收费站": "临武收费站",
    "零五服务区": "临武服务区",
    "一张枢纽": "宜章枢纽",
    "简加奥枢纽": "简家坳枢纽",
    "徐广高速": "许广高速",
    "武申高速 ": "武深高速",
    "金港澳": "京港澳",
    "常株高速": "长株高速",
    "新桐路": "欣桐路",
    "花名楼服务区": "花明楼服务区",
    "相通宝":"湘通宝",
    # "相通保":"湘通宝",
    "湘应东":"湘阴东",
    "祥阴东":"湘阴东",
    "示景灯":"示警灯",
    "真湘收费站":"蒸湘收费站",
    "支悉了":"知悉了",
    "注消":"注销",
    "施旧":"施救",
    "朗立东":"㮾梨东",
    "陆产":"路产",
    # "鹿产":"路产",
    "车祸总重":"车货总重"
}
from pypinyin import pinyin, lazy_pinyin, Style
rules = []
rules_code_lines = []  # 存储每条规则的赋值语句
rule_names = []        # 存储规则变量名（如 rule1, rule2）
# for old, new in replacements.items():
for index, (old, new) in enumerate(replacements.items(), start=1):

    pinyin_list = pinyin(old, style=Style.TONE3)
    pinyin_res = ''.join([p[0] for p in pinyin_list])

    # rule = pynini.cross(pinyin_res, new)
    # rules.append(rule)

    # print(f"rule{index}: {pinyin_res} → {new}")
    # 构建规则并写入变量名和对应语句
    rule_var = f"rule{index}"
    rule_code = f"{rule_var} = pynini.cross('{pinyin_res}', '{new}')"
    
    rules_code_lines.append(rule_code)
    rule_names.append(rule_var)
    print(rule_code)
# 拼接主规则语句
combined_rule = " | ".join(rule_names)
# rule = ({rule1} | {rule2} | {rule3} | {rule4} | {rule5})
final_rule_line = f"rule = ({combined_rule}).optimize()"
print(final_rule_line)



# final_rule_line = (rule1 | rule2 | rule3 | rule4 | rule5 | rule6 | rule7 | rule8 | rule9 | rule10 | rule11 | rule12 | rule13 | rule14 | rule15 | rule16 | rule17 | rule18 | rule19 | rule20 | rule21 | rule22 | rule23 | rule24 | rule25 | rule26 | rule27 | rule28).optimize()







rule_new = cdrewrite(final_rule_line, "", "", sigma)
rule_new.write('/home/wangweifei/repository/wair/baseline_test_datasets/data/service_test_data/dianhua_2436/dianhua_replace.fst')