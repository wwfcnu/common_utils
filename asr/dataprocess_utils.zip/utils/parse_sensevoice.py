import time
import argparse
import re

def parse(input_string: str):
    """
    Parse from SenseVoice output.
    """
    # pattern = r"^(\S+)\s<\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|>(.*)$"
    pattern = r"^(\S+)\s<\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|><\|([^|]+)\|>(.*)?"
    match = re.match(pattern, input_string)
    
    if match:
        wav_id, language, emotion, event, textnorm, text = match.groups()
        return {
            "wav_id": wav_id,
            "language": language,
            "emotion": emotion,
            "event": event,
            "textnorm": textnorm,
            "text": text.strip()
        }
    else:
        raise ValueError(f"Cannot parse the input string: {input_string}")

def process_output(output_dir):
    output_file = f"{output_dir}/1best_recog/text"
    parsed_output_file = f"{output_dir}/1best_recog/parse_text"
    with open(output_file, 'r', encoding='utf-8') as f_in, open(parsed_output_file, 'w', encoding='utf-8') as f_out:
        for line in f_in:
            try:
                parsed_data = parse(line.strip())
                wav_id = parsed_data["wav_id"]
                text = parsed_data["text"]
                
                # Write the result to the parsed output file
                f_out.write(f"{wav_id}\t{text}\n")
            except ValueError as e:
                print(f"Error processing line: {e}")


def main():
    parser = argparse.ArgumentParser(description="ASR transcription and result parsing using SenseVoice model.")
    parser.add_argument('--output_dir', type=str, help='Directory to save the transcription output')
    # Parse the arguments
    args = parser.parse_args()

    process_output(args.output_dir)


if __name__ == "__main__":
    main()