import json
import os
import argparse

def read_json_file(json_filename):
    with open(json_filename, 'r') as f:
        return json.load(f)

def get_file_prefix(json_filename):
    return os.path.splitext(os.path.basename(json_filename))[0]

def filter_and_parse_data(data, dnsmos_threshold, file_prefix):
    segments_content = []
    # text_content = []
    dnsmos_content = []
    speaker_content = []
    for idx, item in enumerate(data):
        if item['dnsmos'] >= dnsmos_threshold:
            wav_id = f"{file_prefix}_{idx}"
            segments_content.append(f"{wav_id} {file_prefix} {item['start']} {item['end']}")
            # text_content.append(f"{wav_id}\t{item['text']}")
            dnsmos_content.append(f"{wav_id}\t{item['dnsmos']}")
            speaker_content.append(f"{wav_id}\t{file_prefix}\t{item['speaker']}")
    
    # return segments_content, text_content, dnsmos_content,speaker_content
    return segments_content,dnsmos_content,speaker_content

def write_to_file(filename, content):
    with open(filename, 'a') as f:  # Use 'a' mode to append content to the file
        for line in content:
            f.write(line + '\n')

def process_json_files_in_directory(directory, output_directory, dnsmos_threshold):
    all_segments_content = []
    # all_text_content = []
    all_dnsmos_content = []
    all_speaker_content = []
    json_file_count = 0  # 添加计数器
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.json'):
                json_file_count += 1  # 统计JSON文件数量
                json_filename = os.path.join(root, file)
                data = read_json_file(json_filename)
                file_prefix = get_file_prefix(json_filename)
                
                segments_content,dnsmos_content, speaker_content = filter_and_parse_data(data, dnsmos_threshold, file_prefix)
                
                all_segments_content.extend(segments_content)
                # all_text_content.extend(text_content)
                all_dnsmos_content.extend(dnsmos_content)  
                all_speaker_content.extend(speaker_content)

    # Ensure output directory exists
    os.makedirs(output_directory, exist_ok=True)
    
    # Generate output file paths
    segments_file = os.path.join(output_directory, 'segments')
    # text_file = os.path.join(output_directory, 'text')
    dnsmos_file = os.path.join(output_directory, 'dnsmos')
    speaker_file = os.path.join(output_directory, 'speaker')

    # Write to output files
    write_to_file(segments_file, all_segments_content)
    # write_to_file(text_file, all_text_content)
    write_to_file(dnsmos_file, all_dnsmos_content)
    write_to_file(speaker_file, all_speaker_content)

    print(f"总共处理了 {json_file_count} 个JSON文件")
    print("All files processed.")

def main():
    parser = argparse.ArgumentParser(description="Process JSON files to extract segments and text.")
    parser.add_argument('directory', type=str, help='The directory containing JSON files.')
    parser.add_argument('output_directory', type=str, help='The directory to output segments and text files.')
    parser.add_argument('--dnsmos', type=float, default=0.0, help='DNSMOS threshold for JSON files.')

    args = parser.parse_args()
    
    process_json_files_in_directory(args.directory, args.output_directory, args.dnsmos)

if __name__ == '__main__':
    main()
