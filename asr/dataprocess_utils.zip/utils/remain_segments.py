# 先开始处理了一部分/home/wangweifei/repository/wair/asr_project/transcribe/podcast/segment_split/segments_merge_path.txt,处理log

processed_segments = []
with open("/home/wangweifei/repository/wair/asr_project/transcribe/podcast/segment_split/segments_merge_path.txt") as f:
    # 路径位置移动到了/lustre/wangweifei/data/segments_merge
    for line in f:
        segments_path = line.strip()
        segments_file = segments_path.split("/")[-1]
        processed_segments.append(segments_file)



with open("/lustre/wangweifei/data/segments_merge_path_20240324.txt")as f,open("/lustre/wangweifei/data/remain_segments_merge_path_20240324.txt","w")as w:

    for line in f:
        segments_path = line.strip()
        segments_file = segments_path.split("/")[-1]
        if segments_file in processed_segments:
            print(f"{segments_file}已经处理，跳过")
            continue
        else:
            w.write(f"/lustre/wangweifei/{segments_path}\n")
