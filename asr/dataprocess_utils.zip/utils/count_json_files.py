#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统计指定目录下JSON文件的数量
"""

import os
import argparse

def count_json_files(directory):
    """
    统计指定目录下所有JSON文件的数量
    
    Args:
        directory (str): 要统计的目录路径
        
    Returns:
        int: JSON文件的总数量
    """
    json_file_count = 0
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.json'):
                json_file_count += 1
                print(f"找到JSON文件: {os.path.join(root, file)}")
    
    return json_file_count

def main():
    parser = argparse.ArgumentParser(description="统计指定目录下JSON文件的数量")
    parser.add_argument('directory', type=str, help='要统计的目录路径')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.directory):
        print(f"错误: 目录 '{args.directory}' 不存在")
        return
    
    print(f"正在统计目录 '{args.directory}' 下的JSON文件...")
    print("-" * 50)
    
    total_count = count_json_files(args.directory)
    
    print("-" * 50)
    print(f"统计完成！")
    print(f"总共找到 {total_count} 个JSON文件")

if __name__ == '__main__':
    main()
