from pydub import AudioSegment
import os
from tqdm import tqdm
import sys
from multiprocessing import cpu_count
from concurrent.futures import ProcessPoolExecutor
executor = ProcessPoolExecutor(max_workers=cpu_count())

# 直接输入segments文件，由segments文件找audio,就是通过wav_id找wav_path
wav_scp_path = {}
with open("/home/wangweifei/repository/wair/asr_project/data/podcast/wav.scp")as f:
    for line in f:
        wav_id,wav_path = line.strip().split()
        wav_scp_path[wav_id] = wav_path



def process(segments_file,output_folder):

    try:
        wav_id = segments_file.split("/")[-1].split(".")[0]

        output_dir = os.path.join(output_folder,wav_id)

        os.makedirs(output_dir, exist_ok=True)     # 创建以文件名为文件夹的名字

        # 加载整个音频文件
        wav_path = wav_scp_path.get(wav_id)
        audio = AudioSegment.from_file(wav_path)


        with open(segments_file, 'r') as f:
            lines = f.readlines()

        # 循环处理每一行
        for line in tqdm(lines):
            # 分割每一行，并提取start和end时间
            parts = line.split()
            filename = parts[0]
            start_time = float(parts[2])
            end_time = float(parts[3])
            
            # 输出文件路径
            output_file = os.path.join(output_dir, f'{filename}.wav')

            # 检查输出文件是否已经存在
            if os.path.exists(output_file):
                print(f"{output_file} already exists, skipping")
                continue



            # 使用pydub切割音频
            segment = audio[start_time * 1000:end_time * 1000]  # pydub uses milliseconds
            if segment: # 判断是否有值
                segment = segment.set_frame_rate(16000).set_channels(1)
                segment.export(output_file, format='wav')
    except Exception as e:
        print(f"切分文件{segment_file}失败")

if __name__ == "__main__":


    segments_list = []
    segments_merge_path = sys.argv[1]   # 合并后的segments文件，包含的是segments的路径
    with open(segments_merge_path)as f:
        for line in f:
            segment_file = line.strip()
            segments_list.append(segment_file)

    num_parts = int(sys.argv[2])   # 分成几部分，比如10000个segments文件可以分成，20*500
    # Split segments_list into 500 equal parts
    segments_per_folder = len(segments_list) // num_parts
    segment_batches = [segments_list[i:i+segments_per_folder] for i in range(0, len(segments_list), segments_per_folder)]

    # Define output folders
    output_part_dir = sys.argv[3] # /lustre/wangweifei/podcast_seg/part1 ，
    output_folders = [f"{output_part_dir}/{i}" for i in range(0, num_parts + 1)] # 分成多少个上级目录,{num_part}/wav_id/*.wav

    # Iterate over each batch and assign it to the corresponding output folder
    for i, batch in enumerate(segment_batches):
        output_folder = output_folders[i]
        # for segments_file in batch:
        #     process(segments_file, output_folder)
        futures = []
        for segments_file in tqdm(batch):
            futures.append(executor.submit(process,segments_file,output_folder))
        result = [future.result() for future in tqdm(futures)]



# python Audio_segment.py segments_file_path.txt 2 /lustre/wangweifei/podcast_seg/part1
# 注意没有整除的情况    output_folder = output_folders[i]  IndexError: list index out of range