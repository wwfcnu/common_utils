from pydub import AudioSegment
import random
import os
import argparse
from typing import Dict, Tuple, List
from functools import lru_cache

@lru_cache(maxsize=None)
def load_audio(wav_path: str, target_sr: int = 16000) -> AudioSegment:
    """
    加载音频文件并转换为标准格式（16kHz, 单通道）
    使用lru_cache缓存结果，避免重复加载相同的文件
    """
    audio = AudioSegment.from_file(wav_path)
    
    # 转换为单通道
    if audio.channels > 1:
        audio = audio.set_channels(1)
    
    # 设置采样率为16kHz
    if audio.frame_rate != target_sr:
        audio = audio.set_frame_rate(target_sr)
        
    return audio

def read_wav_scp(wav_scp_path: str) -> Dict[str, str]:
    """读取wav.scp文件，返回wav_id到wav路径的映射"""
    wav_dict = {}
    with open(wav_scp_path, 'r', encoding='utf-8') as f:
        for line in f:
            wav_id, wav_path = line.strip().split(maxsplit=1)
            wav_dict[wav_id] = wav_path
    return wav_dict

def read_segments(segments_path: str) -> Dict[str, Tuple[str, float, float]]:
    """读取segments文件，返回uttid到(wav_id, start, end)的映射"""
    segments_dict = {}
    with open(segments_path, 'r', encoding='utf-8') as f:
        for line in f:
            uttid, wav_id, start, end = line.strip().split()
            segments_dict[uttid] = (wav_id, float(start), float(end))
    return segments_dict

def read_filter(filter_path: str) -> list:
    """读取filter.txt文件，返回uttid列表"""
    with open(filter_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f]

def filter_by_duration(uttids: List[str], 
                      segments_dict: Dict[str, Tuple[str, float, float]], 
                      min_duration: float = 5.0) -> List[str]:
    """筛选出时长大于指定秒数的uttid"""
    filtered_uttids = []
    
    for uttid in uttids:
        if uttid in segments_dict:
            _, start, end = segments_dict[uttid]
            duration = end - start
            if duration >= min_duration:
                filtered_uttids.append(uttid)
    
    return filtered_uttids

def extract_segments(wav_dict: Dict[str, str], 
                    segments_dict: Dict[str, Tuple[str, float, float]], 
                    selected_uttids: list,
                    output_dir: str):
    """提取选定的音频片段并保存"""
    os.makedirs(output_dir, exist_ok=True)
    
    # 按wav_id分组uttid，减少重复加载
    wav_id_to_uttids = {}
    for uttid in selected_uttids:
        if uttid in segments_dict:
            wav_id = segments_dict[uttid][0]
            if wav_id in wav_dict:  # 确保wav_id有效
                wav_id_to_uttids.setdefault(wav_id, []).append(uttid)
            else:
                print(f"Warning: wav_id {wav_id} not found in wav.scp")
        else:
            print(f"Warning: uttid {uttid} not found in segments file")
    
    # 处理每个音频文件
    for wav_id, uttids in wav_id_to_uttids.items():
        try:
            # 加载并标准化音频（会被缓存，相同wav_id只加载一次）
            wav_path = wav_dict[wav_id]
            audio = load_audio(wav_path)
            
            # 处理这个音频文件的所有片段
            for uttid in uttids:
                _, start, end = segments_dict[uttid]
                start_ms = int(start * 1000)
                end_ms = int(end * 1000)
                
                # 提取片段
                segment = audio[start_ms:end_ms]
                
                # 保存音频片段
                output_path = os.path.join(output_dir, f"{uttid}.wav")
                segment.export(output_path, format="wav")
                
                # print(f"Successfully processed: {uttid} (duration: {(end-start):.2f}s)")
                
        except Exception as e:
            print(f"Error processing wav_id {wav_id}: {str(e)}")
            continue

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='Extract audio segments based on filter list.')
    
    parser.add_argument('--wav_scp', type=str, required=True,
                        help='Path to wav.scp file')
    parser.add_argument('--segments', type=str, required=True,
                        help='Path to segments file')
    parser.add_argument('--filter', type=str, required=True,
                        help='Path to filter.txt file')
    parser.add_argument('--output_dir', type=str, required=True,
                        help='Directory to save extracted segments')
    parser.add_argument('--sample_num', type=int, default=2000,
                        help='Number of utterances to sample (default: 2000)')
    parser.add_argument('--min_duration', type=float, default=5.0,
                        help='Minimum duration in seconds (default: 5.0)')
    
    return parser.parse_args()

def main():
    # 解析命令行参数
    args = parse_args()
    
    # 读取所有文件
    wav_dict = read_wav_scp(args.wav_scp)
    segments_dict = read_segments(args.segments)
    uttids = read_filter(args.filter)
    
    # 筛选出大于指定时长的uttid
    valid_uttids = filter_by_duration(uttids, segments_dict, args.min_duration)
    print(f"Found {len(valid_uttids)} utterances >= {args.min_duration}s from total {len(uttids)} utterances")
    
    if not valid_uttids:
        print("No valid utterances found!")
        return
    
    # 随机选择指定数量的uttid
    sample_num = min(args.sample_num, len(valid_uttids))   # 同时包含了valid_uttids小于sample_num的情况
    selected_uttids = random.sample(valid_uttids, sample_num)
    
    # 提取并保存音频片段
    extract_segments(wav_dict, segments_dict, selected_uttids, args.output_dir)

if __name__ == "__main__":
    # 从训练数据中挑选测试集2000条进行测试
    main()